# CareerOS Auth Testing Playbook

Auth: custom email/password JWT. Access token (60 min) + refresh token (7 days) set as httpOnly cookies (`access_token`, `refresh_token`, secure, samesite=none). `GET /api/auth/me` also accepts `Authorization: Bearer <access_token>` as fallback.

User documents use string `id` (uuid4), not ObjectId.

## Endpoints
- POST /api/auth/register {name, email, password} → user + cookies (409 on duplicate email)
- POST /api/auth/login {email, password} → user + cookies (401 invalid, 429 after 5 failed attempts / 15 min lockout)
- POST /api/auth/logout → clears cookies
- GET /api/auth/me → current user (401 unauthenticated)
- POST /api/auth/refresh → new access cookie from refresh cookie
- POST /api/auth/forgot-password {email} → always {ok:true}; reset link logged to backend log
- POST /api/auth/reset-password {token, password}
- POST /api/waitlist {email, name?} → {ok, message}

## Step 1: MongoDB
```
mongosh
use app
db.users.find({role:"admin"})
db.users.findOne({role:"admin"},{password_hash:1})   # must start with $2b$
```
Indexes: users.email (unique), users.id (unique), password_reset_tokens.expires_at (TTL), waitlist.email (unique).

## Step 2: API (use https public URL so secure cookies are set)
```
API=https://resume-hub-436.preview.emergentagent.com
curl -c cj.txt -X POST $API/api/auth/login -H "Content-Type: application/json" -d '{"email":"admin@careeros.io","password":"CareerOS-Admin-2026!"}'
curl -b cj.txt $API/api/auth/me
curl -X POST $API/api/auth/login -H "Content-Type: application/json" -d '{"email":"admin@careeros.io","password":"wrong"}'   # expect 401
curl -X POST $API/api/waitlist -H "Content-Type: application/json" -d '{"email":"test@example.com"}'
```

Credentials live in /app/memory/test_credentials.md.
