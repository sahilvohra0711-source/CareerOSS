import io
import json
import os
import re
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from emergentintegrations.llm.chat import LlmChat, StreamDone, TextDelta, UserMessage

from lib.db import db

router = APIRouter(prefix="/ai", tags=["ai"])

MODEL = ("openai", "gpt-5.4")

RESUME_SCHEMA = """{
  "name": string (short label, e.g. "Software Engineer — Imported"),
  "personal": {"fullName": "", "title": "", "email": "", "phone": "", "location": "", "website": "", "linkedin": ""},
  "summary": string,
  "experience": [{"company": "", "role": "", "location": "", "start": "2022", "end": "Present", "current": true, "bullets": [string]}],
  "education": [{"school": "", "degree": "", "field": "", "start": "", "end": ""}],
  "projects": [{"name": "", "description": "", "tech": [string], "url": ""}],
  "skills": [string],
  "certifications": [{"name": "", "issuer": "", "year": ""}],
  "achievements": [string]
}"""


def make_chat(session_id: str, system: str) -> LlmChat:
    chat = LlmChat(
        api_key=os.environ["EMERGENT_LLM_KEY"],
        session_id=session_id,
        system_message=system,
    )
    return chat.with_model(*MODEL)


async def complete(session_id: str, system: str, prompt: str) -> str:
    return await make_chat(session_id, system).send_message(UserMessage(text=prompt))


def extract_json(text: str):
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", cleaned, flags=re.S).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    for open_c, close_c in (("{", "}"), ("[", "]")):
        start = cleaned.find(open_c)
        end = cleaned.rfind(close_c)
        if start != -1 and end > start:
            try:
                return json.loads(cleaned[start:end + 1])
            except json.JSONDecodeError:
                continue
    raise ValueError("model returned no parseable JSON")


def uid() -> str:
    return uuid.uuid4().hex[:8]


# ------------------------------- coach chat (SSE) -------------------------------

class ChatBody(BaseModel):
    message: str
    history: list[dict] = []
    context: dict = {}


@router.post("/chat")
async def coach_chat(body: ChatBody):
    session_id = f"coach-{uid()}"
    ctx = body.context or {}
    system = (
        "You are Nova, the AI career coach inside CareerOS. Give specific, actionable, honest career advice — "
        "never generic platitudes. Keep answers under 150 words, use short numbered steps when advising, and end "
        "with one concrete next action. You know the user's workspace context: "
        f"career readiness {ctx.get('readiness', '?')}/100, resume score {ctx.get('resumeScore', '?')}/100, "
        f"{ctx.get('apps', '?')} tracked applications, target role Software Engineer."
    )
    history_text = "\n".join(
        f"{'User' if m.get('from') == 'user' else 'Nova'}: {m.get('text', '')}" for m in body.history[-6:]
    )
    prompt = f"{history_text}\nUser: {body.message}" if history_text else body.message

    async def gen():
        full = ""
        try:
            chat = make_chat(session_id, system)
            async for ev in chat.stream_message(UserMessage(text=prompt)):
                if isinstance(ev, TextDelta):
                    full += ev.content
                    yield f"data: {json.dumps({'t': ev.content})}\n\n"
                elif isinstance(ev, StreamDone):
                    break
        except Exception as exc:  # surface failure so the client falls back
            yield f"data: {json.dumps({'error': str(exc)[:200]})}\n\n"
        yield "data: [DONE]\n\n"
        if full:
            await db.coach_chats.insert_one({
                "id": str(uuid.uuid4()), "session_id": session_id,
                "message": body.message, "reply": full,
                "created_at": datetime.now(timezone.utc),
            })

    return StreamingResponse(
        gen(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ------------------------------- resume parsing -------------------------------

def extract_text(filename: str, content: bytes) -> str:
    name = filename.lower()
    if name.endswith(".pdf"):
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(content))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if name.endswith(".docx"):
        import docx
        doc = docx.Document(io.BytesIO(content))
        parts = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                parts.extend(cell.text for cell in row.cells if cell.text.strip())
        return "\n".join(parts)
    if name.endswith(".doc"):
        raise HTTPException(status_code=400, detail="Legacy .doc files aren't supported — please save as .docx or PDF.")
    raise HTTPException(status_code=400, detail="Unsupported file type. Upload a PDF or DOCX.")


@router.post("/parse-resume")
async def parse_resume(file: UploadFile):
    content = await file.read()
    if len(content) > 6 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large (max 6 MB).")
    text = extract_text(file.filename or "resume.pdf", content)
    if len(text.strip()) < 80:
        raise HTTPException(status_code=422, detail="Couldn't read enough text — is this a scanned image PDF?")

    prompt = (
        "Extract this resume into structured JSON matching EXACTLY this schema (no extra keys, no commentary, "
        "JSON only). Keep every achievement bullet. Infer a short professional title if missing.\n\n"
        f"SCHEMA:\n{RESUME_SCHEMA}\n\nRESUME TEXT:\n{text[:12000]}"
    )
    try:
        data = extract_json(await complete(f"parse-{uid()}", "You are a precise resume parser. Output JSON only.", prompt))
    except Exception:
        raise HTTPException(status_code=502, detail="AI parsing failed. Please try again.")

    resume = {
        "id": uid(),
        "name": data.get("name") or "Imported Resume",
        "template": "modern",
        "updatedAt": datetime.now(timezone.utc).date().isoformat(),
        "personal": {**{"fullName": "", "title": "", "email": "", "phone": "", "location": "", "website": "", "linkedin": ""}, **(data.get("personal") or {})},
        "summary": data.get("summary") or "",
        "experience": [{**e, "id": uid(), "bullets": e.get("bullets") or []} for e in data.get("experience") or []],
        "education": [{**e, "id": uid()} for e in data.get("education") or []],
        "projects": [{**p, "id": uid(), "tech": p.get("tech") or []} for p in data.get("projects") or []],
        "skills": data.get("skills") or [],
        "certifications": [{**c, "id": uid()} for c in data.get("certifications") or []],
        "achievements": data.get("achievements") or [],
    }
    return resume


# --------------------------- structured AI endpoints ---------------------------

class EvalBody(BaseModel):
    question: str
    answer: str
    type: str = "General"
    level: str = "Mid"


@router.post("/evaluate-answer")
async def evaluate_answer(body: EvalBody):
    prompt = (
        f"Interview type: {body.type}. Candidate level: {body.level}.\n"
        f"QUESTION: {body.question}\nANSWER: {body.answer}\n\n"
        "Score this interview answer. Return JSON only: "
        '{"clarity": 1-10, "depth": 1-10, "structure": 1-10, "impact": 1-10, '
        '"overall": number 1-10 with one decimal (average), '
        '"reaction": "excellent"|"strong"|"average"|"weak" '
        '(excellent >=8.5, strong >=7, average >=5, else weak), '
        '"feedback": string (2-3 sentences, specific: what worked, what to add, reference their actual words)}'
    )
    data = extract_json(await complete(f"eval-{uid()}", "You are a rigorous but encouraging interview coach. JSON only.", prompt))
    return {
        "scores": {
            "clarity": float(data.get("clarity", 5)), "depth": float(data.get("depth", 5)),
            "structure": float(data.get("structure", 5)), "impact": float(data.get("impact", 5)),
            "overall": float(data.get("overall", 5)),
        },
        "feedback": data.get("feedback") or "Solid answer — tighten the structure and add a measurable result.",
        "reaction": data.get("reaction") if data.get("reaction") in ("excellent", "strong", "average", "weak") else "average",
    }


class ResumeBody(BaseModel):
    resume: dict


@router.post("/analyze-resume")
async def analyze_resume(body: ResumeBody):
    r = body.resume
    bullets = [b for e in r.get("experience", []) for b in e.get("bullets", [])]
    prompt = (
        "Act as an ATS (applicant tracking system) and senior recruiter. Analyze this resume for a Software Engineer target role.\n"
        f"SUMMARY: {r.get('summary', '')}\nSKILLS: {', '.join(r.get('skills', []))}\n"
        f"EXPERIENCE BULLETS:\n" + "\n".join(f"- {b}" for b in bullets) + "\n\n"
        "Return JSON only: {\"overall\": 0-100, "
        '"categories": [{"label": "Formatting"|"Impact"|"Clarity"|"Keywords"|"Experience"|"Skills", "score": 0-100, "note": string}], '
        '"feedback": [{"title": string (with counts, e.g. "2 bullets missing measurable achievements"), "detail": string (quote the actual bullet), "action": string (imperative fix)}]}. '
        "2-4 feedback items, each quoting real text from the resume."
    )
    return extract_json(await complete(f"ats-{uid()}", "You are an ATS analyzer. JSON only, specific and evidence-based.", prompt))


class MatchBody(BaseModel):
    resume: dict
    jd: str


@router.post("/match")
async def match_job(body: MatchBody):
    r = body.resume
    prompt = (
        "Compare this resume against the job description.\n"
        f"RESUME SUMMARY: {r.get('summary', '')}\nSKILLS: {', '.join(r.get('skills', []))}\n"
        f"TOP EXPERIENCE: {json.dumps(r.get('experience', [])[:2])[:2000]}\n\n"
        f"JOB DESCRIPTION:\n{body.jd[:6000]}\n\n"
        "Return JSON only: {\"score\": 0-100 (overall match), "
        '"matched": [skill strings the candidate provably has], "missing": [required/nice-to-have skills they lack], '
        '"categories": [{"label": "Skills Match"|"Experience Match"|"Education Match"|"Keyword Coverage", "value": 0-100}], '
        '"suggestions": [3-4 specific, non-generic strings]}.'
    )
    return extract_json(await complete(f"match-{uid()}", "You are a precise job-matching engine. JSON only.", prompt))


@router.post("/tailor")
async def tailor_resume(body: MatchBody):
    r = body.resume
    bullets = [(e.get("company", ""), b) for e in r.get("experience", [])[:2] for b in e.get("bullets", [])[:2]]
    prompt = (
        "Rewrite these resume bullets to fit the job description. Never invent experience — only reframe, quantify "
        "plausibly from context, and mirror JD keywords.\n"
        f"BULLETS (company :: bullet):\n" + "\n".join(f"{c} :: {b}" for c, b in bullets) + "\n\n"
        f"JOB DESCRIPTION:\n{body.jd[:5000]}\n\n"
        "Return JSON only — a list: [{\"original\": exact original bullet, \"improved\": rewritten bullet, "
        '"why": one sentence naming the concrete technique used, "company": company string}].'
    )
    return extract_json(await complete(f"tailor-{uid()}", "You are an elite resume writer. JSON only.", prompt))


class ProjectBody(BaseModel):
    project: dict
    variant: str = "resume"


@router.post("/project-description")
async def project_description(body: ProjectBody):
    p = body.project
    style = {
        "resume": "Two tight resume bullets: what it does + a measurable achievement. Plain text.",
        "linkedin": "A LinkedIn post: hook line, what it does, stack, one achievement, 3 hashtags.",
        "github": "A GitHub README intro: title, one-paragraph description, Stack list, Highlights list. Markdown.",
    }[body.variant if body.variant in ("resume", "linkedin", "github") else "resume"]
    prompt = (
        f"Write the {body.variant} version of this project description. Style: {style}\n"
        f"PROJECT: {p.get('name')} — {p.get('description')}\nTECH: {', '.join(p.get('tech', []))}\n"
        f"ACHIEVEMENTS: {'; '.join(p.get('achievements', []))}\n"
        'Return JSON only: {"text": string}.'
    )
    data = extract_json(await complete(f"proj-{uid()}", "You are a sharp technical copywriter. JSON only.", prompt))
    return {"text": data.get("text", "")}
