import { Route, Routes } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/sonner";
import { CareerProvider } from "@/context/CareerContext";
import LandingPage from "@/pages/landing/LandingPage";
import NotFound from "@/pages/NotFound";
import { ForgotPassword, Login, Signup } from "@/pages/auth/AuthPages";
import AppShell from "@/components/layout/AppShell";
import Dashboard from "@/pages/app/Dashboard";
import Resumes from "@/pages/app/Resumes";
import ResumeBuilder from "@/pages/app/ResumeBuilder";
import JobMatcher from "@/pages/app/JobMatcher";
import AtsAnalysis from "@/pages/app/AtsAnalysis";
import Tailor from "@/pages/app/Tailor";
import Applications from "@/pages/app/Applications";
import Companies from "@/pages/app/Companies";
import Jobs from "@/pages/app/Jobs";
import Interview from "@/pages/app/Interview";
import Skills from "@/pages/app/Skills";
import Roadmap from "@/pages/app/Roadmap";
import Projects from "@/pages/app/Projects";
import Analytics from "@/pages/app/Analytics";
import Coach from "@/pages/app/Coach";
import Reminders from "@/pages/app/Reminders";
import Profile from "@/pages/app/Profile";
import Settings from "@/pages/app/Settings";

// One <Route> per page; BrowserRouter + QueryClientProvider already wrap this in main.tsx.
export default function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} storageKey="careeros-theme">
      <CareerProvider>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/app" element={<AppShell />}>
            <Route index element={<Dashboard />} />
            <Route path="resumes" element={<Resumes />} />
            <Route path="resumes/:id" element={<ResumeBuilder />} />
            <Route path="matcher" element={<JobMatcher />} />
            <Route path="ats" element={<AtsAnalysis />} />
            <Route path="tailor" element={<Tailor />} />
            <Route path="applications" element={<Applications />} />
            <Route path="companies" element={<Companies />} />
            <Route path="jobs" element={<Jobs />} />
            <Route path="interview" element={<Interview />} />
            <Route path="skills" element={<Skills />} />
            <Route path="roadmap" element={<Roadmap />} />
            <Route path="projects" element={<Projects />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="coach" element={<Coach />} />
            <Route path="reminders" element={<Reminders />} />
            <Route path="profile" element={<Profile />} />
            <Route path="settings" element={<Settings />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster />
      </CareerProvider>
    </ThemeProvider>
  );
}
