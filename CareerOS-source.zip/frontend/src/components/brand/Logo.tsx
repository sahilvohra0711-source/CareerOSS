import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={cn("h-9 w-9", className)} aria-hidden>
      <defs>
        <linearGradient id="cos-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5B5FEF" />
          <stop offset=".55" stopColor="#7C3AED" />
          <stop offset="1" stopColor="#22D3EE" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="58" height="58" rx="16" fill="#0B1020" />
      <rect x="3" y="3" width="58" height="58" rx="16" fill="url(#cos-g)" opacity=".16" />
      <path d="M43 23.5a12.5 12.5 0 1 0 0 17" stroke="url(#cos-g)" strokeWidth="6" strokeLinecap="round" fill="none" />
      <circle cx="44" cy="20" r="4" fill="#22D3EE" />
    </svg>
  );
}

export function Logo({ className, textClassName }: { className?: string; textClassName?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)} data-testid="brand-logo">
      <LogoMark />
      <span className={cn("font-heading text-lg font-bold tracking-tight", textClassName)}>
        Career<span className="text-gradient">OS</span>
      </span>
    </span>
  );
}
