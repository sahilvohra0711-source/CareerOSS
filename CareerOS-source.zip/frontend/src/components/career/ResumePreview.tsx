import type { Resume } from "@/lib/types";
import { cn } from "@/lib/utils";

/* Renders a print-faithful A4 resume. Always light: resumes are read by humans + ATS. */
export function ResumePreview({ resume, printId = false }: { resume: Resume; printId?: boolean }) {
  const t = resume.template;
  const p = resume.personal;

  const accents: Record<string, string> = {
    modern: "#5B5FEF",
    minimal: "#334155",
    professional: "#0F172A",
    tech: "#0891B2",
    executive: "#6D28D9",
  };
  const accent = accents[t];

  const H = ({ children }: { children: string }) => (
    <h2
      className={cn(
        "mb-1.5 text-[11px] font-bold uppercase tracking-[0.18em]",
        t === "tech" && "font-mono",
        t === "minimal" && "text-center",
      )}
      style={{ color: accent, borderBottom: t === "minimal" ? "none" : `1.5px solid ${accent}33`, paddingBottom: 3 }}
    >
      {children}
    </h2>
  );

  return (
    <div
      id={printId ? "resume-print" : undefined}
      data-testid="resume-preview"
      className={cn(
        "mx-auto aspect-[1/1.414] w-full max-w-[640px] overflow-hidden bg-white text-[#1F2937] shadow-xl",
        t === "executive" ? "p-10" : "p-8",
        t === "tech" && "font-mono",
      )}
      style={{ fontSize: 11, lineHeight: 1.45 }}
    >
      {t === "professional" || t === "executive" ? (
        <header className="-mx-8 -mt-8 mb-5 px-8 py-6 text-white" style={{ background: accent }}>
          <h1 className="font-heading text-2xl font-bold tracking-tight">{p.fullName}</h1>
          <p className="text-[12px] opacity-90">{p.title}</p>
          <p className="mt-2 text-[10px] opacity-75">
            {p.email} · {p.phone} · {p.location} · {p.linkedin}
          </p>
        </header>
      ) : (
        <header className={cn("mb-5", t === "minimal" ? "text-center" : "border-l-4 pl-4")} style={{ borderColor: accent }}>
          <h1 className="font-heading text-2xl font-bold tracking-tight" style={{ color: t === "minimal" ? "#111827" : accent }}>
            {p.fullName}
          </h1>
          <p className="text-[12px] font-medium">{p.title}</p>
          <p className="mt-1 text-[10px] text-[#6B7280]">
            {p.email} · {p.phone} · {p.location}
            {p.website ? ` · ${p.website}` : ""}
          </p>
        </header>
      )}

      {resume.summary && (
        <section className="mb-4">
          <H>Summary</H>
          <p>{resume.summary}</p>
        </section>
      )}

      <section className="mb-4">
        <H>Experience</H>
        {resume.experience.map((e) => (
          <div key={e.id} className="mb-3">
            <div className="flex items-baseline justify-between">
              <p className="text-[12px] font-bold">{e.role} — <span style={{ color: accent }}>{e.company}</span></p>
              <p className="text-[10px] text-[#6B7280]">{e.start} – {e.current ? "Present" : e.end}</p>
            </div>
            <ul className="mt-1 list-disc space-y-0.5 pl-4 text-[#374151]">
              {e.bullets.filter(Boolean).map((b, i) => <li key={i}>{b}</li>)}
            </ul>
          </div>
        ))}
      </section>

      {resume.projects.length > 0 && (
        <section className="mb-4">
          <H>Projects</H>
          {resume.projects.map((pr) => (
            <div key={pr.id} className="mb-2">
              <p className="text-[12px] font-bold">
                {pr.name} <span className="font-normal text-[#6B7280]">— {pr.tech.join(", ")}</span>
              </p>
              <p>{pr.description}</p>
            </div>
          ))}
        </section>
      )}

      <section className="mb-4">
        <H>Skills</H>
        <p>{resume.skills.join(" · ")}</p>
      </section>

      <section className="mb-4">
        <H>Education</H>
        {resume.education.map((e) => (
          <div key={e.id} className="flex items-baseline justify-between">
            <p className="text-[12px] font-bold">{e.degree} {e.field} — {e.school}</p>
            <p className="text-[10px] text-[#6B7280]">{e.start} – {e.end}</p>
          </div>
        ))}
      </section>

      {resume.certifications.length > 0 && (
        <section className="mb-4">
          <H>Certifications</H>
          {resume.certifications.map((c) => (
            <p key={c.id}>{c.name} — {c.issuer} ({c.year})</p>
          ))}
        </section>
      )}

      {resume.achievements.length > 0 && (
        <section>
          <H>Achievements</H>
          <ul className="list-disc pl-4">
            {resume.achievements.filter(Boolean).map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        </section>
      )}
    </div>
  );
}
