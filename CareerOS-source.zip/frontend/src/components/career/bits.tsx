import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion, useInView } from "motion/react";
import { cn } from "@/lib/utils";

/* Animated circular progress ring */
export function ScoreRing({
  value, size = 120, stroke = 9, label, sub, className, testId,
}: {
  value: number; size?: number; stroke?: number; label?: string; sub?: string; className?: string; testId?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const color = value >= 85 ? "#22D3EE" : value >= 70 ? "#5B5FEF" : value >= 50 ? "#F59E0B" : "#F43F5E";
  return (
    <div ref={ref} className={cn("relative inline-flex items-center justify-center", className)} data-testid={testId}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} className="stroke-muted" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={inView ? { strokeDashoffset: c - (c * value) / 100 } : {}}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
          style={{ filter: `drop-shadow(0 0 6px ${color}55)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-heading font-bold" style={{ fontSize: size / 3.4 }}>
          {label ?? <CountUp to={value} />}
        </span>
        {sub && <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{sub}</span>}
      </div>
    </div>
  );
}

/* Animated counter */
export function CountUp({ to, suffix = "", className }: { to: number; suffix?: string; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-20px" });
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const dur = 1100;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      setN(Math.round(to * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return (
    <span ref={ref} className={className}>
      {n}
      {suffix}
    </span>
  );
}

/* AI typing indicator */
export function TypingDots({ label = "Thinking" }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm text-muted-foreground" data-testid="typing-indicator">
      {label}
      <span className="flex gap-1">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="h-1.5 w-1.5 rounded-full bg-[#5B5FEF]"
            animate={{ y: [0, -4, 0], opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15 }}
          />
        ))}
      </span>
    </span>
  );
}

/* Empty state */
export function EmptyState({
  icon, title, subtitle, action, testId,
}: {
  icon: ReactNode; title: string; subtitle: string; action?: ReactNode; testId?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border py-14 text-center" data-testid={testId}>
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-accent text-[#5B5FEF]">{icon}</div>
      <p className="font-heading text-lg font-semibold">{title}</p>
      <p className="max-w-xs text-sm text-muted-foreground">{subtitle}</p>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/* Page header for app pages */
export function PageHeader({
  title, subtitle, actions, testId,
}: {
  title: string; subtitle?: string; actions?: ReactNode; testId?: string;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3" data-testid={testId}>
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

/* Animated progress bar */
export function ProgressBar({ value, className, color }: { value: number; className?: string; color?: string }) {
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-muted", className)}>
      <motion.div
        className="h-full rounded-full"
        style={{ background: color ?? "linear-gradient(90deg,#5B5FEF,#22D3EE)" }}
        initial={{ width: 0 }}
        whileInView={{ width: `${value}%` }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
      />
    </div>
  );
}

/* Section label used across landing + app */
export function SectionTag({ children }: { children: ReactNode }) {
  return (
    <span className="font-mono text-xs font-semibold uppercase tracking-[0.2em] text-[#22D3EE]">{children}</span>
  );
}
