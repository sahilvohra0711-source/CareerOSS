import { useRef, useState } from "react";
import { motion } from "motion/react";
import { Bot, SendHorizonal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TypingDots } from "@/components/career/bits";
import { careerCoachChat, streamCoach, type CoachCtx } from "@/services/ai";
import { useCareer } from "@/context/CareerContext";
import { cn } from "@/lib/utils";

interface Msg { from: "user" | "ai"; text: string; time: string }

const SUGGESTED = [
  "How can I improve my resume?",
  "What skills should I learn?",
  "How should I answer behavioral questions?",
  "How do I negotiate the Linear offer?",
];

const now = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

/* Minimal markdown for coach replies: **bold**, - bullets, 1. numbered lists */
function Md({ text }: { text: string }) {
  return (
    <>
      {text.split("\n").map((line, i) => {
        const inline = line.split(/(\*\*[^*]+\*\*)/g).map((seg, j) =>
          seg.startsWith("**") && seg.endsWith("**")
            ? <strong key={j} className="font-semibold">{seg.slice(2, -2)}</strong>
            : <span key={j}>{seg}</span>,
        );
        const bullet = line.match(/^\s*[-•]\s+(.*)$/);
        const numbered = line.match(/^\s*(\d+)\.\s+(.*)$/);
        if (bullet || numbered) {
          const body = (bullet?.[1] ?? numbered?.[2]) ?? "";
          const parts = body.split(/(\*\*[^*]+\*\*)/g).map((seg, j) =>
            seg.startsWith("**") && seg.endsWith("**")
              ? <strong key={j} className="font-semibold">{seg.slice(2, -2)}</strong>
              : <span key={j}>{seg}</span>,
          );
          return (
            <span key={i} className="mt-1 flex gap-2">
              <span className="shrink-0 text-[#5B5FEF]">{numbered ? `${numbered[1]}.` : "•"}</span>
              <span>{parts}</span>
            </span>
          );
        }
        return line.trim() ? <span key={i} className="block">{inline}</span> : <span key={i} className="block h-2" />;
      })}
    </>
  );
}

export function ChatCore({ compact = false }: { compact?: boolean }) {
  const { data } = useCareer();
  const [messages, setMessages] = useState<Msg[]>([
    { from: "ai", text: `Hey ${data.profile.firstName} — I'm Nova, your career coach. I can see your resume, tracker and skill gaps. What's on your mind?`, time: now() },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const scrollDown = () => setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 40);

  const send = async (text: string) => {
    const msg = text.trim();
    if (!msg || thinking) return;
    const ctx: CoachCtx = { readiness: data.readiness.overall, resumeScore: 92, apps: data.applications.length };
    const history = [...messages, { from: "user" as const, text: msg, time: now() }];
    setMessages(history);
    setInput("");
    setThinking(true);
    scrollDown();

    try {
      let streamed = false;
      await streamCoach(msg, history.slice(-7).map(({ from, text: t }) => ({ from, text: t })), ctx, (token) => {
        if (!streamed) {
          streamed = true;
          setThinking(false);
          setMessages((m) => [...m, { from: "ai", text: "", time: now() }]);
        }
        setMessages((m) => {
          const copy = [...m];
          const last = copy[copy.length - 1];
          copy[copy.length - 1] = { ...last, text: last.text + token };
          return copy;
        });
        scrollDown();
      });
      if (!streamed) throw new Error("empty stream");
    } catch {
      const reply = await careerCoachChat(msg, ctx);
      setMessages((m) => [...m, { from: "ai", text: reply, time: now() }]);
    } finally {
      setThinking(false);
      scrollDown();
    }
  };

  return (
    <div className={cn("flex flex-col", compact ? "h-[420px]" : "h-full")} data-testid="coach-chat">
      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        {messages.map((m, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className={cn("flex gap-2.5", m.from === "user" && "justify-end")}>
            {m.from === "ai" && (
              <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#5B5FEF] to-[#22D3EE] text-white">
                <Bot className="h-4 w-4" />
              </span>
            )}
            <div className={cn(
              "max-w-[85%] whitespace-pre-line rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
              m.from === "user" ? "rounded-br-md bg-[#5B5FEF] text-white" : "rounded-bl-md bg-muted",
            )}>
              {m.from === "ai" ? <Md text={m.text} /> : m.text}
              <span className={cn("mt-1 block text-[10px]", m.from === "user" ? "text-white/60" : "text-muted-foreground")}>{m.time}</span>
            </div>
          </motion.div>
        ))}
        {thinking && (
          <div className="flex gap-2.5">
            <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#5B5FEF] to-[#22D3EE] text-white">
              <Bot className="h-4 w-4" />
            </span>
            <div className="rounded-2xl rounded-bl-md bg-muted px-4 py-3">
              <TypingDots label="Thinking" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="border-t border-border p-3">
        {messages.length < 3 && (
          <div className="mb-2.5 flex flex-wrap gap-1.5">
            {SUGGESTED.map((q) => (
              <button key={q} onClick={() => void send(q)} data-testid={`coach-suggestion-${q.slice(4, 14).toLowerCase().replace(/\s/g, "-")}`}
                className="rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-[#5B5FEF]/50 hover:text-foreground">
                {q}
              </button>
            ))}
          </div>
        )}
        <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); void send(input); }}>
          <Input value={input} onChange={(e) => setInput(e.target.value)} data-testid="coach-input"
            placeholder="Ask about your resume, skills, interviews…" className="rounded-full" />
          <Button type="submit" size="icon" className="shrink-0 rounded-full" disabled={thinking || !input.trim()} data-testid="coach-send-btn" aria-label="Send message">
            <SendHorizonal className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
