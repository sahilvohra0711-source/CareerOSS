import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Bot, X } from "lucide-react";
import { ChatCore } from "./ChatCore";

export function FloatingCoach() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <motion.button
        onClick={() => setOpen((o) => !o)}
        whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.94 }}
        data-testid="floating-coach-btn"
        aria-label="Open AI Career Coach"
        className="fixed bottom-20 right-4 z-50 flex h-13 items-center gap-2 rounded-full bg-gradient-to-r from-[#5B5FEF] to-[#7C3AED] px-4 py-3 font-heading text-sm font-semibold text-white shadow-[0_12px_36px_-8px_rgba(91,95,239,0.7)] md:bottom-6 md:right-6"
      >
        <Bot className="h-5 w-5" />
        <span className="hidden sm:inline">Career Coach</span>
      </motion.button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.96 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="glass fixed bottom-36 right-4 z-50 flex w-[calc(100vw-2rem)] max-w-sm flex-col overflow-hidden rounded-3xl shadow-2xl md:bottom-24 md:right-6"
            data-testid="floating-coach-panel"
          >
            <div className="flex items-center gap-3 border-b border-border px-4 py-3">
              <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#5B5FEF] to-[#22D3EE] text-white">
                <Bot className="h-4.5 w-4.5" />
                <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-card bg-[#10B981]" />
              </span>
              <div className="flex-1">
                <p className="font-heading text-sm font-semibold">Nova · Career Coach</p>
                <p className="text-[11px] text-[#10B981]">Online — knows your workspace</p>
              </div>
              <button onClick={() => setOpen(false)} aria-label="Close coach" data-testid="floating-coach-close"
                className="rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            </div>
            <ChatCore compact />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
