import { useState } from "react";
import { Link, NavLink, Navigate, Outlet, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { motion } from "motion/react";
import {
  LayoutDashboard, FileText, Target, ScanSearch, PenLine, Briefcase, Building2,
  Mic, Brain, Map, Rocket, BarChart3, Bot, CalendarClock, Settings, Compass,
  Bell, LogOut, Menu, Moon, Sun, UserRound, CheckCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Logo, LogoMark } from "@/components/brand/Logo";
import { FloatingCoach } from "@/components/coach/FloatingCoach";
import { useCareer } from "@/context/CareerContext";
import { endSession, fetchMe, isDemo } from "@/lib/session";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/app", icon: LayoutDashboard, label: "Dashboard", end: true },
  { to: "/app/resumes", icon: FileText, label: "Resumes" },
  { to: "/app/matcher", icon: Target, label: "Job Matcher" },
  { to: "/app/ats", icon: ScanSearch, label: "ATS Analysis" },
  { to: "/app/tailor", icon: PenLine, label: "Resume Tailoring" },
  { to: "/app/applications", icon: Briefcase, label: "Applications" },
  { to: "/app/companies", icon: Building2, label: "Companies" },
  { to: "/app/jobs", icon: Compass, label: "Job Discovery" },
  { to: "/app/interview", icon: Mic, label: "Interview Prep" },
  { to: "/app/skills", icon: Brain, label: "Skills" },
  { to: "/app/roadmap", icon: Map, label: "Career Roadmap" },
  { to: "/app/projects", icon: Rocket, label: "Projects" },
  { to: "/app/analytics", icon: BarChart3, label: "Analytics" },
  { to: "/app/coach", icon: Bot, label: "AI Career Coach" },
  { to: "/app/reminders", icon: CalendarClock, label: "Reminders" },
  { to: "/app/settings", icon: Settings, label: "Settings" },
];

const MOBILE_NAV = [NAV[0], NAV[1], NAV[5], NAV[8], NAV[13]];

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="flex flex-1 flex-col gap-0.5 overflow-y-auto px-3 py-2" data-testid="sidebar-nav">
      {NAV.map((item) => (
        <NavLink
          key={item.to} to={item.to} end={item.end} onClick={onNavigate}
          data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
          className={({ isActive }) =>
            cn(
              "group flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition-colors",
              isActive
                ? "bg-gradient-to-r from-[#5B5FEF]/20 to-transparent text-foreground shadow-[inset_2px_0_0_#5B5FEF]"
                : "text-muted-foreground hover:bg-accent hover:text-foreground",
            )
          }
        >
          <item.icon className="h-[17px] w-[17px] shrink-0" />
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}

function SidebarBody({ onNavigate }: { onNavigate?: () => void }) {
  const { data } = useCareer();
  return (
    <div className="flex h-full flex-col bg-sidebar">
      <Link to="/app" className="flex h-16 items-center px-5"><Logo /></Link>
      <NavItems onNavigate={onNavigate} />
      <div className="border-t border-sidebar-border p-3">
        <Link to="/app/profile" className="flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-accent" data-testid="sidebar-profile-link">
          <img src={data.profile.avatarUrl} alt={data.profile.name} className="h-9 w-9 rounded-full object-cover ring-2 ring-[#5B5FEF]/40" />
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold">{data.profile.name}</span>
            <span className="block truncate text-xs text-muted-foreground">{data.profile.targetRole}</span>
          </span>
        </Link>
      </div>
    </div>
  );
}

function Notifications() {
  const { data, markAllRead } = useCareer();
  const unread = data.notifications.filter((n) => !n.read).length;
  const dot = { info: "#22D3EE", success: "#10B981", warning: "#F59E0B" };
  return (
    <Popover>
      <PopoverTrigger render={<Button variant="ghost" size="icon" className="relative rounded-full" aria-label="Notifications" data-testid="notifications-trigger" />}>
        <Bell className="h-[18px] w-[18px]" />
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#5B5FEF] text-[9px] font-bold text-white">
            {unread}
          </span>
        )}
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0" data-testid="notifications-panel">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="font-heading text-sm font-semibold">Notifications</p>
          <button onClick={markAllRead} data-testid="notifications-mark-read"
            className="flex items-center gap-1 text-xs text-[#5B5FEF] hover:underline">
            <CheckCheck className="h-3.5 w-3.5" /> Mark all read
          </button>
        </div>
        <div className="max-h-80 overflow-y-auto">
          {data.notifications.map((n) => (
            <div key={n.id} className={cn("flex gap-3 border-b border-border/60 px-4 py-3 text-sm", !n.read && "bg-accent/40")}>
              <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: dot[n.kind] }} />
              <div>
                <p className="leading-snug">{n.text}</p>
                <p className="mt-1 text-xs text-muted-foreground">{n.time}</p>
              </div>
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}

function Topbar({ demo }: { demo: boolean }) {
  const { theme, setTheme } = useTheme();
  const { data } = useCareer();
  const dark = theme !== "light";
  return (
    <header className="glass sticky top-0 z-40 flex h-16 items-center gap-2 px-4 sm:px-6" data-testid="app-topbar">
      <Sheet>
        <SheetTrigger render={<Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu" data-testid="mobile-menu-btn" />}>
          <Menu className="h-5 w-5" />
        </SheetTrigger>
        <SheetContent side="left" className="w-72 p-0">
          <SidebarBody />
        </SheetContent>
      </Sheet>

      <div className="hidden items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1.5 md:flex" data-testid="topbar-readiness">
        <span className="relative flex h-2 w-2">
          <span className="absolute h-full w-full animate-ping rounded-full bg-[#22D3EE] opacity-60" />
          <span className="relative h-2 w-2 rounded-full bg-[#22D3EE]" />
        </span>
        <span className="text-xs text-muted-foreground">Career Readiness</span>
        <span className="font-heading text-sm font-bold text-[#22D3EE]">{data.readiness.overall}/100</span>
      </div>
      {demo && (
        <span className="rounded-full border border-[#F59E0B]/40 bg-[#F59E0B]/10 px-3 py-1 text-[11px] font-semibold text-[#F59E0B]" data-testid="demo-badge">
          DEMO MODE
        </span>
      )}

      <div className="ml-auto flex items-center gap-1">
        <Button variant="ghost" size="icon" className="rounded-full" aria-label="Toggle theme" data-testid="app-theme-toggle"
          onClick={() => setTheme(dark ? "light" : "dark")}>
          {dark ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
        </Button>
        <Notifications />
        <DropdownMenu>
          <DropdownMenuTrigger render={<button className="ml-1 rounded-full outline-none focus-visible:ring-2 focus-visible:ring-[#5B5FEF]" aria-label="Account menu" data-testid="avatar-menu-trigger" />}>
            <img src={data.profile.avatarUrl} alt={data.profile.name} className="h-9 w-9 rounded-full object-cover ring-2 ring-[#5B5FEF]/40" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <div className="px-3 py-2">
              <p className="text-sm font-semibold">{data.profile.name}</p>
              <p className="truncate text-xs text-muted-foreground">{data.profile.email}</p>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem render={<Link to="/app/profile" />}>
              <UserRound className="mr-2 h-4 w-4" /> Profile
            </DropdownMenuItem>
            <DropdownMenuItem render={<Link to="/app/settings" />}>
              <Settings className="mr-2 h-4 w-4" /> Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive" data-testid="logout-btn" onClick={() => void endSession()}>
              <LogOut className="mr-2 h-4 w-4" /> {demo ? "Exit demo" : "Log out"}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

export default function AppShell() {
  const demo = isDemo();
  const location = useLocation();
  const { isLoading, isError } = useQuery({
    queryKey: ["me"],
    queryFn: fetchMe,
    retry: false,
    staleTime: Infinity,
    enabled: !demo,
  });

  if (!demo && isLoading)
    return (
      <div className="flex h-screen flex-col items-center justify-center gap-4 bg-background" data-testid="app-loading">
        <LogoMark className="h-12 w-12 animate-pulse" />
        <p className="text-sm text-muted-foreground">Loading your workspace…</p>
      </div>
    );
  if (!demo && isError) return <Navigate to="/login" replace />;

  return (
    <div className="flex h-screen overflow-hidden bg-background" data-testid="app-shell">
      <aside className="hidden w-[268px] shrink-0 border-r border-sidebar-border md:block">
        <SidebarBody />
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar demo={demo} />
        <main className="flex-1 overflow-y-auto pb-24 md:pb-8">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="mx-auto max-w-[1400px] p-4 sm:p-6"
          >
            <Outlet />
          </motion.div>
        </main>
        <nav className="glass fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-border py-2 md:hidden" data-testid="mobile-bottom-nav">
          {MOBILE_NAV.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end}
              data-testid={`mobile-nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
              className={({ isActive }) =>
                cn("flex flex-col items-center gap-0.5 rounded-lg px-3 py-1 text-[10px]",
                  isActive ? "text-[#5B5FEF]" : "text-muted-foreground")
              }>
              <item.icon className="h-5 w-5" />
              {item.label.split(" ")[0]}
            </NavLink>
          ))}
        </nav>
      </div>
      {location.pathname !== "/app/coach" && <FloatingCoach />}
    </div>
  );
}
