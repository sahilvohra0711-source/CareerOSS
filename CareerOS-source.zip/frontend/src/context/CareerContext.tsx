import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type {
  AppNotification, CareerState, Company, InterviewSession, JobApplication,
  Profile, Project, Reminder, Resume, Skill,
} from "@/lib/types";
import { seedState } from "@/data/demo";

const KEY = "careeros-state-v1";

function load(): CareerState {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...seedState(), ...JSON.parse(raw) };
  } catch { /* corrupted state -> reseed */ }
  return seedState();
}

interface CareerCtx {
  data: CareerState;
  patch: (p: Partial<CareerState>) => void;
  updateProfile: (p: Partial<Profile>) => void;
  saveResume: (r: Resume) => void;
  deleteResume: (id: string) => void;
  duplicateResume: (id: string) => void;
  saveApplication: (a: JobApplication) => void;
  deleteApplication: (id: string) => void;
  saveCompany: (c: Company) => void;
  deleteCompany: (id: string) => void;
  saveProject: (p: Project) => void;
  deleteProject: (id: string) => void;
  saveReminder: (r: Reminder) => void;
  deleteReminder: (id: string) => void;
  saveSkill: (s: Skill) => void;
  deleteSkill: (name: string) => void;
  addSession: (s: InterviewSession) => void;
  addActivity: (text: string) => void;
  pushNotification: (text: string, kind?: AppNotification["kind"]) => void;
  markAllRead: () => void;
  resetDemo: () => void;
}

const Ctx = createContext<CareerCtx | null>(null);

const uid = () => crypto.randomUUID().slice(0, 8);

export function CareerProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<CareerState>(load);

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(data));
  }, [data]);

  const value = useMemo<CareerCtx>(() => {
    const upsert = <T extends { id: string }>(list: T[], item: T) => {
      const i = list.findIndex((x) => x.id === item.id);
      return i >= 0 ? list.map((x) => (x.id === item.id ? item : x)) : [item, ...list];
    };
    return {
      data,
      patch: (p) => setData((d) => ({ ...d, ...p })),
      updateProfile: (p) => setData((d) => ({ ...d, profile: { ...d.profile, ...p } })),
      saveResume: (r) => setData((d) => ({ ...d, resumes: upsert(d.resumes, { ...r, updatedAt: new Date().toISOString().slice(0, 10) }) })),
      deleteResume: (id) => setData((d) => ({ ...d, resumes: d.resumes.filter((r) => r.id !== id) })),
      duplicateResume: (id) =>
        setData((d) => {
          const src = d.resumes.find((r) => r.id === id);
          if (!src) return d;
          return { ...d, resumes: [{ ...src, id: uid(), name: `${src.name} (copy)`, updatedAt: new Date().toISOString().slice(0, 10) }, ...d.resumes] };
        }),
      saveApplication: (a) => setData((d) => ({ ...d, applications: upsert(d.applications, a) })),
      deleteApplication: (id) => setData((d) => ({ ...d, applications: d.applications.filter((a) => a.id !== id) })),
      saveCompany: (c) => setData((d) => ({ ...d, companies: upsert(d.companies, c) })),
      deleteCompany: (id) => setData((d) => ({ ...d, companies: d.companies.filter((c) => c.id !== id) })),
      saveProject: (p) => setData((d) => ({ ...d, projects: upsert(d.projects, p) })),
      deleteProject: (id) => setData((d) => ({ ...d, projects: d.projects.filter((p) => p.id !== id) })),
      saveReminder: (r) => setData((d) => ({ ...d, reminders: upsert(d.reminders, r) })),
      deleteReminder: (id) => setData((d) => ({ ...d, reminders: d.reminders.filter((r) => r.id !== id) })),
      saveSkill: (s) =>
        setData((d) => {
          const i = d.skills.findIndex((x) => x.name === s.name);
          return { ...d, skills: i >= 0 ? d.skills.map((x) => (x.name === s.name ? s : x)) : [...d.skills, s] };
        }),
      deleteSkill: (name) => setData((d) => ({ ...d, skills: d.skills.filter((s) => s.name !== name) })),
      addSession: (s) => setData((d) => ({ ...d, sessions: [s, ...d.sessions].slice(0, 20) })),
      addActivity: (text) => setData((d) => ({ ...d, activities: [{ id: uid(), text, date: "Today" }, ...d.activities].slice(0, 20) })),
      pushNotification: (text, kind = "info") =>
        setData((d) => ({ ...d, notifications: [{ id: uid(), text, kind, time: "Just now", read: false }, ...d.notifications].slice(0, 20) })),
      markAllRead: () => setData((d) => ({ ...d, notifications: d.notifications.map((n) => ({ ...n, read: true })) })),
      resetDemo: () => setData(seedState()),
    };
  }, [data]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCareer() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCareer must be used inside CareerProvider");
  return ctx;
}
