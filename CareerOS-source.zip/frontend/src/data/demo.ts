import type { CareerState, Resume } from "@/lib/types";

export const ALEX_AVATAR =
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMjd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMHRlY2glMjBsZWFkZXJ8ZW58MHx8fHwxNzkwNDQyNjAzfDA&ixlib=rb-4.1.0&q=85";
export const INTERVIEWER_AVATAR =
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMjd8MHwxfHNlYXJjaHwzfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMHRlY2glMjBsZWFkZXJ8ZW58MHx8fHwxNzkwNDQyNjAzfDA&ixlib=rb-4.1.0&q=85";

const uid = () => crypto.randomUUID().slice(0, 8);

const resumeMain: Resume = {
  id: "r-main",
  name: "Software Engineer — Modern",
  template: "modern",
  updatedAt: "2026-07-03",
  personal: {
    fullName: "Alex Morgan",
    title: "Software Engineer",
    email: "alex.morgan@demo.dev",
    phone: "(415) 555-0132",
    location: "San Francisco, CA",
    website: "alexmorgan.dev",
    linkedin: "linkedin.com/in/alexmorgan",
  },
  summary:
    "Software engineer with 4+ years building high-traffic web platforms. Shipped checkout and payments features used by 2M+ monthly users and cut p95 API latency 40% at a fintech scale-up. Focused on React, TypeScript, Node.js and distributed systems.",
  experience: [
    {
      id: uid(),
      company: "Nova Payments",
      role: "Software Engineer II",
      location: "San Francisco, CA",
      start: "2022",
      end: "Present",
      current: true,
      bullets: [
        "Led rebuild of checkout micro-frontend in React + TypeScript, lifting conversion 12% for 2M+ monthly users.",
        "Cut p95 API latency 40% by introducing Redis caching and query optimization across 6 Node.js services.",
        "Designed event-driven invoice pipeline (Kafka, Postgres) processing $30M+ in monthly volume.",
        "Mentored 4 engineers and introduced an RFC review culture that raised deploy frequency 3x.",
      ],
    },
    {
      id: uid(),
      company: "Cloudhaven",
      role: "Software Engineer",
      location: "Remote",
      start: "2021",
      end: "2022",
      bullets: [
        "Built multi-tenant analytics dashboard in React and D3 used by 300+ B2B customers.",
        "Shipped REST and GraphQL APIs in Node.js; wrote 500+ tests, raising coverage to 85%.",
        "Migrated legacy monolith modules to AWS Lambda, reducing infra cost 28%.",
      ],
    },
    {
      id: uid(),
      company: "Brightlab",
      role: "Junior Developer",
      location: "Davis, CA",
      start: "2020",
      end: "2021",
      bullets: [
        "Developed marketing sites and internal tools in JavaScript and Python.",
        "Automated weekly reporting with SQL scripts, saving the ops team 10 hours per week.",
      ],
    },
  ],
  projects: [
    {
      id: uid(),
      name: "CareerOS",
      description:
        "All-in-one career workspace with AI resume analysis, job matching and mock interviews.",
      tech: ["React", "TypeScript", "FastAPI", "MongoDB"],
      url: "github.com/alexmorgan/careeros",
    },
    {
      id: uid(),
      name: "Pulseboard",
      description: "Real-time uptime monitoring dashboard with alerting and status pages.",
      tech: ["Next.js", "WebSockets", "Postgres"],
      url: "github.com/alexmorgan/pulseboard",
    },
  ],
  skills: [
    "JavaScript", "TypeScript", "React", "Node.js", "SQL", "PostgreSQL", "GraphQL",
    "Redis", "AWS", "Docker", "Git", "REST APIs", "Testing", "CI/CD",
  ],
  education: [
    {
      id: uid(),
      school: "UC Davis",
      degree: "B.S.",
      field: "Computer Science",
      start: "2016",
      end: "2020",
    },
  ],
  certifications: [
    { id: uid(), name: "AWS Certified Developer – Associate", issuer: "Amazon Web Services", year: "2023" },
  ],
  achievements: [
    "Hackathon winner — TechCrunch Disrupt 2022 (team of 4)",
    "Speaker, SF React meetup: “Streaming SSR in production”",
  ],
};

const resumeFrontend: Resume = {
  ...resumeMain,
  id: "r-frontend",
  name: "Frontend Engineer — Minimal",
  template: "minimal",
  updatedAt: "2026-06-21",
  summary:
    "Frontend-leaning software engineer who loves shipping polished, fast product UI. Deep React and TypeScript experience across fintech and B2B SaaS.",
  personal: { ...resumeMain.personal, title: "Frontend Engineer" },
};

export function seedState(): CareerState {
  return {
    profile: {
      name: "Alex Morgan",
      firstName: "Alex",
      email: "alex.morgan@demo.dev",
      targetRole: "Software Engineer",
      location: "San Francisco, CA",
      experience: "4 years",
      linkedin: "linkedin.com/in/alexmorgan",
      github: "github.com/alexmorgan",
      portfolio: "alexmorgan.dev",
      avatarUrl: ALEX_AVATAR,
    },
    resumes: [resumeMain, resumeFrontend],
    applications: [
      { id: uid(), company: "Stripe", position: "Full Stack Engineer", location: "Remote", salary: "$160k–220k", appliedDate: "2026-06-30", nextAction: "Technical round — Jul 10", status: "interview", match: 94, notes: "Recruiter: Sarah Kim. Panel of 2, expect React + system design." },
      { id: uid(), company: "Google", position: "Software Engineer, L4", location: "Mountain View, CA", salary: "$150k–210k", appliedDate: "2026-06-28", nextAction: "Onsite loop — Jul 14", status: "interview", match: 91, notes: "Hiring manager: D. Patel. Brush up graphs + behavioral." },
      { id: uid(), company: "Microsoft", position: "Frontend Engineer", location: "Redmond (Remote)", salary: "$140k–190k", appliedDate: "2026-07-01", nextAction: "Recruiter call — Jul 9", status: "screening", match: 88 },
      { id: uid(), company: "Shopify", position: "Frontend Engineer", location: "Remote", salary: "$135k–180k", appliedDate: "2026-06-25", nextAction: "Take-home due — Jul 12", status: "screening", match: 86 },
      { id: uid(), company: "Amazon", position: "Software Development Engineer", location: "Seattle, WA", salary: "$145k–200k", appliedDate: "2026-07-02", status: "applied", match: 84 },
      { id: uid(), company: "Airbnb", position: "Software Engineer", location: "San Francisco, CA", salary: "$155k–205k", appliedDate: "2026-07-05", status: "applied", match: 89 },
      { id: uid(), company: "Linear", position: "Product Engineer", location: "Remote", salary: "$150k–190k", appliedDate: "2026-06-18", nextAction: "Offer call — Jul 8", status: "offer", match: 95, notes: "Offer: $165k base + equity. Decision by Jul 15." },
      { id: uid(), company: "Notion", position: "Product Engineer", location: "San Francisco, CA", salary: "$150k–200k", appliedDate: "", status: "saved", match: 90 },
      { id: uid(), company: "Figma", position: "Software Engineer", location: "San Francisco, CA", salary: "$160k–215k", appliedDate: "", status: "saved", match: 87 },
      { id: uid(), company: "Datadog", position: "Backend Engineer", location: "New York, NY", salary: "$150k–195k", appliedDate: "2026-06-10", status: "rejected", match: 78, notes: "Rejected after screen — wanted deeper Go experience." },
      { id: uid(), company: "Coinbase", position: "Software Engineer", location: "Remote", salary: "$150k–200k", appliedDate: "2026-05-30", status: "rejected", match: 74 },
    ],
    companies: [
      { id: uid(), name: "Stripe", position: "Full Stack Engineer", location: "Remote", salary: "$160k–220k", url: "stripe.com/jobs", appliedDate: "2026-06-30", contact: "Sarah Kim — sarah.k@stripe.com", notes: "Strong mission fit. Team owns checkout infra. Follow up after technical round.", status: "interview" },
      { id: uid(), name: "Google", position: "Software Engineer, L4", location: "Mountain View, CA", salary: "$150k–210k", url: "careers.google.com", appliedDate: "2026-06-28", contact: "David Patel — Hiring Manager", notes: "Onsite July 14: 2 coding, 1 system design, 1 behavioral.", status: "interview" },
      { id: uid(), name: "Notion", position: "Product Engineer", location: "San Francisco, CA", salary: "$150k–200k", url: "notion.so/careers", appliedDate: "", contact: "", notes: "Dream company. Waiting for new grad+ req to reopen; tailor resume first.", status: "saved" },
      { id: uid(), name: "Figma", position: "Software Engineer", location: "San Francisco, CA", salary: "$160k–215k", url: "figma.com/careers", appliedDate: "", contact: "Mia Torres — Recruiter (LinkedIn)", notes: "Met recruiter at Config. Send portfolio after resume update.", status: "saved" },
    ],
    jobs: [
      { id: uid(), title: "Software Engineer", company: "TechCorp", location: "Remote", salary: "$85k–110k", match: 92, tags: ["React", "Node.js", "SQL"], posted: "2d ago", type: "Full-time" },
      { id: uid(), title: "Full Stack Engineer", company: "Stripe", location: "Remote", salary: "$160k–220k", match: 94, tags: ["React", "TypeScript", "Ruby"], posted: "1d ago", type: "Full-time" },
      { id: uid(), title: "Frontend Engineer", company: "Vercel", location: "Remote", salary: "$140k–190k", match: 90, tags: ["Next.js", "React", "TypeScript"], posted: "3d ago", type: "Full-time" },
      { id: uid(), title: "Software Engineer II", company: "Anthropic", location: "San Francisco, CA", salary: "$180k–260k", match: 81, tags: ["Python", "React", "Distributed Systems"], posted: "5d ago", type: "Full-time" },
      { id: uid(), title: "Product Engineer", company: "Linear", location: "Remote", salary: "$150k–190k", match: 95, tags: ["TypeScript", "React", "GraphQL"], posted: "1w ago", type: "Full-time" },
      { id: uid(), title: "Backend Engineer", company: "Datadog", location: "New York, NY", salary: "$150k–195k", match: 76, tags: ["Go", "Kafka", "Kubernetes"], posted: "4d ago", type: "Full-time" },
      { id: uid(), title: "Software Engineer, Web", company: "Figma", location: "San Francisco, CA", salary: "$160k–215k", match: 87, tags: ["TypeScript", "React", "WebGL"], posted: "6d ago", type: "Full-time" },
      { id: uid(), title: "Full Stack Developer", company: "Ramp", location: "New York (Hybrid)", salary: "$145k–200k", match: 85, tags: ["React", "Python", "Postgres"], posted: "2d ago", type: "Full-time" },
    ],
    projects: [
      { id: uid(), name: "CareerOS", description: "All-in-one career workspace: AI resume analysis, job matching, mock interviews and application tracking.", tech: ["React", "TypeScript", "FastAPI", "MongoDB"], github: "github.com/alexmorgan/careeros", demo: "careeros.alexmorgan.dev", role: "Solo builder", achievements: ["Designed 12 connected product modules", "Mock-AI engine with deterministic scoring heuristics"] },
      { id: uid(), name: "Pulseboard", description: "Real-time uptime monitoring with alerting, status pages and incident timelines.", tech: ["Next.js", "WebSockets", "Postgres"], github: "github.com/alexmorgan/pulseboard", demo: "pulseboard.dev", role: "Lead developer", achievements: ["1.2k GitHub stars", "Handles 40k checks/day on a $20 VPS"] },
      { id: uid(), name: "Devfolio CLI", description: "CLI that turns a GitHub profile into a polished portfolio site in one command.", tech: ["Node.js", "TypeScript"], github: "github.com/alexmorgan/devfolio", role: "Creator", achievements: ["400+ weekly npm downloads"] },
    ],
    reminders: [
      { id: uid(), title: "Follow up with Sarah (Stripe recruiter)", date: "2026-07-09", type: "follow-up", done: false, note: "Thank her for the loop schedule; ask about team placement." },
      { id: uid(), title: "Prepare for Google onsite", date: "2026-07-13", type: "interview", done: false, note: "2 coding + 1 system design + 1 behavioral. Do 2 mock interviews." },
      { id: uid(), title: "Submit Netflix application", date: "2026-07-11", type: "application", done: false },
      { id: uid(), title: "Send thank-you note to Microsoft", date: "2026-07-07", type: "follow-up", done: true },
    ],
    notifications: [
      { id: uid(), text: "Resume match increased to 94% for Stripe — Full Stack Engineer.", kind: "info", time: "2h ago", read: false },
      { id: uid(), text: "Interview preparation completed: Technical set, score 84/100.", kind: "success", time: "5h ago", read: false },
      { id: uid(), text: "Follow up with your Stripe recruiter tomorrow.", kind: "warning", time: "1d ago", read: false },
      { id: uid(), text: "New skill recommendation available: System Design.", kind: "info", time: "2d ago", read: true },
    ],
    activities: [
      { id: uid(), text: "Updated resume “Software Engineer — Modern”", date: "Today" },
      { id: uid(), text: "Applied to Software Engineer at TechCorp", date: "Yesterday" },
      { id: uid(), text: "Completed mock interview — Technical (84/100)", date: "2 days ago" },
      { id: uid(), text: "Added project “Pulseboard” to portfolio", date: "5 days ago" },
      { id: uid(), text: "Tailored resume for Stripe — Full Stack Engineer", date: "1 week ago" },
    ],
    skills: [
      { name: "JavaScript", level: 92, tag: "Advanced" },
      { name: "React", level: 90, tag: "Advanced" },
      { name: "TypeScript", level: 78, tag: "Intermediate" },
      { name: "Node.js", level: 74, tag: "Intermediate" },
      { name: "SQL", level: 70, tag: "Intermediate" },
      { name: "AWS", level: 45, tag: "Beginner", recommended: true },
      { name: "Docker", level: 52, tag: "Beginner", recommended: true },
      { name: "System Design", level: 58, tag: "Beginner", recommended: true },
    ],
    roadmap: [
      { id: uid(), title: "HTML / CSS", status: "done" },
      { id: uid(), title: "JavaScript", status: "done" },
      { id: uid(), title: "React", status: "done" },
      { id: uid(), title: "TypeScript", status: "current" },
      { id: uid(), title: "Testing", status: "next" },
      { id: uid(), title: "Advanced React", status: "upcoming" },
      { id: uid(), title: "Node.js Deep Dive", status: "upcoming" },
      { id: uid(), title: "System Design", status: "upcoming" },
    ],
    sessions: [
      {
        id: uid(), jobTitle: "Software Engineer", type: "Technical", level: "Mid", date: "2026-07-04", mode: "Mock interview",
        overall: 84,
        answers: [],
      },
    ],
    readiness: {
      overall: 87,
      breakdown: [
        { label: "Resume", value: 92 },
        { label: "Skills", value: 84 },
        { label: "Projects", value: 89 },
        { label: "Interview Prep", value: 76 },
        { label: "Applications", value: 83 },
      ],
    },
  };
}

export const SAMPLE_JD = `Senior Software Engineer — TechCorp (Remote)

We're looking for a Senior Software Engineer to build customer-facing web applications at scale.

What you'll do:
- Design and build features end-to-end with React, TypeScript and Node.js
- Build and consume REST APIs and GraphQL services backed by PostgreSQL
- Own services running on AWS with Docker and Kubernetes, deployed via CI/CD
- Write tests, review code, and mentor junior engineers
- Collaborate in an Agile team with product and design

Requirements:
- 4+ years of professional software engineering experience
- Strong JavaScript/TypeScript and React skills
- Experience with SQL databases (PostgreSQL preferred)
- Familiarity with AWS, Docker, CI/CD pipelines
- Bonus: Redis, Kafka, system design experience`;
