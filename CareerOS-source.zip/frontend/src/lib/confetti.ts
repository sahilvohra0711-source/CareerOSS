import confetti from "canvas-confetti";

export const celebrate = () =>
  confetti({
    particleCount: 90,
    spread: 70,
    origin: { y: 0.7 },
    colors: ["#5B5FEF", "#7C3AED", "#22D3EE"],
  });
