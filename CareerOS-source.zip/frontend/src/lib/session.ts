// Session boundary: auth is an httpOnly cookie the backend owns; the frontend's one
// duty is wiping the react-query cache so one account's data never renders for the next.
import { queryClient } from "./queryClient";
import { apiGet, apiPost, ApiError } from "./api";

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  role?: string;
}

const DEMO_KEY = "careeros-demo";

export const isDemo = () => localStorage.getItem(DEMO_KEY) === "1";
export const startDemo = () => localStorage.setItem(DEMO_KEY, "1");
export const endDemo = () => localStorage.removeItem(DEMO_KEY);

export const fetchMe = () => apiGet<SessionUser>("/auth/me");
export const login = (email: string, password: string) =>
  apiPost<SessionUser>("/auth/login", { email, password });
export const register = (name: string, email: string, password: string) =>
  apiPost<SessionUser>("/auth/register", { name, email, password });
export const forgotPassword = (email: string) =>
  apiPost<{ ok: boolean }>("/auth/forgot-password", { email });

// Call after every successful login/signup.
export function beginSession(): void {
  queryClient.clear();
}

// Call from every sign-out control; the hard redirect resets all in-memory state.
export async function endSession(redirectTo: string = "/"): Promise<void> {
  endDemo();
  try {
    await apiPost("/auth/logout");
  } finally {
    queryClient.clear();
    window.location.assign(redirectTo);
  }
}

export function formatApiError(err: unknown): string {
  if (err instanceof ApiError) {
    const detail = (err.body as { detail?: unknown } | null)?.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail))
      return detail
        .map((e) => (e && typeof e.msg === "string" ? e.msg : ""))
        .filter(Boolean)
        .join(" ");
  }
  return "Something went wrong. Try the demo instead.";
}
