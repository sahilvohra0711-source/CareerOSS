export type Theme = "dark" | "light";

export interface Profile {
  name: string;
  firstName: string;
  email: string;
  targetRole: string;
  location: string;
  experience: string;
  linkedin: string;
  github: string;
  portfolio: string;
  avatarUrl: string;
}

export interface Education {
  id: string;
  school: string;
  degree: string;
  field: string;
  start: string;
  end: string;
}

export interface Experience {
  id: string;
  company: string;
  role: string;
  location: string;
  start: string;
  end: string;
  current?: boolean;
  bullets: string[];
}

export interface ResumeProject {
  id: string;
  name: string;
  description: string;
  tech: string[];
  url?: string;
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  year: string;
}

export type ResumeTemplate = "modern" | "minimal" | "professional" | "tech" | "executive";

export interface Resume {
  id: string;
  name: string;
  template: ResumeTemplate;
  updatedAt: string;
  personal: {
    fullName: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    website: string;
    linkedin: string;
  };
  summary: string;
  education: Education[];
  experience: Experience[];
  projects: ResumeProject[];
  skills: string[];
  certifications: Certification[];
  achievements: string[];
}

export type AppStatus = "saved" | "applied" | "screening" | "interview" | "offer" | "rejected";

export interface JobApplication {
  id: string;
  company: string;
  position: string;
  location: string;
  salary: string;
  appliedDate: string;
  nextAction?: string;
  status: AppStatus;
  notes?: string;
  match?: number;
}

export interface Company {
  id: string;
  name: string;
  position: string;
  location: string;
  salary: string;
  url: string;
  appliedDate: string;
  contact: string;
  notes: string;
  status: AppStatus;
}

export interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  match: number;
  tags: string[];
  posted: string;
  type: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  tech: string[];
  github?: string;
  demo?: string;
  role: string;
  achievements: string[];
}

export interface Reminder {
  id: string;
  title: string;
  date: string;
  type: "follow-up" | "application" | "interview" | "other";
  done: boolean;
  note?: string;
}

export interface AppNotification {
  id: string;
  text: string;
  kind: "info" | "success" | "warning";
  time: string;
  read: boolean;
}

export interface Activity {
  id: string;
  text: string;
  date: string;
}

export interface Skill {
  name: string;
  level: number;
  tag: "Advanced" | "Intermediate" | "Beginner";
  recommended?: boolean;
}

export interface RoadmapItem {
  id: string;
  title: string;
  status: "done" | "current" | "next" | "upcoming";
}

export interface AnswerScores {
  clarity: number;
  depth: number;
  structure: number;
  impact: number;
  overall: number;
}

export type Reaction = "excellent" | "strong" | "average" | "weak";

export interface InterviewAnswer {
  question: string;
  answer: string;
  scores: AnswerScores;
  feedback: string;
  reaction: Reaction;
}

export interface InterviewSession {
  id: string;
  jobTitle: string;
  type: string;
  level: string;
  date: string;
  mode: string;
  answers: InterviewAnswer[];
  overall: number;
}

export interface Readiness {
  overall: number;
  breakdown: { label: string; value: number }[];
}

export interface CareerState {
  profile: Profile;
  resumes: Resume[];
  applications: JobApplication[];
  companies: Company[];
  jobs: JobListing[];
  projects: Project[];
  reminders: Reminder[];
  notifications: AppNotification[];
  activities: Activity[];
  skills: Skill[];
  roadmap: RoadmapItem[];
  sessions: InterviewSession[];
  readiness: Readiness;
}
