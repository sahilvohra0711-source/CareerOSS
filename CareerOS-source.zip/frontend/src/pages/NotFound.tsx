import { Link, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowLeft, Compass, PlayCircle } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { LogoMark } from "@/components/brand/Logo";
import { startDemo } from "@/lib/session";

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="hero-aurora relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-background px-6 text-center" data-testid="not-found-page">
      <div className="bg-grid absolute inset-0" aria-hidden />
      <motion.div
        initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative"
      >
        <LogoMark className="mx-auto h-14 w-14" />
        <p className="mt-8 font-mono text-xs font-semibold uppercase tracking-[0.25em] text-[#22D3EE]">404 — Off the roadmap</p>
        <h1 className="mt-3 font-heading text-4xl font-bold tracking-tight sm:text-5xl">
          This page isn't on your<br className="hidden sm:block" /> career path.
        </h1>
        <p className="mx-auto mt-4 max-w-md text-muted-foreground">
          The link may be mistyped or moved. Your next opportunity is one click away — the live demo needs no account.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link to="/" data-testid="not-found-home" className={buttonVariants({ variant: "outline", size: "lg" }) + " rounded-full px-6"}>
            <ArrowLeft className="mr-1 h-4 w-4" /> Back to home
          </Link>
          <Button size="lg" data-testid="not-found-demo" className="rounded-full px-6"
            onClick={() => { startDemo(); navigate("/app"); }}>
            <PlayCircle className="mr-1 h-4 w-4" /> Try Interactive Demo
          </Button>
        </div>
        <p className="mt-10 flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <Compass className="h-3.5 w-3.5" /> CareerOS — your career. One intelligent workspace.
        </p>
      </motion.div>
    </div>
  );
}
