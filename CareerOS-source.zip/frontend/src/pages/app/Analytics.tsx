import { Briefcase, Mic, Target, TrendingUp } from "lucide-react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart,
  PolarAngleAxis, PolarGrid, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { CountUp, PageHeader } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";

const WEEK = [
  { w: "W1", apps: 2, responses: 1 }, { w: "W2", apps: 4, responses: 1 },
  { w: "W3", apps: 3, responses: 2 }, { w: "W4", apps: 6, responses: 2 },
  { w: "W5", apps: 5, responses: 3 }, { w: "W6", apps: 8, responses: 4 },
  { w: "W7", apps: 7, responses: 3 }, { w: "W8", apps: 9, responses: 5 },
];

const STATUS_TONE: Record<string, string> = {
  saved: "#94A3B8", applied: "#5B5FEF", screening: "#22D3EE",
  interview: "#7C3AED", offer: "#10B981", rejected: "#F43F5E",
};

export default function Analytics() {
  const { data } = useCareer();
  const statusData = Object.entries(
    data.applications.reduce<Record<string, number>>((acc, a) => {
      acc[a.status] = (acc[a.status] ?? 0) + 1;
      return acc;
    }, {}),
  ).map(([name, value]) => ({ name: name[0].toUpperCase() + name.slice(1), value, tone: STATUS_TONE[name] }));

  const matchData = data.jobs.slice(0, 6).map((j) => ({ name: j.company, match: j.match }));
  const avgMatch = Math.round(data.jobs.reduce((s, j) => s + j.match, 0) / Math.max(1, data.jobs.length));

  const stats = [
    { icon: Briefcase, label: "Applications", value: 24, suffix: "" },
    { icon: Mic, label: "Interviews", value: 6, suffix: "" },
    { icon: TrendingUp, label: "Response rate", value: 31, suffix: "%" },
    { icon: Target, label: "Avg. job match", value: avgMatch, suffix: "%" },
  ];

  return (
    <div data-testid="analytics-page">
      <PageHeader title="Analytics" subtitle="Your job search, measured — so you can improve it." testId="analytics-header" />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-4" data-testid={`analytics-${s.label.toLowerCase().replace(/[\s.]+/g, "-")}`}>
            <div className="flex items-center justify-between">
              <s.icon className="h-4 w-4 text-[#5B5FEF]" />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</span>
            </div>
            <p className="mt-2 font-heading text-2xl font-bold"><CountUp to={s.value} suffix={s.suffix} /></p>
          </div>
        ))}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <div className="rounded-3xl border border-border bg-card p-6" data-testid="chart-momentum">
          <h2 className="mb-1 font-heading text-lg font-semibold">Applications vs. responses</h2>
          <p className="mb-4 text-xs text-muted-foreground">Weekly, last 8 weeks</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={WEEK} margin={{ left: -24, right: 8, top: 4 }}>
                <defs>
                  <linearGradient id="aApps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#5B5FEF" stopOpacity={0.5} /><stop offset="100%" stopColor="#5B5FEF" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="aResp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22D3EE" stopOpacity={0.5} /><stop offset="100%" stopColor="#22D3EE" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(128,140,170,0.15)" vertical={false} />
                <XAxis dataKey="w" tick={{ fontSize: 11 }} stroke="rgba(128,140,170,0.4)" tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} stroke="rgba(128,140,170,0.4)" tickLine={false} axisLine={false} />
                <Tooltip formatter={(v: number, n: string) => [v, n === "apps" ? "Applications" : "Responses"]} />
                <Area type="monotone" dataKey="apps" stroke="#5B5FEF" strokeWidth={2.5} fill="url(#aApps)" />
                <Area type="monotone" dataKey="responses" stroke="#22D3EE" strokeWidth={2.5} fill="url(#aResp)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card p-6" data-testid="chart-pipeline">
          <h2 className="mb-1 font-heading text-lg font-semibold">Pipeline by stage</h2>
          <p className="mb-4 text-xs text-muted-foreground">{data.applications.length} tracked applications</p>
          <div className="flex h-64 items-center">
            <ResponsiveContainer width="55%" height="100%">
              <PieChart>
                <Pie data={statusData} dataKey="value" innerRadius="55%" outerRadius="85%" paddingAngle={3} strokeWidth={0}>
                  {statusData.map((s) => <Cell key={s.name} fill={s.tone} />)}
                </Pie>
                <Tooltip formatter={(v: number, n: string) => [v, n]} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2">
              {statusData.map((s) => (
                <div key={s.name} className="flex items-center gap-2 text-sm">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.tone }} />
                  <span className="text-muted-foreground">{s.name}</span>
                  <span className="ml-auto font-mono text-xs">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card p-6" data-testid="chart-matches">
          <h2 className="mb-1 font-heading text-lg font-semibold">Match score by open role</h2>
          <p className="mb-4 text-xs text-muted-foreground">Where to focus your tailoring energy</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={matchData} margin={{ left: -24, right: 8, top: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(128,140,170,0.15)" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="rgba(128,140,170,0.4)" tickLine={false} axisLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="rgba(128,140,170,0.4)" tickLine={false} axisLine={false} />
                <Tooltip formatter={(v: number) => [`${v}%`, "Match"]} />
                <Bar dataKey="match" radius={[6, 6, 0, 0]}>
                  {matchData.map((m, i) => <Cell key={i} fill={m.match >= 90 ? "#22D3EE" : "#5B5FEF"} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card p-6" data-testid="chart-readiness">
          <h2 className="mb-1 font-heading text-lg font-semibold">Readiness radar</h2>
          <p className="mb-4 text-xs text-muted-foreground">Balanced profiles convert better</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={data.readiness.breakdown} outerRadius="75%">
                <PolarGrid stroke="rgba(128,140,170,0.2)" />
                <PolarAngleAxis dataKey="label" tick={{ fontSize: 11 }} />
                <Radar dataKey="value" stroke="#7C3AED" fill="#7C3AED" fillOpacity={0.3} strokeWidth={2} />
                <Tooltip formatter={(v: number) => [`${v}%`, "Score"]} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="mt-5 rounded-3xl border border-[#5B5FEF]/25 bg-[#5B5FEF]/5 p-5" data-testid="analytics-insight">
        <p className="text-sm leading-relaxed">
          <span className="font-semibold text-[#5B5FEF]">Insight:</span> your response rate jumped to 31% after you
          started tailoring resumes (week 5). Roles above 90% match convert 2.3× better for you — Figma (87%) is one
          tailoring pass away from that tier.
        </p>
      </div>
    </div>
  );
}
