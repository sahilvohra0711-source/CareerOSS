import { useMemo, useState } from "react";
import { motion } from "motion/react";
import { GripVertical, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import { celebrate } from "@/lib/confetti";
import type { AppStatus, JobApplication } from "@/lib/types";
import { cn } from "@/lib/utils";

const COLUMNS: { id: AppStatus; label: string; tone: string }[] = [
  { id: "saved", label: "Saved", tone: "#94A3B8" },
  { id: "applied", label: "Applied", tone: "#5B5FEF" },
  { id: "screening", label: "Screening", tone: "#22D3EE" },
  { id: "interview", label: "Interview", tone: "#7C3AED" },
  { id: "offer", label: "Offer", tone: "#10B981" },
  { id: "rejected", label: "Rejected", tone: "#F43F5E" },
];

const emptyApp = (status: AppStatus): JobApplication => ({
  id: crypto.randomUUID().slice(0, 8),
  company: "", position: "", location: "", salary: "",
  appliedDate: new Date().toISOString().slice(0, 10),
  nextAction: "", status, notes: "",
});

const AVATAR_TONES = ["#5B5FEF", "#7C3AED", "#22D3EE", "#10B981", "#F59E0B", "#F43F5E"];
const toneFor = (name: string) => AVATAR_TONES[(name.charCodeAt(0) || 0) % AVATAR_TONES.length];

export default function Applications() {
  const { data, saveApplication, deleteApplication, addActivity } = useCareer();
  const [dragId, setDragId] = useState<string | null>(null);
  const [overCol, setOverCol] = useState<AppStatus | null>(null);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("recent");
  const [editing, setEditing] = useState<JobApplication | null>(null);

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    const list = data.applications.filter((a) =>
      !q || a.company.toLowerCase().includes(q) || a.position.toLowerCase().includes(q));
    return [...list].sort((a, b) =>
      sort === "match" ? (b.match ?? 0) - (a.match ?? 0)
      : sort === "company" ? a.company.localeCompare(b.company)
      : (b.appliedDate || "").localeCompare(a.appliedDate || ""));
  }, [data.applications, query, sort]);

  const drop = (status: AppStatus) => {
    if (!dragId) return;
    const app = data.applications.find((a) => a.id === dragId);
    if (app && app.status !== status) {
      saveApplication({ ...app, status });
      addActivity(`Moved ${app.company} to ${COLUMNS.find((c) => c.id === status)?.label}`);
      if (status === "offer") { celebrate(); toast.success("🏆 Offer stage — huge!"); }
      else toast.success(`${app.company} → ${COLUMNS.find((c) => c.id === status)?.label}`);
    }
    setDragId(null);
    setOverCol(null);
  };

  const save = () => {
    if (!editing) return;
    if (!editing.company.trim() || !editing.position.trim()) {
      toast.error("Company and position are required.");
      return;
    }
    const isNew = !data.applications.some((a) => a.id === editing.id);
    saveApplication(editing);
    addActivity(isNew ? `Added application: ${editing.position} at ${editing.company}` : `Updated ${editing.company}`);
    toast.success(isNew ? "✓ Application saved." : "Application updated");
    if (isNew) celebrate();
    setEditing(null);
  };

  return (
    <div data-testid="applications-page">
      <PageHeader title="Application Tracker" subtitle="Drag cards between stages — your pipeline at a glance."
        testId="applications-header"
        actions={<Button className="rounded-full" data-testid="add-application-btn" onClick={() => setEditing(emptyApp("saved"))}>
          <Plus className="mr-1 h-4 w-4" /> Add application
        </Button>} />

      <div className="mb-5 flex flex-wrap gap-3">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search company or position…" value={query}
            onChange={(e) => setQuery(e.target.value)} data-testid="applications-search" />
        </div>
        <Select value={sort} onValueChange={(v: string) => setSort(v)}>
          <SelectTrigger className="w-44" data-testid="applications-sort">
            <SelectValue>{(v: string) => ({ recent: "Sort: Recent", match: "Sort: Match %", company: "Sort: Company" })[v] ?? v}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="recent">Sort: Recent</SelectItem>
            <SelectItem value="match">Sort: Match %</SelectItem>
            <SelectItem value="company">Sort: Company</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4" data-testid="kanban-board">
        {COLUMNS.map((col) => {
          const cards = filtered.filter((a) => a.status === col.id);
          return (
            <div key={col.id}
              onDragOver={(e) => { e.preventDefault(); setOverCol(col.id); }}
              onDragLeave={() => setOverCol((c) => (c === col.id ? null : c))}
              onDrop={() => drop(col.id)}
              className={cn(
                "flex w-64 shrink-0 flex-col rounded-2xl border bg-card/60 p-3 transition-colors",
                overCol === col.id ? "border-[#5B5FEF]/60 bg-[#5B5FEF]/5" : "border-border",
              )}
              data-testid={`kanban-col-${col.id}`}>
              <div className="mb-3 flex items-center justify-between px-1">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <span className="h-2 w-2 rounded-full" style={{ background: col.tone }} />
                  {col.label}
                </p>
                <span className="rounded-full bg-muted px-2 py-0.5 font-mono text-[11px] text-muted-foreground">{cards.length}</span>
              </div>
              <div className="flex min-h-24 flex-1 flex-col gap-2.5">
                {cards.map((a) => (
                  <motion.article key={a.id} layoutId={a.id}
                    draggable onDragStart={() => setDragId(a.id)}
                    className="group cursor-grab rounded-xl border border-border bg-card p-3 shadow-sm transition-shadow hover:shadow-md active:cursor-grabbing"
                    data-testid={`app-card-${a.company.toLowerCase().replace(/\s/g, "-")}`}>
                    <div className="flex items-start gap-2.5">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg font-heading text-xs font-bold text-white"
                        style={{ background: toneFor(a.company) }}>
                        {a.company.slice(0, 1)}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{a.position}</p>
                        <p className="truncate text-xs text-muted-foreground">{a.company} · {a.location}</p>
                      </div>
                      <GripVertical className="h-4 w-4 shrink-0 text-muted-foreground/40" />
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[10px]">
                      {a.salary && <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">{a.salary}</span>}
                      {typeof a.match === "number" && (
                        <span className="rounded-full bg-[#22D3EE]/10 px-2 py-0.5 font-semibold text-[#22D3EE]">{a.match}% match</span>
                      )}
                      {a.appliedDate && <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">{a.appliedDate}</span>}
                    </div>
                    {a.nextAction && (
                      <p className="mt-2 rounded-lg bg-[#7C3AED]/10 px-2 py-1 text-[11px] font-medium text-[#7C3AED]">→ {a.nextAction}</p>
                    )}
                    <div className="mt-2 flex justify-end gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                      <button className="rounded-md p-1 text-muted-foreground hover:text-foreground" aria-label="Edit"
                        data-testid={`app-edit-${a.id}`} onClick={() => setEditing(a)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button className="rounded-md p-1 text-muted-foreground hover:text-destructive" aria-label="Delete"
                        data-testid={`app-delete-${a.id}`}
                        onClick={() => { deleteApplication(a.id); toast("Application deleted"); }}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </motion.article>
                ))}
                <button onClick={() => setEditing(emptyApp(col.id))} data-testid={`kanban-add-${col.id}`}
                  className="rounded-xl border border-dashed border-border py-2 text-xs text-muted-foreground transition-colors hover:border-[#5B5FEF]/50 hover:text-foreground">
                  + Add
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg" data-testid="application-dialog">
          <DialogHeader>
            <DialogTitle className="font-heading">
              {editing && data.applications.some((a) => a.id === editing.id) ? "Edit application" : "Add application"}
            </DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Company</Label><Input className="mt-1" value={editing.company} data-testid="app-form-company" onChange={(e) => setEditing({ ...editing, company: e.target.value })} /></div>
              <div><Label>Position</Label><Input className="mt-1" value={editing.position} data-testid="app-form-position" onChange={(e) => setEditing({ ...editing, position: e.target.value })} /></div>
              <div><Label>Location</Label><Input className="mt-1" value={editing.location} onChange={(e) => setEditing({ ...editing, location: e.target.value })} /></div>
              <div><Label>Salary</Label><Input className="mt-1" placeholder="$140k–180k" value={editing.salary} onChange={(e) => setEditing({ ...editing, salary: e.target.value })} /></div>
              <div><Label>Application date</Label><Input className="mt-1" type="date" value={editing.appliedDate} onChange={(e) => setEditing({ ...editing, appliedDate: e.target.value })} /></div>
              <div>
                <Label>Status</Label>
                <Select value={editing.status} onValueChange={(v: string) => setEditing({ ...editing, status: v as AppStatus })}>
                  <SelectTrigger className="mt-1" data-testid="app-form-status">
                    <SelectValue>{(v: string) => COLUMNS.find((c) => c.id === v)?.label ?? v}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>{COLUMNS.map((c) => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2"><Label>Next action</Label><Input className="mt-1" placeholder="e.g. Recruiter call — Jul 9" value={editing.nextAction ?? ""} onChange={(e) => setEditing({ ...editing, nextAction: e.target.value })} /></div>
              <div className="col-span-2"><Label>Notes</Label><Textarea className="mt-1" rows={3} value={editing.notes ?? ""} data-testid="app-form-notes" onChange={(e) => setEditing({ ...editing, notes: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={save} data-testid="app-form-save">Save application</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
