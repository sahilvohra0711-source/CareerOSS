import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowRight, Lightbulb, ScanSearch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader, ProgressBar, ScoreRing } from "@/components/career/bits";
import { analyzeResume, type AtsReport } from "@/services/ai";
import { useCareer } from "@/context/CareerContext";

export default function AtsAnalysis() {
  const { data } = useCareer();
  const navigate = useNavigate();
  const [resumeId, setResumeId] = useState(data.resumes[0]?.id ?? "");
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState(0);
  const [report, setReport] = useState<AtsReport | null>(null);
  const resume = data.resumes.find((r) => r.id === resumeId);

  const STAGES = ["Scanning structure…", "Analyzing your resume…", "Checking keywords…", "Almost there…"];

  const run = async () => {
    if (!resume) return;
    setLoading(true);
    setReport(null);
    setStage(0);
    const timer = setInterval(() => setStage((s) => Math.min(s + 1, STAGES.length - 1)), 450);
    const r = await analyzeResume(resume);
    clearInterval(timer);
    setReport(r);
    setLoading(false);
  };

  return (
    <div data-testid="ats-page">
      <PageHeader title="ATS Analysis" subtitle="See your resume the way an applicant tracking system does — then fix what it flags." testId="ats-header" />

      <div className="mb-6 flex flex-wrap items-end gap-3 rounded-3xl border border-border bg-card p-5">
        <div className="min-w-64 flex-1">
          <label className="text-sm font-medium">Resume</label>
          <Select value={resumeId} onValueChange={(v: string) => setResumeId(v)}>
            <SelectTrigger className="mt-1.5" data-testid="ats-resume-select">
              <SelectValue>{(v: string) => data.resumes.find((r) => r.id === v)?.name ?? "Choose a resume"}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {data.resumes.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Button className="rounded-full" onClick={() => void run()} disabled={loading || !resume} data-testid="run-ats-btn">
          <ScanSearch className="mr-1 h-4 w-4" /> {loading ? STAGES[stage] : "Run ATS analysis"}
        </Button>
      </div>

      {loading && (
        <div className="grid gap-4 md:grid-cols-3" data-testid="ats-loading">
          {[0, 1, 2].map((i) => <div key={i} className="skeleton-shimmer h-40 rounded-3xl" />)}
          <p className="text-sm text-muted-foreground md:col-span-3">{STAGES[stage]}</p>
        </div>
      )}

      {report && !loading && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="grid gap-5 lg:grid-cols-12" data-testid="ats-report">
          <div className="flex flex-col items-center rounded-3xl border border-border bg-card p-6 lg:col-span-4">
            <ScoreRing value={report.overall} size={190} stroke={13} label={`${report.overall}`} sub="ATS SCORE / 100" testId="ats-score-ring" />
            <p className="mt-4 text-center text-sm text-muted-foreground">
              {report.overall >= 85 ? "Excellent — this resume parses and ranks well." :
               report.overall >= 70 ? "Solid, with a few fixable gaps below." :
               "Needs work — start with the first action below."}
            </p>
            <Button className="mt-5 rounded-full" onClick={() => navigate(`/app/resumes/${resumeId}`)} data-testid="improve-resume-btn">
              Improve Resume <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </div>

          <div className="rounded-3xl border border-border bg-card p-6 lg:col-span-8">
            <h2 className="mb-4 font-heading text-lg font-semibold">Category breakdown</h2>
            <div className="grid gap-x-8 gap-y-4 sm:grid-cols-2">
              {report.categories.map((c) => (
                <div key={c.label} data-testid={`ats-cat-${c.label.toLowerCase()}`}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span>{c.label}</span>
                    <span className="font-mono text-muted-foreground">{c.score}/100</span>
                  </div>
                  <ProgressBar value={c.score} />
                  <p className="mt-1 text-xs text-muted-foreground">{c.note}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-12">
            <h2 className="mb-3 font-heading text-lg font-semibold">Actionable feedback</h2>
            <div className="grid gap-4 md:grid-cols-3">
              {report.feedback.map((f, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                  className="card-lift rounded-2xl border border-border bg-card p-5" data-testid={`ats-feedback-${i}`}>
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#F59E0B]/10 text-[#F59E0B]">
                    <Lightbulb className="h-4.5 w-4.5" />
                  </span>
                  <p className="mt-3 text-sm font-semibold leading-snug">{f.title}</p>
                  <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{f.detail}</p>
                  <p className="mt-3 rounded-lg bg-[#5B5FEF]/10 px-3 py-2 text-xs font-medium text-[#5B5FEF]">→ {f.action}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {!report && !loading && (
        <div className="flex min-h-60 flex-col items-center justify-center rounded-3xl border border-dashed border-border p-8 text-center" data-testid="ats-empty">
          <ScanSearch className="h-8 w-8 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">Choose a resume and run the analysis — your score and fixes appear here.</p>
        </div>
      )}
    </div>
  );
}
