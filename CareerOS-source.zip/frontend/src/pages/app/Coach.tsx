import { Bot } from "lucide-react";
import { PageHeader } from "@/components/career/bits";
import { ChatCore } from "@/components/coach/ChatCore";

export default function Coach() {
  return (
    <div className="mx-auto flex h-[calc(100vh-9rem)] max-w-3xl flex-col" data-testid="coach-page">
      <PageHeader title="AI Career Coach" subtitle="Nova knows your resume, tracker and skill gaps — ask anything." testId="coach-header" />
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-3xl border border-border bg-card">
        <div className="flex items-center gap-3 border-b border-border px-5 py-3.5">
          <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#5B5FEF] to-[#22D3EE] text-white">
            <Bot className="h-4 w-4" />
            <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-card bg-[#10B981]" />
          </span>
          <div>
            <p className="font-heading text-sm font-semibold">Nova</p>
            <p className="text-[11px] text-[#10B981]">Online — context: Alex Morgan · Software Engineer</p>
          </div>
        </div>
        <div className="min-h-0 flex-1">
          <ChatCore />
        </div>
      </div>
    </div>
  );
}
