import { useState } from "react";
import { Building2, ExternalLink, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState, PageHeader } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import type { AppStatus, Company } from "@/lib/types";

const STATUS_LABEL: Record<AppStatus, string> = {
  saved: "Researching", applied: "Applied", screening: "Screening",
  interview: "Interviewing", offer: "Offer", rejected: "Closed",
};
const TONES = ["#5B5FEF", "#7C3AED", "#22D3EE", "#10B981", "#F59E0B"];

const blank: Company = {
  id: "", name: "", position: "", location: "", salary: "", url: "",
  appliedDate: "", contact: "", notes: "", status: "saved",
};

export default function Companies() {
  const { data, saveCompany, deleteCompany } = useCareer();
  const [editing, setEditing] = useState<Company | null>(null);

  const save = () => {
    if (!editing) return;
    if (!editing.name.trim()) { toast.error("Company name is required."); return; }
    saveCompany({ ...editing, id: editing.id || crypto.randomUUID().slice(0, 8) });
    toast.success("Company saved");
    setEditing(null);
  };

  return (
    <div data-testid="companies-page">
      <PageHeader title="Company Tracker" subtitle="Every target company, contact and conversation in one dossier."
        testId="companies-header"
        actions={<Button className="rounded-full" data-testid="add-company-btn" onClick={() => setEditing({ ...blank })}>
          <Plus className="mr-1 h-4 w-4" /> Add company
        </Button>} />

      {data.companies.length === 0 ? (
        <EmptyState icon={<Building2 className="h-6 w-6" />} title="No companies yet"
          subtitle="Track the companies you're targeting — contacts, notes and status."
          testId="companies-empty"
          action={<Button onClick={() => setEditing({ ...blank })}>Add your first company</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {data.companies.map((c, i) => (
            <div key={c.id} className="card-lift flex flex-col rounded-3xl border border-border bg-card p-5" data-testid={`company-card-${c.name.toLowerCase()}`}>
              <div className="flex items-start justify-between">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl font-heading text-base font-bold text-white"
                  style={{ background: TONES[i % TONES.length] }}>
                  {c.name.slice(0, 1)}
                </span>
                <Badge variant="secondary">{STATUS_LABEL[c.status]}</Badge>
              </div>
              <h3 className="mt-3 font-heading text-lg font-semibold">{c.name}</h3>
              <p className="text-sm text-muted-foreground">{c.position} · {c.location}</p>
              {c.salary && <p className="mt-1 font-mono text-xs text-[#22D3EE]">{c.salary}</p>}
              {c.contact && (
                <p className="mt-3 rounded-xl bg-muted/60 px-3 py-2 text-xs text-muted-foreground">👤 {c.contact}</p>
              )}
              {c.notes && <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-muted-foreground">{c.notes}</p>}
              <div className="mt-4 flex items-center gap-1.5 border-t border-border pt-3">
                {c.url && (
                  <a href={`https://${c.url}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-1 text-xs text-[#5B5FEF] hover:underline" data-testid={`company-url-${c.id}`}>
                    <ExternalLink className="h-3 w-3" /> Job post
                  </a>
                )}
                <div className="ml-auto flex gap-1">
                  <Button size="icon-sm" variant="ghost" aria-label="Edit company" data-testid={`company-edit-${c.id}`} onClick={() => setEditing(c)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="icon-sm" variant="ghost" aria-label="Delete company" className="text-destructive" data-testid={`company-delete-${c.id}`}
                    onClick={() => { deleteCompany(c.id); toast("Company removed"); }}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg" data-testid="company-dialog">
          <DialogHeader><DialogTitle className="font-heading">{editing?.id ? "Edit company" : "Add company"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Company</Label><Input className="mt-1" value={editing.name} data-testid="company-form-name" onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
              <div><Label>Position</Label><Input className="mt-1" value={editing.position} onChange={(e) => setEditing({ ...editing, position: e.target.value })} /></div>
              <div><Label>Location</Label><Input className="mt-1" value={editing.location} onChange={(e) => setEditing({ ...editing, location: e.target.value })} /></div>
              <div><Label>Salary</Label><Input className="mt-1" value={editing.salary} onChange={(e) => setEditing({ ...editing, salary: e.target.value })} /></div>
              <div><Label>Job URL</Label><Input className="mt-1" placeholder="company.com/jobs" value={editing.url} onChange={(e) => setEditing({ ...editing, url: e.target.value })} /></div>
              <div><Label>Application date</Label><Input className="mt-1" type="date" value={editing.appliedDate} onChange={(e) => setEditing({ ...editing, appliedDate: e.target.value })} /></div>
              <div className="col-span-2"><Label>Recruiter / contact</Label><Input className="mt-1" placeholder="Name — email or LinkedIn" value={editing.contact} onChange={(e) => setEditing({ ...editing, contact: e.target.value })} /></div>
              <div className="col-span-2">
                <Label>Status</Label>
                <Select value={editing.status} onValueChange={(v: string) => setEditing({ ...editing, status: v as AppStatus })}>
                  <SelectTrigger className="mt-1"><SelectValue>{(v: string) => STATUS_LABEL[v as AppStatus]}</SelectValue></SelectTrigger>
                  <SelectContent>{Object.entries(STATUS_LABEL).map(([k, l]) => <SelectItem key={k} value={k}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2"><Label>Notes</Label><Textarea className="mt-1" rows={3} value={editing.notes} onChange={(e) => setEditing({ ...editing, notes: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter><Button onClick={save} data-testid="company-form-save">Save company</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
