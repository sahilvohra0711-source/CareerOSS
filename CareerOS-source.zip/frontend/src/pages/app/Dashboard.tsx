import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "motion/react";
import {
  FileText, Briefcase, Mic, TrendingUp, UserRound, ArrowRight, Target,
  Sparkles, CalendarClock, CheckCircle2, Plus,
} from "lucide-react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CountUp, ProgressBar, ScoreRing } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import { toast } from "sonner";

const WEEK = [
  { w: "W1", apps: 2, responses: 1 }, { w: "W2", apps: 4, responses: 1 },
  { w: "W3", apps: 3, responses: 2 }, { w: "W4", apps: 6, responses: 2 },
  { w: "W5", apps: 5, responses: 3 }, { w: "W6", apps: 8, responses: 4 },
  { w: "W7", apps: 7, responses: 3 }, { w: "W8", apps: 9, responses: 5 },
];

const ACTIONS = [
  { to: "/app/tailor", icon: Sparkles, tone: "#7C3AED", title: "Tailor resume for Figma", copy: "87% match sitting in Saved — a tailored resume pushes it past 90%." },
  { to: "/app/interview", icon: Mic, tone: "#F43F5E", title: "Mock interview before Google onsite", copy: "Onsite is Jul 14. Two practice rounds target your weakest dimension: impact." },
  { to: "/app/reminders", icon: CalendarClock, tone: "#F59E0B", title: "Follow up with Stripe", copy: "Technical round done — a thank-you note within 48h doubles reply odds." },
];

export default function Dashboard() {
  const { data, saveReminder } = useCareer();
  const [reportOpen, setReportOpen] = useState(false);
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const upcoming = data.reminders.filter((r) => !r.done).slice(0, 3);
  const matches = [...data.jobs].sort((a, b) => b.match - a.match).slice(0, 3);
  const gaps = data.skills.filter((s) => s.recommended);

  const stats = [
    { icon: FileText, label: "Resume Score", value: 92, suffix: "/100", tone: "#22D3EE", delta: "+4 this week", testId: "stat-resume-score" },
    { icon: Briefcase, label: "Applications", value: 24, suffix: "", tone: "#5B5FEF", delta: `${data.applications.length} in pipeline`, testId: "stat-applications" },
    { icon: Mic, label: "Interviews", value: 6, suffix: "", tone: "#7C3AED", delta: "2 this week", testId: "stat-interviews" },
    { icon: TrendingUp, label: "Response Rate", value: 31, suffix: "%", tone: "#10B981", delta: "Benchmark: 20%", testId: "stat-response-rate" },
    { icon: UserRound, label: "Profile Strength", value: 87, suffix: "%", tone: "#F59E0B", delta: "Almost elite", testId: "stat-profile-strength" },
  ];

  return (
    <div data-testid="dashboard-page">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight sm:text-3xl" data-testid="dashboard-greeting">
            {greeting}, {data.profile.firstName} 👋
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Here's what's happening with your career today.</p>
        </div>
        <Link to="/app/applications">
          <Button data-testid="dashboard-add-application" className="rounded-full"><Plus className="mr-1 h-4 w-4" /> Log application</Button>
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        {stats.map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06, duration: 0.45 }}
            className="card-lift rounded-2xl border border-border bg-card p-4" data-testid={s.testId}>
            <div className="flex items-center justify-between">
              <s.icon className="h-4 w-4" style={{ color: s.tone }} />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</span>
            </div>
            <p className="mt-2 font-heading text-2xl font-bold"><CountUp to={s.value} suffix={s.suffix} /></p>
            <p className="mt-0.5 text-[11px] text-muted-foreground">{s.delta}</p>
          </motion.div>
        ))}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-12">
        <div className="rounded-3xl border border-border bg-card p-6 lg:col-span-4" data-testid="readiness-card">
          <div className="flex items-center justify-between">
            <h2 className="font-heading text-lg font-semibold">Career Readiness</h2>
            <Button variant="ghost" size="sm" data-testid="readiness-report-btn" onClick={() => setReportOpen(true)}>
              Report <ArrowRight className="ml-1 h-3.5 w-3.5" />
            </Button>
          </div>
          <button onClick={() => setReportOpen(true)} className="mt-2 flex w-full flex-col items-center rounded-2xl p-2 transition-colors hover:bg-accent/50" data-testid="readiness-ring-btn">
            <ScoreRing value={data.readiness.overall} size={180} stroke={12} sub="OUT OF 100" testId="career-score-gauge" />
          </button>
          <div className="mt-4 space-y-3">
            {data.readiness.breakdown.map((b) => (
              <div key={b.label}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="text-muted-foreground">{b.label}</span>
                  <span className="font-mono">{b.value}%</span>
                </div>
                <ProgressBar value={b.value} />
              </div>
            ))}
          </div>
          <p className="mt-4 rounded-xl bg-[#5B5FEF]/10 px-3 py-2.5 text-xs leading-relaxed text-muted-foreground">
            <span className="font-semibold text-[#5B5FEF]">Fastest lever:</span> Interview prep is 76% — two mock
            sessions before your Google onsite moves you past 90.
          </p>
        </div>

        <div className="rounded-3xl border border-border bg-card p-6 lg:col-span-8" data-testid="activity-chart-card">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-heading text-lg font-semibold">Application momentum</h2>
              <p className="text-xs text-muted-foreground">Applications sent vs. responses — last 8 weeks</p>
            </div>
            <Link to="/app/analytics" className="text-xs text-[#5B5FEF] hover:underline" data-testid="view-analytics-link">Full analytics →</Link>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={WEEK} margin={{ left: -24, right: 8, top: 4 }}>
                <defs>
                  <linearGradient id="gApps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#5B5FEF" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#5B5FEF" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gResp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22D3EE" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#22D3EE" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(128,140,170,0.15)" vertical={false} />
                <XAxis dataKey="w" tick={{ fontSize: 11 }} stroke="rgba(128,140,170,0.4)" tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} stroke="rgba(128,140,170,0.4)" tickLine={false} axisLine={false} />
                <Tooltip formatter={(value: number, name: string) => [value, name === "apps" ? "Applications" : "Responses"]} labelFormatter={(l: string) => `Week ${l.slice(1)}`} />
                <Area type="monotone" dataKey="apps" stroke="#5B5FEF" strokeWidth={2.5} fill="url(#gApps)" />
                <Area type="monotone" dataKey="responses" stroke="#22D3EE" strokeWidth={2.5} fill="url(#gResp)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card p-6 lg:col-span-4" data-testid="reminders-card">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-heading text-lg font-semibold">Upcoming</h2>
            <Link to="/app/reminders" className="text-xs text-[#5B5FEF] hover:underline">All reminders →</Link>
          </div>
          <div className="space-y-3">
            {upcoming.map((r) => (
              <div key={r.id} className="flex items-start gap-3 rounded-xl border border-border/70 p-3">
                <button
                  onClick={() => { saveReminder({ ...r, done: true }); toast.success("Reminder completed"); }}
                  className="mt-0.5 text-muted-foreground transition-colors hover:text-[#10B981]"
                  aria-label={`Complete ${r.title}`} data-testid={`reminder-check-${r.id}`}
                >
                  <CheckCircle2 className="h-4.5 w-4.5" />
                </button>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{r.title}</p>
                  <p className="text-xs text-muted-foreground">{r.date}</p>
                </div>
              </div>
            ))}
            {upcoming.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">All clear — nothing due. 🎉</p>}
          </div>
          <div className="mt-5 border-t border-border pt-4">
            <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Recent activity</h3>
            <div className="space-y-3">
              {data.activities.slice(0, 4).map((a) => (
                <div key={a.id} className="flex gap-3 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#22D3EE]" />
                  <div>
                    <p className="leading-snug">{a.text}</p>
                    <p className="text-xs text-muted-foreground">{a.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-5">
          <h2 className="mb-3 font-heading text-lg font-semibold">Recommended actions</h2>
          <div className="space-y-3">
            {ACTIONS.map((a, i) => (
              <motion.div key={a.title} initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.08 }}>
                <Link to={a.to} data-testid={`action-${i}`}
                  className="card-lift flex items-start gap-4 rounded-2xl border border-border bg-card p-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl" style={{ background: `${a.tone}1f`, color: a.tone }}>
                    <a.icon className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-sm font-semibold">{a.title}</span>
                    <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">{a.copy}</span>
                  </span>
                  <ArrowRight className="ml-auto mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card p-6 lg:col-span-3" data-testid="top-matches-card">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-heading text-lg font-semibold">Top matches</h2>
            <Target className="h-4 w-4 text-[#22D3EE]" />
          </div>
          <div className="space-y-3">
            {matches.map((j) => (
              <Link to="/app/jobs" key={j.id} className="block rounded-xl border border-border/70 p-3 transition-colors hover:border-[#5B5FEF]/40" data-testid={`match-${j.company.toLowerCase()}`}>
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-semibold">{j.title}</p>
                  <span className="rounded-full bg-[#22D3EE]/10 px-2 py-0.5 font-mono text-[11px] font-semibold text-[#22D3EE]">{j.match}%</span>
                </div>
                <p className="mt-0.5 text-xs text-muted-foreground">{j.company} · {j.location}</p>
              </Link>
            ))}
          </div>
        </div>

        <div className="lg:col-span-12 xl:col-span-12">
          <h2 className="mb-3 font-heading text-lg font-semibold">Skill gaps to close</h2>
          <div className="grid gap-3 sm:grid-cols-3">
            {gaps.map((s) => (
              <div key={s.name} className="rounded-2xl border border-border bg-card p-4" data-testid={`gap-${s.name.toLowerCase().replace(/\s/g, "-")}`}>
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold">{s.name}</p>
                  <span className="rounded-full bg-[#F59E0B]/10 px-2 py-0.5 text-[10px] font-semibold text-[#F59E0B]">GAP</span>
                </div>
                <ProgressBar value={s.level} className="mt-3" color="#F59E0B" />
                <p className="mt-2 text-xs text-muted-foreground">{s.level}% — appears in most of your saved roles</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="max-w-lg" data-testid="readiness-report-dialog">
          <DialogHeader>
            <DialogTitle className="font-heading">Career Readiness Report</DialogTitle>
          </DialogHeader>
          <div className="flex items-center gap-6">
            <ScoreRing value={data.readiness.overall} size={130} sub="OVERALL" />
            <p className="text-sm text-muted-foreground">
              You're in the <span className="font-semibold text-foreground">top 12%</span> of active job seekers on
              this track. One focused week on interview prep puts elite status (90+) within reach.
            </p>
          </div>
          <div className="mt-2 space-y-3">
            {data.readiness.breakdown.map((b) => (
              <div key={b.label} className="flex items-center gap-4">
                <span className="w-32 shrink-0 text-sm">{b.label}</span>
                <ProgressBar value={b.value} className="flex-1" />
                <span className="w-10 text-right font-mono text-xs">{b.value}%</span>
              </div>
            ))}
          </div>
          <Link to="/app/interview">
            <Button className="mt-4 w-full rounded-full" data-testid="report-start-prep-btn">Start interview prep <ArrowRight className="ml-1 h-4 w-4" /></Button>
          </Link>
        </DialogContent>
      </Dialog>
    </div>
  );
}
