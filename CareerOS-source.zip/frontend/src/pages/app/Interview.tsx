import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "motion/react";
import { ArrowRight, Lightbulb, MessageCircle, Mic, MicOff, RotateCcw, Smile, Sparkles, Timer, Trophy } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader, ProgressBar, ScoreRing, TypingDots } from "@/components/career/bits";
import { evaluateInterviewAnswer, generateInterviewQuestions, type EvalResult } from "@/services/ai";
import { INTERVIEWER_AVATAR } from "@/data/demo";
import { useCareer } from "@/context/CareerContext";
import { celebrate } from "@/lib/confetti";
import type { InterviewAnswer, Reaction } from "@/lib/types";
import { cn } from "@/lib/utils";

const TYPES = ["Behavioral", "Technical", "HR", "System Design", "General"];
const LEVELS = ["Entry", "Mid", "Senior"];

const REACTIONS: Record<Reaction, { icon: typeof Smile; label: string; tone: string }> = {
  excellent: { icon: Sparkles, label: "Excellent answer!", tone: "#10B981" },
  strong: { icon: Smile, label: "Nice answer!", tone: "#22D3EE" },
  average: { icon: Lightbulb, label: "Good start — let's strengthen the impact.", tone: "#F59E0B" },
  weak: { icon: MessageCircle, label: "Let's make this answer more specific.", tone: "#94A3B8" },
};

/* Browser-native speech recognition (free — no AI credits). */
type SpeechRecognitionLike = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((e: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
};

function getSpeechRecognition(): (new () => SpeechRecognitionLike) | null {
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

type Phase = "setup" | "running" | "report";

export default function Interview() {
  const { data, addSession, addActivity, pushNotification } = useCareer();
  const [phase, setPhase] = useState<Phase>("setup");
  const [job, setJob] = useState("Software Engineer");
  const [type, setType] = useState("Behavioral");
  const [level, setLevel] = useState("Mid");
  const [mode, setMode] = useState<"practice" | "mock">("mock");
  const [questions, setQuestions] = useState<string[]>([]);
  const [qi, setQi] = useState(0);
  const [answer, setAnswer] = useState("");
  const [analyzing, setAnalyzing] = useState<0 | 1 | 2>(0);
  const [evalResult, setEvalResult] = useState<EvalResult | null>(null);
  const [answers, setAnswers] = useState<InterviewAnswer[]>([]);
  const [seconds, setSeconds] = useState(120);
  const [listening, setListening] = useState(false);
  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const toggleVoice = () => {
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const SR = getSpeechRecognition();
    if (!SR) {
      toast.error("Voice input works in Chrome or Edge — or just type your answer.");
      return;
    }
    const rec = new SR();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = "en-US";
    rec.onresult = (e) => {
      let final = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
      }
      if (final.trim()) setAnswer((a) => (a ? a.trimEnd() + " " : "") + final.trim());
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => { setListening(false); toast.error("Microphone unavailable — check permissions, or type instead."); };
    rec.start();
    recRef.current = rec;
    setListening(true);
    toast.success("Listening… speak your answer naturally");
  };

  const total = questions.length;

  useEffect(() => {
    if (phase === "running" && mode === "mock" && !evalResult && analyzing === 0) {
      timerRef.current = setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : 0)), 1000);
      return () => { if (timerRef.current) clearInterval(timerRef.current); };
    }
  }, [phase, mode, qi, evalResult, analyzing]);

  const start = () => {
    const count = mode === "mock" ? 10 : 5;
    setQuestions(generateInterviewQuestions(type, level, job, count));
    setQi(0); setAnswers([]); setAnswer(""); setEvalResult(null);
    setSeconds(120);
    setPhase("running");
  };

  const submit = async () => {
    if (!answer.trim()) { toast.error("Type your answer first."); return; }
    setAnalyzing(1);
    const stageTimer = setTimeout(() => setAnalyzing(2), 900);
    const result = await evaluateInterviewAnswer(questions[qi], answer);
    clearTimeout(stageTimer);
    setEvalResult(result);
    setAnalyzing(0);
    setAnswers((a) => [...a, { question: questions[qi], answer, scores: result.scores, feedback: result.feedback, reaction: result.reaction }]);
  };

  const next = () => {
    setEvalResult(null);
    setAnswer("");
    setSeconds(120);
    if (qi + 1 >= total) finish();
    else setQi(qi + 1);
  };

  const finish = () => {
    const finalAnswers = answers;
    const overall = Math.round((finalAnswers.reduce((s, a) => s + a.scores.overall, 0) / Math.max(1, finalAnswers.length)) * 10);
    addSession({
      id: crypto.randomUUID().slice(0, 8), jobTitle: job, type, level,
      date: new Date().toISOString().slice(0, 10),
      mode: mode === "mock" ? "Mock interview" : "Practice",
      answers: finalAnswers, overall,
    });
    addActivity(`Completed ${mode === "mock" ? "mock interview" : "practice"} — ${type} (${overall}/100)`);
    pushNotification(`Interview preparation completed: ${type} set, score ${overall}/100.`, "success");
    setPhase("report");
    celebrate();
    toast.success("🏆 Mock interview completed!");
  };

  const reportStats = useMemo(() => {
    if (answers.length === 0) return null;
    const avg = (k: "clarity" | "depth" | "structure" | "impact") =>
      Math.round((answers.reduce((s, a) => s + a.scores[k], 0) / answers.length) * 10) / 10;
    const dims = { clarity: avg("clarity"), depth: avg("depth"), structure: avg("structure"), impact: avg("impact") };
    const overall = Math.round(((dims.clarity + dims.depth + dims.structure + dims.impact) / 4) * 10);
    return { dims, overall };
  }, [answers]);

  if (phase === "setup")
    return (
      <div data-testid="interview-setup">
        <PageHeader title="Interview Prep" subtitle="Rehearse with an AI interviewer that scores every answer and reacts like a real panel." testId="interview-header" />
        <div className="grid gap-6 lg:grid-cols-5">
          <div className="rounded-3xl border border-border bg-card p-6 lg:col-span-3">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium">Target job</label>
                <Select value={job} onValueChange={(v: string) => setJob(v)}>
                  <SelectTrigger className="mt-1.5" data-testid="interview-job-select">
                    <SelectValue>{(v: string) => v}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {[...new Set([...data.applications.map((a) => a.position), "Software Engineer"])].map((p) => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Experience level</label>
                <Select value={level} onValueChange={(v: string) => setLevel(v)}>
                  <SelectTrigger className="mt-1.5" data-testid="interview-level-select"><SelectValue>{(v: string) => v}</SelectValue></SelectTrigger>
                  <SelectContent>{LEVELS.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="sm:col-span-2">
                <label className="mb-2 block text-sm font-medium">Interview type</label>
                <div className="flex flex-wrap gap-2" data-testid="interview-type-picker">
                  {TYPES.map((t) => (
                    <button key={t} onClick={() => setType(t)} data-testid={`interview-type-${t.toLowerCase().replace(/\s/g, "-")}`}
                      className={cn("rounded-full px-4 py-2 text-sm font-medium transition-colors",
                        type === t ? "bg-[#5B5FEF] text-white" : "bg-muted text-muted-foreground hover:text-foreground")}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="mb-2 block text-sm font-medium">Mode</label>
                <div className="grid gap-3 sm:grid-cols-2">
                  {([
                    { id: "practice", title: "Practice — 5 questions", copy: "Untimed, focused feedback per answer." },
                    { id: "mock", title: "Mock interview — 10 questions", copy: "2:00 per question, full report + practice plan." },
                  ] as const).map((m) => (
                    <button key={m.id} onClick={() => setMode(m.id)} data-testid={`mode-${m.id}`}
                      className={cn("rounded-2xl border p-4 text-left transition-colors",
                        mode === m.id ? "border-[#5B5FEF] bg-[#5B5FEF]/10" : "border-border hover:border-[#5B5FEF]/40")}>
                      <p className="text-sm font-semibold">{m.title}</p>
                      <p className="mt-1 text-xs text-muted-foreground">{m.copy}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <Button size="lg" className="mt-6 rounded-full px-8" onClick={start} data-testid="start-interview-btn">
              <Mic className="mr-1.5 h-4 w-4" /> Start interview
            </Button>
          </div>

          <div className="rounded-3xl border border-border bg-card p-6 lg:col-span-2">
            <div className="flex items-center gap-4">
              <img src={INTERVIEWER_AVATAR} alt="Sarah, your AI interviewer" className="h-16 w-16 rounded-2xl object-cover ring-2 ring-[#5B5FEF]/50" />
              <div>
                <p className="font-heading font-semibold">Sarah — AI Interviewer</p>
                <p className="text-xs text-muted-foreground">Senior tech recruiter persona. Reacts to your answers in real time.</p>
              </div>
            </div>
            <div className="mt-5 space-y-2.5 text-sm">
              {Object.values(REACTIONS).map((r) => (
                <div key={r.label} className="flex items-center gap-2.5 rounded-xl bg-muted/50 px-3 py-2">
                  <r.icon className="h-4 w-4" style={{ color: r.tone }} />
                  <span className="text-xs text-muted-foreground">{r.label}</span>
                </div>
              ))}
            </div>
            {data.sessions.length > 0 && (
              <div className="mt-5 border-t border-border pt-4">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Recent sessions</p>
                {data.sessions.slice(0, 3).map((s) => (
                  <p key={s.id} className="flex justify-between py-1 text-sm">
                    <span className="text-muted-foreground">{s.type} · {s.mode}</span>
                    <span className="font-mono font-semibold text-[#22D3EE]">{s.overall}/100</span>
                  </p>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );

  if (phase === "running") {
    const reaction = evalResult ? REACTIONS[evalResult.reaction] : null;
    return (
      <div className="mx-auto max-w-3xl" data-testid="interview-running">
        <div className="mb-5 flex items-center justify-between gap-4">
          <div className="flex-1">
            <div className="mb-1.5 flex justify-between text-xs text-muted-foreground">
              <span>Question {qi + 1} of {total}</span>
              <span>{type} · {level} · {mode === "mock" ? "Mock" : "Practice"}</span>
            </div>
            <ProgressBar value={((qi + (evalResult ? 1 : 0)) / total) * 100} />
          </div>
          {mode === "mock" && (
            <span className={cn("flex items-center gap-1.5 rounded-full px-3 py-1.5 font-mono text-sm", seconds < 30 ? "bg-[#F43F5E]/10 text-[#F43F5E]" : "bg-muted text-muted-foreground")} data-testid="interview-timer">
              <Timer className="h-3.5 w-3.5" /> {Math.floor(seconds / 60)}:{String(seconds % 60).padStart(2, "0")}
            </span>
          )}
        </div>

        <div className="rounded-3xl border border-border bg-card p-6">
          <div className="flex items-start gap-4">
            <motion.div
              key={evalResult ? evalResult.reaction : "neutral"}
              initial={{ scale: 0.9 }} animate={{ scale: [0.9, 1.08, 1] }} transition={{ duration: 0.5 }}
              className="relative shrink-0"
            >
              <img src={INTERVIEWER_AVATAR} alt="Sarah, AI interviewer"
                className="h-14 w-14 rounded-2xl object-cover transition-all"
                style={{ boxShadow: reaction ? `0 0 0 3px ${reaction.tone}` : "0 0 0 2px rgba(91,95,239,0.4)" }}
                data-testid="interviewer-avatar" />
              {reaction && (
                <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }}
                  className="absolute -bottom-2 -right-2 flex h-7 w-7 items-center justify-center rounded-full text-white"
                  style={{ background: reaction.tone }} data-testid="avatar-reaction-badge">
                  <reaction.icon className="h-3.5 w-3.5" />
                </motion.span>
              )}
            </motion.div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Sarah · AI Interviewer</p>
              <p className="mt-1 font-heading text-lg font-semibold leading-snug" data-testid="interview-question">
                {questions[qi]}
              </p>
              <AnimatePresence>
                {reaction && (
                  <motion.p initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                    className="mt-2 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold"
                    style={{ background: `${reaction.tone}1a`, color: reaction.tone }} data-testid="reaction-label">
                    <reaction.icon className="h-3.5 w-3.5" /> {reaction.label}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          </div>

          {!evalResult && (
            <>
              <div className="relative mt-5">
                <Textarea rows={6} className="pr-14" placeholder="Structure your answer: situation → what you did → the measurable result… or tap the mic and speak it."
                  value={answer} onChange={(e) => setAnswer(e.target.value)} disabled={analyzing > 0}
                  data-testid="interview-answer-input" />
                <button
                  type="button" onClick={toggleVoice} disabled={analyzing > 0}
                  aria-label={listening ? "Stop voice input" : "Speak your answer"}
                  data-testid="voice-mic-btn"
                  className={cn(
                    "absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full transition-all",
                    listening
                      ? "animate-pulse bg-[#F43F5E] text-white shadow-[0_0_20px_rgba(244,63,94,0.5)]"
                      : "bg-muted text-muted-foreground hover:bg-[#5B5FEF] hover:text-white",
                  )}>
                  {listening ? <MicOff className="h-4.5 w-4.5" /> : <Mic className="h-4.5 w-4.5" />}
                </button>
              </div>
              {listening && (
                <p className="mt-2 flex items-center gap-2 text-xs text-[#F43F5E]" data-testid="voice-listening-hint">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute h-full w-full animate-ping rounded-full bg-[#F43F5E] opacity-60" />
                    <span className="relative h-2 w-2 rounded-full bg-[#F43F5E]" />
                  </span>
                  Listening — tap the mic again to stop. Your words appear in the box.
                </p>
              )}
              <div className="mt-4 flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{answer.trim().split(/\s+/).filter(Boolean).length} words</span>
                {analyzing > 0 ? (
                  <TypingDots label={analyzing === 1 ? "AI is analyzing your answer" : "Reviewing your response…"} />
                ) : (
                  <Button onClick={() => void submit()} className="rounded-full" data-testid="submit-answer-btn">
                    Submit answer <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                )}
              </div>
            </>
          )}

          {evalResult && (
            <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="mt-6" data-testid="answer-feedback">
              <div className="flex flex-wrap items-center gap-6 rounded-2xl border border-border bg-muted/40 p-5">
                <ScoreRing value={evalResult.scores.overall * 10} size={110} label={String(evalResult.scores.overall)} sub="/ 10" testId="answer-score-ring" />
                <div className="min-w-56 flex-1 space-y-2.5">
                  {([["Clarity", evalResult.scores.clarity], ["Technical Depth", evalResult.scores.depth], ["Structure", evalResult.scores.structure], ["Impact", evalResult.scores.impact]] as const).map(([l, v]) => (
                    <div key={l} className="flex items-center gap-3">
                      <span className="w-28 shrink-0 text-xs text-muted-foreground">{l}</span>
                      <ProgressBar value={v * 10} className="flex-1" />
                      <span className="w-9 text-right font-mono text-xs">{v}/10</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-4 rounded-2xl border border-[#5B5FEF]/25 bg-[#5B5FEF]/5 p-4">
                <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-[#5B5FEF]">AI feedback</p>
                <p className="text-sm leading-relaxed" data-testid="answer-feedback-text">{evalResult.feedback}</p>
              </div>
              <div className="mt-4 text-right">
                <Button onClick={next} className="rounded-full" data-testid="continue-interview-btn">
                  {qi + 1 >= total ? "See my report" : "Continue"} <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  const dims = reportStats?.dims ?? { clarity: 0, depth: 0, structure: 0, impact: 0 };
  const overall = reportStats?.overall ?? 0;
  const strengths = [
    dims.structure >= 7.5 && "Communication",
    dims.depth >= 7.5 && "Technical knowledge",
    dims.clarity >= 7.5 && "Problem solving",
  ].filter(Boolean) as string[];
  const improve = [
    dims.impact < 7.5 && "Quantifying achievements",
    dims.clarity < 7.5 && "Behavioral examples",
    dims.depth < 7.5 && "Technical depth",
  ].filter(Boolean) as string[];

  return (
    <div className="mx-auto max-w-3xl" data-testid="interview-report">
      <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }}
        className="rounded-3xl border border-border bg-card p-8 text-center">
        <Trophy className="mx-auto h-10 w-10 text-[#F59E0B]" />
        <h1 className="mt-3 font-heading text-2xl font-bold">Interview Report</h1>
        <p className="text-sm text-muted-foreground">{type} · {level} · {job}</p>
        <div className="mt-6 flex justify-center">
          <ScoreRing value={overall} size={180} stroke={12} label={`${overall}`} sub="OVERALL / 100" testId="interview-overall-ring" />
        </div>
        <div className="mt-8 grid gap-4 text-left sm:grid-cols-2">
          <div className="rounded-2xl bg-[#10B981]/5 p-4">
            <p className="mb-2 text-sm font-semibold text-[#10B981]">Strengths</p>
            {(strengths.length ? strengths : ["Consistency across answers"]).map((s) => (
              <p key={s} className="flex items-center gap-2 py-0.5 text-sm">✓ {s}</p>
            ))}
          </div>
          <div className="rounded-2xl bg-[#F59E0B]/5 p-4">
            <p className="mb-2 text-sm font-semibold text-[#F59E0B]">Improve</p>
            {(improve.length ? improve : ["Keep answers under 2 minutes"]).map((s) => (
              <p key={s} className="flex items-center gap-2 py-0.5 text-sm">⚠ {s}</p>
            ))}
          </div>
        </div>

        <div className="mt-6 rounded-2xl border border-border p-5 text-left">
          <p className="mb-3 font-heading text-sm font-semibold">Personalized Practice Plan</p>
          <ol className="list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
            <li>Rewrite your top 3 project stories in STAR format with one metric each — practice aloud twice.</li>
            <li>Run one Technical set focused on {dims.depth <= dims.impact ? "depth: explain trade-offs, not just choices" : "impact: close every story with a number"}.</li>
            <li>Re-take this mock in 3 days — target: every dimension above 8/10.</li>
          </ol>
        </div>

        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Button variant="outline" className="rounded-full" onClick={() => setPhase("setup")} data-testid="practice-again-btn">
            <RotateCcw className="mr-1 h-4 w-4" /> Practice again
          </Button>
          <Link to="/app"><Button className="rounded-full" data-testid="report-dashboard-btn">Back to dashboard</Button></Link>
        </div>
      </motion.div>
    </div>
  );
}
