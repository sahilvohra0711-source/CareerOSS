import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { Check, Sparkles, TriangleAlert, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader, ProgressBar, ScoreRing } from "@/components/career/bits";
import { matchJob, type MatchReport } from "@/services/ai";
import { SAMPLE_JD } from "@/data/demo";
import { useCareer } from "@/context/CareerContext";

export default function JobMatcher() {
  const { data, saveApplication, addActivity } = useCareer();
  const navigate = useNavigate();
  const [resumeId, setResumeId] = useState(data.resumes[0]?.id ?? "");
  const [jd, setJd] = useState("");
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<MatchReport | null>(null);
  const resume = data.resumes.find((r) => r.id === resumeId);

  const analyze = async () => {
    if (!resume || jd.trim().length < 40) {
      toast.error("Pick a resume and paste a full job description (40+ characters).");
      return;
    }
    setLoading(true);
    setReport(null);
    const r = await matchJob(resume, jd);
    setReport(r);
    setLoading(false);
    addActivity(`Matched resume against a job description — ${r.score}%`);
  };

  const saveToTracker = () => {
    if (!report) return;
    const m = jd.match(/—\s*([A-Z][A-Za-z0-9 ]+)/);
    saveApplication({
      id: crypto.randomUUID().slice(0, 8),
      company: m?.[1]?.replace(/\(.*/, "").trim() || "New company",
      position: jd.split("\n")[0].split("—")[0].trim().slice(0, 60) || "Software Engineer",
      location: jd.match(/\(([^)]+)\)/)?.[1] ?? "Remote",
      salary: "", appliedDate: "", status: "saved", match: report.score,
      notes: "Added from Job Matcher",
    });
    toast.success("Saved to your tracker");
    navigate("/app/applications");
  };

  return (
    <div data-testid="job-matcher-page">
      <PageHeader title="Job Matcher" subtitle="Paste a job description. See exactly where you stand — and what to fix." testId="matcher-header" />

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-3xl border border-border bg-card p-5" data-testid="matcher-input-panel">
          <label className="text-sm font-medium">Resume</label>
          <Select value={resumeId} onValueChange={(v: string) => setResumeId(v)}>
            <SelectTrigger className="mt-1.5" data-testid="matcher-resume-select">
              <SelectValue>{(v: string) => data.resumes.find((r) => r.id === v)?.name ?? "Choose a resume"}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {data.resumes.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
            </SelectContent>
          </Select>

          <div className="mt-4 flex items-center justify-between">
            <label className="text-sm font-medium">Job description</label>
            <Button variant="ghost" size="sm" data-testid="load-sample-jd" onClick={() => setJd(SAMPLE_JD)}>
              <Sparkles className="mr-1 h-3.5 w-3.5" /> Load sample JD
            </Button>
          </div>
          <Textarea rows={13} className="mt-1.5 font-mono text-xs" placeholder="Paste the full job description here…"
            value={jd} onChange={(e) => setJd(e.target.value)} data-testid="jd-input" />
          <Button className="mt-4 w-full rounded-full" onClick={() => void analyze()} disabled={loading} data-testid="analyze-match-btn">
            <Wand2 className="mr-1 h-4 w-4" /> {loading ? "Analyzing…" : "Analyze match"}
          </Button>
        </div>

        <div data-testid="matcher-result-panel">
          {loading && (
            <div className="space-y-4 rounded-3xl border border-border bg-card p-6">
              <div className="skeleton-shimmer mx-auto h-36 w-36 rounded-full" />
              <div className="skeleton-shimmer h-4 rounded-full" />
              <div className="skeleton-shimmer h-4 w-2/3 rounded-full" />
              <p className="pt-2 text-center text-sm text-muted-foreground">Comparing your resume against the role…</p>
            </div>
          )}
          {!loading && !report && (
            <div className="flex h-full min-h-72 flex-col items-center justify-center rounded-3xl border border-dashed border-border p-8 text-center" data-testid="matcher-empty">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#22D3EE]/10 text-[#22D3EE]"><Wand2 className="h-6 w-6" /></span>
              <p className="mt-4 font-heading text-lg font-semibold">Your match report appears here</p>
              <p className="mt-1 max-w-xs text-sm text-muted-foreground">Load the sample JD to see a live 94% match analysis in seconds.</p>
            </div>
          )}
          {report && !loading && (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-5 rounded-3xl border border-border bg-card p-6" data-testid="match-report">
              <div className="flex flex-wrap items-center gap-6">
                <ScoreRing value={report.score} size={140} label={`${report.score}%`} sub="MATCH" testId="match-score-ring" />
                <div className="flex-1 space-y-2.5 min-w-48">
                  {report.categories.map((c) => (
                    <div key={c.label}>
                      <div className="mb-1 flex justify-between text-xs">
                        <span className="text-muted-foreground">{c.label}</span>
                        <span className="font-mono">{c.value}%</span>
                      </div>
                      <ProgressBar value={c.value} />
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <p className="mb-2 text-sm font-semibold">You match</p>
                <div className="flex flex-wrap gap-2" data-testid="matched-skills">
                  {report.matched.map((s) => (
                    <span key={s} className="flex items-center gap-1.5 rounded-full bg-[#10B981]/10 px-3 py-1 text-xs font-medium text-[#10B981]">
                      <Check className="h-3 w-3" /> {s}
                    </span>
                  ))}
                  {report.matched.length === 0 && <p className="text-xs text-muted-foreground">No direct skill overlap detected.</p>}
                </div>
              </div>
              <div>
                <p className="mb-2 text-sm font-semibold">Strengthen</p>
                <div className="flex flex-wrap gap-2" data-testid="missing-skills">
                  {report.missing.map((s) => (
                    <span key={s} className="flex items-center gap-1.5 rounded-full bg-[#F59E0B]/10 px-3 py-1 text-xs font-medium text-[#F59E0B]">
                      <TriangleAlert className="h-3 w-3" /> {s}
                    </span>
                  ))}
                  {report.missing.length === 0 && <p className="text-xs text-muted-foreground">Nothing missing — apply with confidence.</p>}
                </div>
              </div>

              <div className="rounded-2xl bg-muted/60 p-4">
                <p className="mb-2 text-sm font-semibold">How to close the gap</p>
                <ul className="list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
                  {report.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button onClick={() => navigate("/app/tailor")} variant="outline" className="rounded-full" data-testid="tailor-from-match-btn">Tailor my resume →</Button>
                <Button onClick={saveToTracker} className="rounded-full" data-testid="save-to-tracker-btn">Save to tracker</Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
