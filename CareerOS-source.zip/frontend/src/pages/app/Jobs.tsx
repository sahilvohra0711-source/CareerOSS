import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { Bookmark, Compass, Search, Send, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { PageHeader, ScoreRing } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import { celebrate } from "@/lib/confetti";

const TONES = ["#5B5FEF", "#7C3AED", "#22D3EE", "#10B981", "#F59E0B", "#F43F5E"];

export default function Jobs() {
  const { data, saveApplication, addActivity, pushNotification } = useCareer();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [saved, setSaved] = useState<Set<string>>(new Set());

  const jobs = data.jobs.filter((j) =>
    !query || `${j.title} ${j.company} ${j.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase()));

  const track = (jobId: string, status: "saved" | "applied") => {
    const j = data.jobs.find((x) => x.id === jobId);
    if (!j || saved.has(jobId + status)) return;
    saveApplication({
      id: crypto.randomUUID().slice(0, 8), company: j.company, position: j.title,
      location: j.location, salary: j.salary,
      appliedDate: status === "applied" ? new Date().toISOString().slice(0, 10) : "",
      status, match: j.match,
    });
    setSaved((s) => new Set(s).add(jobId + status));
    addActivity(status === "applied" ? `Applied to ${j.title} at ${j.company}` : `Saved ${j.title} at ${j.company}`);
    if (status === "applied") {
      celebrate();
      toast.success("✓ Application saved. Good luck!");
      pushNotification(`Applied to ${j.title} at ${j.company} — ${j.match}% match.`, "success");
    } else {
      toast.success("Saved to your pipeline");
    }
  };

  return (
    <div data-testid="jobs-page">
      <PageHeader title="Job Discovery" subtitle="Curated roles matched to your profile — demo data, real workflow." testId="jobs-header" />

      <div className="relative mb-6 max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input className="pl-9" placeholder="Search title, company or skill…" value={query}
          onChange={(e) => setQuery(e.target.value)} data-testid="jobs-search" />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {jobs.map((j, i) => (
          <motion.div key={j.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            className="card-lift flex gap-4 rounded-3xl border border-border bg-card p-5"
            data-testid={`job-card-${j.company.toLowerCase().replace(/\s/g, "-")}`}>
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl font-heading text-lg font-bold text-white"
              style={{ background: TONES[i % TONES.length] }}>
              {j.company.slice(0, 1)}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="truncate font-heading font-semibold">{j.title}</h3>
                  <p className="text-sm text-muted-foreground">{j.company} · {j.location}</p>
                </div>
                <ScoreRing value={j.match} size={54} stroke={5} label={`${j.match}%`} testId={`job-match-${j.id}`} />
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className="font-mono text-xs text-[#22D3EE]">{j.salary}</span>
                <Badge variant="secondary" className="text-[10px]">{j.type}</Badge>
                <span className="text-[10px] text-muted-foreground">· {j.posted}</span>
                {j.tags.map((t) => (
                  <span key={t} className="rounded-full bg-muted px-2 py-0.5 text-[10px] text-muted-foreground">{t}</span>
                ))}
              </div>
              <div className="mt-3 flex gap-2">
                <Button size="sm" variant="outline" className="rounded-full" disabled={saved.has(j.id + "saved")}
                  data-testid={`job-save-${j.id}`} onClick={() => track(j.id, "saved")}>
                  <Bookmark className="mr-1 h-3.5 w-3.5" /> {saved.has(j.id + "saved") ? "Saved" : "Save"}
                </Button>
                <Button size="sm" className="rounded-full" disabled={saved.has(j.id + "applied")}
                  data-testid={`job-apply-${j.id}`} onClick={() => track(j.id, "applied")}>
                  <Send className="mr-1 h-3.5 w-3.5" /> {saved.has(j.id + "applied") ? "Applied" : "Apply"}
                </Button>
                <Button size="sm" variant="ghost" className="rounded-full" data-testid={`job-analyze-${j.id}`}
                  onClick={() => navigate("/app/matcher")}>
                  <Wand2 className="mr-1 h-3.5 w-3.5" /> Analyze
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
        {jobs.length === 0 && (
          <div className="col-span-full flex flex-col items-center rounded-3xl border border-dashed border-border py-14 text-center" data-testid="jobs-empty">
            <Compass className="h-8 w-8 text-muted-foreground" />
            <p className="mt-3 font-heading font-semibold">No roles match “{query}”</p>
            <p className="mt-1 text-sm text-muted-foreground">Try a broader search — or clear it to see all {data.jobs.length} roles.</p>
          </div>
        )}
      </div>
    </div>
  );
}
