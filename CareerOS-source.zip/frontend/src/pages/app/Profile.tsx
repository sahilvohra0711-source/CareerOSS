import { useState } from "react";
import { Github, Globe, Linkedin, MapPin, Pencil } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PageHeader, ProgressBar, ScoreRing } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";

export default function Profile() {
  const { data, updateProfile } = useCareer();
  const p = data.profile;
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(p);

  const main = data.resumes[0];
  const sections = main
    ? [main.summary, main.experience.length > 0 ? "x" : "", main.education.length > 0 ? "x" : "", main.projects.length > 0 ? "x" : "", main.skills.length > 5 ? "x" : "", main.certifications.length > 0 ? "x" : ""]
    : [];
  const completion = sections.length ? Math.round((sections.filter(Boolean).length / sections.length) * 100) : 0;

  const save = () => {
    updateProfile({ ...form, firstName: form.name.split(" ")[0] });
    toast.success("Profile updated");
    setOpen(false);
  };

  return (
    <div className="mx-auto max-w-3xl" data-testid="profile-page">
      <PageHeader title="Profile" subtitle="How CareerOS — and recruiters — see you." testId="profile-header" />

      <div className="rounded-3xl border border-border bg-card p-6">
        <div className="flex flex-wrap items-center gap-5">
          <img src={p.avatarUrl} alt={p.name} className="h-20 w-20 rounded-3xl object-cover ring-2 ring-[#5B5FEF]/50" data-testid="profile-avatar" />
          <div className="min-w-0 flex-1">
            <h2 className="font-heading text-2xl font-bold" data-testid="profile-name">{p.name}</h2>
            <p className="text-sm text-muted-foreground">{p.targetRole} · {p.experience} experience</p>
            <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="h-3 w-3" /> {p.location}</p>
          </div>
          <Button variant="outline" className="rounded-full" onClick={() => { setForm(p); setOpen(true); }} data-testid="edit-profile-btn">
            <Pencil className="mr-1 h-3.5 w-3.5" /> Edit profile
          </Button>
        </div>
        <div className="mt-5 flex flex-wrap gap-2 border-t border-border pt-4">
          {([["LinkedIn", p.linkedin, Linkedin], ["GitHub", p.github, Github], ["Portfolio", p.portfolio, Globe]] as const).map(([label, url, Icon]) => (
            <a key={label} href={`https://${url}`} target="_blank" rel="noreferrer" data-testid={`profile-link-${label.toLowerCase()}`}
              className="flex items-center gap-2 rounded-full border border-border px-3.5 py-1.5 text-xs text-muted-foreground transition-colors hover:border-[#5B5FEF]/50 hover:text-foreground">
              <Icon className="h-3.5 w-3.5" /> {label}
            </a>
          ))}
        </div>
      </div>

      <div className="mt-5 grid gap-5 sm:grid-cols-2">
        <div className="flex flex-col items-center rounded-3xl border border-border bg-card p-6" data-testid="profile-completion-card">
          <ScoreRing value={completion} size={130} sub="RESUME COMPLETE" testId="profile-completion-ring" />
          <p className="mt-3 text-center text-xs text-muted-foreground">
            {completion >= 90 ? "Fully built out — nice." : "Add certifications and projects to hit 100%."}
          </p>
        </div>
        <div className="flex flex-col items-center rounded-3xl border border-border bg-card p-6" data-testid="profile-readiness-card">
          <ScoreRing value={data.readiness.overall} size={130} sub="CAREER READINESS" />
          <p className="mt-3 text-center text-xs text-muted-foreground">Top 12% of Software Engineer candidates on this track.</p>
        </div>
      </div>

      <div className="mt-5 rounded-3xl border border-border bg-card p-6" data-testid="profile-skills-card">
        <h3 className="mb-3 font-heading font-semibold">Skills</h3>
        <div className="flex flex-wrap gap-2">
          {data.skills.map((s) => (
            <span key={s.name} className="rounded-full bg-[#5B5FEF]/10 px-3 py-1 text-xs font-medium text-[#5B5FEF]">{s.name}</span>
          ))}
        </div>
      </div>

      <div className="mt-5 rounded-3xl border border-border bg-card p-6" data-testid="profile-activity-card">
        <h3 className="mb-3 font-heading font-semibold">Readiness breakdown</h3>
        <div className="space-y-3">
          {data.readiness.breakdown.map((b) => (
            <div key={b.label} className="flex items-center gap-3">
              <span className="w-28 shrink-0 text-xs text-muted-foreground">{b.label}</span>
              <ProgressBar value={b.value} className="flex-1" />
              <span className="w-9 text-right font-mono text-xs">{b.value}%</span>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent data-testid="edit-profile-dialog">
          <DialogHeader><DialogTitle className="font-heading">Edit profile</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Name</Label><Input className="mt-1" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="profile-form-name" /></div>
            <div><Label>Target role</Label><Input className="mt-1" value={form.targetRole} onChange={(e) => setForm({ ...form, targetRole: e.target.value })} /></div>
            <div><Label>Location</Label><Input className="mt-1" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
            <div><Label>Experience</Label><Input className="mt-1" value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} /></div>
            <div className="col-span-2"><Label>LinkedIn</Label><Input className="mt-1" value={form.linkedin} onChange={(e) => setForm({ ...form, linkedin: e.target.value })} /></div>
            <div className="col-span-2"><Label>GitHub</Label><Input className="mt-1" value={form.github} onChange={(e) => setForm({ ...form, github: e.target.value })} /></div>
            <div className="col-span-2"><Label>Portfolio</Label><Input className="mt-1" value={form.portfolio} onChange={(e) => setForm({ ...form, portfolio: e.target.value })} /></div>
          </div>
          <DialogFooter><Button onClick={save} data-testid="profile-form-save">Save profile</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
