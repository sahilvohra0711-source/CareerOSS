import { useState } from "react";
import { motion } from "motion/react";
import { Copy, ExternalLink, Github, Pencil, Plus, Rocket, Sparkles, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyState, PageHeader, TypingDots } from "@/components/career/bits";
import { generateProjectDescription } from "@/services/ai";
import { useCareer } from "@/context/CareerContext";
import type { Project } from "@/lib/types";

const GRADIENTS = [
  "linear-gradient(135deg,#5B5FEF,#7C3AED)",
  "linear-gradient(135deg,#22D3EE,#5B5FEF)",
  "linear-gradient(135deg,#7C3AED,#F43F5E)",
  "linear-gradient(135deg,#10B981,#22D3EE)",
];

const blank: Project = { id: "", name: "", description: "", tech: [], github: "", demo: "", role: "", achievements: [] };

export default function Projects() {
  const { data, saveProject, deleteProject, addActivity } = useCareer();
  const [editing, setEditing] = useState<Project | null>(null);
  const [aiFor, setAiFor] = useState<Project | null>(null);
  const [aiOut, setAiOut] = useState<Record<string, string>>({});
  const [aiLoading, setAiLoading] = useState(false);

  const save = () => {
    if (!editing) return;
    if (!editing.name.trim()) { toast.error("Project name is required."); return; }
    const isNew = !editing.id;
    saveProject({ ...editing, id: editing.id || crypto.randomUUID().slice(0, 8) });
    if (isNew) addActivity(`Added project “${editing.name}” to portfolio`);
    toast.success("Project saved");
    setEditing(null);
  };

  const generate = async (variant: "resume" | "linkedin" | "github") => {
    if (!aiFor) return;
    setAiLoading(true);
    const out = await generateProjectDescription(aiFor, variant);
    setAiOut((o) => ({ ...o, [variant]: out }));
    setAiLoading(false);
  };

  return (
    <div data-testid="projects-page">
      <PageHeader title="Portfolio & Projects" subtitle="Proof of work, framed for recruiters — with AI-written descriptions for every channel."
        testId="projects-header"
        actions={<Button className="rounded-full" data-testid="add-project-btn" onClick={() => setEditing({ ...blank })}><Plus className="mr-1 h-4 w-4" /> Add project</Button>} />

      {data.projects.length === 0 ? (
        <EmptyState icon={<Rocket className="h-6 w-6" />} title="No projects yet"
          subtitle="Projects are the strongest signal on a junior-to-mid resume."
          testId="projects-empty"
          action={<Button onClick={() => setEditing({ ...blank })}>Add your first project</Button>} />
      ) : (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {data.projects.map((p, i) => (
            <motion.div key={p.id} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className="card-lift flex flex-col overflow-hidden rounded-3xl border border-border bg-card"
              data-testid={`project-card-${p.name.toLowerCase().replace(/\s/g, "-")}`}>
              <div className="relative flex h-28 items-end p-4" style={{ background: GRADIENTS[i % GRADIENTS.length] }}>
                <span className="font-heading text-4xl font-black text-white/25">{p.name.slice(0, 1)}</span>
                <div className="absolute right-4 top-4 flex gap-1.5">
                  {p.github && (
                    <a href={`https://${p.github}`} target="_blank" rel="noreferrer" aria-label="GitHub"
                      className="flex h-8 w-8 items-center justify-center rounded-lg bg-black/30 text-white backdrop-blur transition-colors hover:bg-black/50"
                      data-testid={`project-github-${p.id}`}>
                      <Github className="h-4 w-4" />
                    </a>
                  )}
                  {p.demo && (
                    <a href={`https://${p.demo}`} target="_blank" rel="noreferrer" aria-label="Live demo"
                      className="flex h-8 w-8 items-center justify-center rounded-lg bg-black/30 text-white backdrop-blur transition-colors hover:bg-black/50"
                      data-testid={`project-demo-${p.id}`}>
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                </div>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-heading text-lg font-semibold">{p.name}</h3>
                  {p.role && <span className="shrink-0 rounded-full bg-muted px-2.5 py-0.5 text-[10px] font-medium text-muted-foreground">{p.role}</span>}
                </div>
                <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{p.description}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {p.tech.map((t) => (
                    <span key={t} className="rounded-full bg-[#5B5FEF]/10 px-2.5 py-0.5 text-[11px] font-medium text-[#5B5FEF]">{t}</span>
                  ))}
                </div>
                {p.achievements.length > 0 && (
                  <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
                    {p.achievements.slice(0, 2).map((a, j) => <li key={j}>▸ {a}</li>)}
                  </ul>
                )}
                <div className="mt-4 flex items-center gap-1.5 border-t border-border pt-3">
                  <Button size="sm" variant="outline" className="rounded-full" data-testid={`project-ai-${p.id}`}
                    onClick={() => { setAiFor(p); setAiOut({}); }}>
                    <Sparkles className="mr-1 h-3.5 w-3.5" /> AI descriptions
                  </Button>
                  <div className="ml-auto flex gap-1">
                    <Button size="icon-sm" variant="ghost" aria-label="Edit project" data-testid={`project-edit-${p.id}`} onClick={() => setEditing(p)}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon-sm" variant="ghost" aria-label="Delete project" className="text-destructive" data-testid={`project-delete-${p.id}`}
                      onClick={() => { deleteProject(p.id); toast("Project deleted"); }}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg" data-testid="project-dialog">
          <DialogHeader><DialogTitle className="font-heading">{editing?.id ? "Edit project" : "Add project"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label>Project name</Label><Input className="mt-1" value={editing.name} data-testid="project-form-name" onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
              <div className="col-span-2"><Label>Description</Label><Textarea className="mt-1" rows={2} value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
              <div className="col-span-2"><Label>Technologies (comma separated)</Label><Input className="mt-1" value={editing.tech.join(", ")} onChange={(e) => setEditing({ ...editing, tech: e.target.value.split(",").map((t) => t.trim()).filter(Boolean) })} /></div>
              <div><Label>GitHub URL</Label><Input className="mt-1" placeholder="github.com/…" value={editing.github ?? ""} onChange={(e) => setEditing({ ...editing, github: e.target.value })} /></div>
              <div><Label>Live demo</Label><Input className="mt-1" placeholder="myapp.dev" value={editing.demo ?? ""} onChange={(e) => setEditing({ ...editing, demo: e.target.value })} /></div>
              <div className="col-span-2"><Label>Your role</Label><Input className="mt-1" placeholder="Solo builder, Lead developer…" value={editing.role} onChange={(e) => setEditing({ ...editing, role: e.target.value })} /></div>
              <div className="col-span-2"><Label>Achievements (one per line)</Label><Textarea className="mt-1" rows={2} value={editing.achievements.join("\n")} onChange={(e) => setEditing({ ...editing, achievements: e.target.value.split("\n").filter(Boolean) })} /></div>
            </div>
          )}
          <div className="mt-4 flex justify-end"><Button onClick={save} data-testid="project-form-save">Save project</Button></div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!aiFor} onOpenChange={(o) => !o && setAiFor(null)}>
        <DialogContent className="max-w-xl" data-testid="project-ai-dialog">
          <DialogHeader><DialogTitle className="font-heading">AI descriptions — {aiFor?.name}</DialogTitle></DialogHeader>
          <Tabs defaultValue="resume" onValueChange={(v: string) => { const k = v as "resume" | "linkedin" | "github"; if (!aiOut[k]) void generate(k); }}>
            <TabsList className="w-full">
              <TabsTrigger value="resume" className="flex-1" data-testid="ai-tab-resume">Resume</TabsTrigger>
              <TabsTrigger value="linkedin" className="flex-1" data-testid="ai-tab-linkedin">LinkedIn</TabsTrigger>
              <TabsTrigger value="github" className="flex-1" data-testid="ai-tab-github">GitHub</TabsTrigger>
            </TabsList>
            {(["resume", "linkedin", "github"] as const).map((v) => (
              <TabsContent key={v} value={v}>
                <div className="min-h-40 rounded-2xl border border-border bg-muted/40 p-4" data-testid={`ai-output-${v}`}>
                  {aiOut[v] ? (
                    <p className="whitespace-pre-line text-sm leading-relaxed">{aiOut[v]}</p>
                  ) : aiLoading ? (
                    <TypingDots label="Writing" />
                  ) : (
                    <p className="text-sm text-muted-foreground">Generating…</p>
                  )}
                </div>
                {aiOut[v] && (
                  <Button size="sm" variant="outline" className="mt-3 rounded-full" data-testid={`ai-copy-${v}`}
                    onClick={() => { void navigator.clipboard.writeText(aiOut[v]); toast.success("Copied"); }}>
                    <Copy className="mr-1 h-3.5 w-3.5" /> Copy {v} version
                  </Button>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
