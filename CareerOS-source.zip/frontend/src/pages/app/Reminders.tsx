import { useState } from "react";
import { BellRing, CalendarClock, CheckCircle2, Circle, Mic, Plus, Send, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState, PageHeader } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import type { Reminder } from "@/lib/types";
import { cn } from "@/lib/utils";

const TYPE_META = {
  "follow-up": { icon: Send, tone: "#22D3EE", label: "Follow-up" },
  application: { icon: BellRing, tone: "#5B5FEF", label: "Application" },
  interview: { icon: Mic, tone: "#7C3AED", label: "Interview" },
  other: { icon: CalendarClock, tone: "#F59E0B", label: "Other" },
} as const;

export default function Reminders() {
  const { data, saveReminder, deleteReminder } = useCareer();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", date: "", type: "follow-up" as Reminder["type"], note: "" });

  const today = new Date().toISOString().slice(0, 10);
  const pending = data.reminders.filter((r) => !r.done).sort((a, b) => a.date.localeCompare(b.date));
  const doneList = data.reminders.filter((r) => r.done);

  const add = () => {
    if (!form.title.trim() || !form.date) { toast.error("Title and date are required."); return; }
    saveReminder({ id: crypto.randomUUID().slice(0, 8), done: false, ...form });
    toast.success("Reminder created 🔔");
    setOpen(false);
    setForm({ title: "", date: "", type: "follow-up", note: "" });
  };

  const Row = ({ r }: { r: Reminder }) => {
    const m = TYPE_META[r.type];
    const overdue = !r.done && r.date < today;
    return (
      <div className={cn("flex items-center gap-4 rounded-2xl border bg-card p-4", overdue ? "border-[#F59E0B]/40" : "border-border")}
        data-testid={`reminder-${r.id}`}>
        <button aria-label={r.done ? "Mark not done" : "Mark done"} data-testid={`reminder-toggle-${r.id}`}
          onClick={() => { saveReminder({ ...r, done: !r.done }); toast.success(r.done ? "Reopened" : "✓ Done — nice follow-through"); }}
          className={cn("shrink-0 transition-colors", r.done ? "text-[#10B981]" : "text-muted-foreground hover:text-[#10B981]")}>
          {r.done ? <CheckCircle2 className="h-5 w-5" /> : <Circle className="h-5 w-5" />}
        </button>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl" style={{ background: `${m.tone}1a`, color: m.tone }}>
          <m.icon className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className={cn("truncate text-sm font-medium", r.done && "text-muted-foreground line-through")}>{r.title}</p>
          {r.note && <p className="truncate text-xs text-muted-foreground">{r.note}</p>}
        </div>
        <span className={cn("shrink-0 rounded-full px-2.5 py-1 font-mono text-[11px]",
          overdue ? "bg-[#F59E0B]/10 text-[#F59E0B]" : "bg-muted text-muted-foreground")}>
          {overdue ? "Overdue · " : ""}{r.date}
        </span>
        <button aria-label="Delete reminder" className="shrink-0 text-muted-foreground transition-colors hover:text-destructive"
          data-testid={`reminder-delete-${r.id}`}
          onClick={() => { deleteReminder(r.id); toast("Reminder deleted"); }}>
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    );
  };

  return (
    <div className="mx-auto max-w-3xl" data-testid="reminders-page">
      <PageHeader title="Follow-up Reminders" subtitle="The fortune is in the follow-up — never let one slip."
        testId="reminders-header"
        actions={<Button className="rounded-full" data-testid="add-reminder-btn" onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New reminder</Button>} />

      {data.reminders.length === 0 ? (
        <EmptyState icon={<BellRing className="h-6 w-6" />} title="No reminders yet"
          subtitle="Follow-ups double reply rates. Set your first one."
          testId="reminders-empty"
          action={<Button onClick={() => setOpen(true)}>Create a reminder</Button>} />
      ) : (
        <>
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Upcoming ({pending.length})</h2>
          <div className="space-y-3">{pending.map((r) => <Row key={r.id} r={r} />)}</div>
          {doneList.length > 0 && (
            <>
              <h2 className="mb-3 mt-8 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Completed ({doneList.length})</h2>
              <div className="space-y-3 opacity-70">{doneList.map((r) => <Row key={r.id} r={r} />)}</div>
            </>
          )}
        </>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent data-testid="reminder-dialog">
          <DialogHeader><DialogTitle className="font-heading">New reminder</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Title</Label><Input className="mt-1.5" placeholder="Follow up with recruiter" value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })} data-testid="reminder-title-input" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Date</Label><Input className="mt-1.5" type="date" value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })} data-testid="reminder-date-input" /></div>
              <div>
                <Label>Type</Label>
                <Select value={form.type} onValueChange={(v: string) => setForm({ ...form, type: v as Reminder["type"] })}>
                  <SelectTrigger className="mt-1.5" data-testid="reminder-type-select">
                    <SelectValue>{(v: string) => TYPE_META[v as Reminder["type"]].label}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(TYPE_META).map(([k, m]) => <SelectItem key={k} value={k}>{m.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Note (optional)</Label><Input className="mt-1.5" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></div>
          </div>
          <DialogFooter><Button onClick={add} data-testid="reminder-save-btn">Create reminder</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
