import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { ArrowDown, ArrowLeft, ArrowUp, Download, Plus, Save, ScanSearch, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ResumePreview } from "@/components/career/ResumePreview";
import { useCareer } from "@/context/CareerContext";
import { celebrate } from "@/lib/confetti";
import type { Experience, Resume, ResumeTemplate } from "@/lib/types";

const TEMPLATES: ResumeTemplate[] = ["modern", "minimal", "professional", "tech", "executive"];

export default function ResumeBuilder() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const { data, saveResume, addActivity } = useCareer();
  const navigate = useNavigate();
  const source = data.resumes.find((r) => r.id === id);
  const [draft, setDraft] = useState<Resume | null>(source ?? null);

  useEffect(() => { if (source && !draft) setDraft(source); }, [source, draft]);
  useEffect(() => {
    if (params.get("print") === "1") {
      const t = setTimeout(() => window.print(), 600);
      return () => clearTimeout(t);
    }
  }, [params]);

  const upd = useMemo(() => (fn: (r: Resume) => Resume) => setDraft((d) => (d ? fn(d) : d)), []);

  if (!draft)
    return (
      <div className="py-20 text-center" data-testid="resume-not-found">
        <p className="text-muted-foreground">Resume not found.</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate("/app/resumes")}>Back to resumes</Button>
      </div>
    );

  const save = () => {
    saveResume(draft);
    addActivity(`Updated resume “${draft.name}”`);
    toast.success("🎉 Resume saved!");
    celebrate();
  };

  const setExp = (eid: string, patch: Partial<Experience>) =>
    upd((r) => ({ ...r, experience: r.experience.map((e) => (e.id === eid ? { ...e, ...patch } : e)) }));

  const moveExp = (idx: number, dir: -1 | 1) =>
    upd((r) => {
      const exp = [...r.experience];
      const j = idx + dir;
      if (j < 0 || j >= exp.length) return r;
      [exp[idx], exp[j]] = [exp[j], exp[idx]];
      return { ...r, experience: exp };
    });

  const personalFields: [keyof Resume["personal"], string][] = [
    ["fullName", "Full name"], ["title", "Title"], ["email", "Email"], ["phone", "Phone"],
    ["location", "Location"], ["website", "Website"], ["linkedin", "LinkedIn"],
  ];

  return (
    <div data-testid="resume-builder-page">
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Button variant="ghost" size="icon" aria-label="Back" data-testid="builder-back-btn" onClick={() => navigate("/app/resumes")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <Input value={draft.name} onChange={(e) => upd((r) => ({ ...r, name: e.target.value }))}
          className="w-64 border-transparent bg-transparent font-heading text-lg font-semibold hover:border-border focus:border-border"
          data-testid="builder-name-input" aria-label="Resume name" />
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" data-testid="builder-ats-btn" onClick={() => navigate("/app/ats")}>
            <ScanSearch className="mr-1 h-4 w-4" /> ATS check
          </Button>
          <Button variant="outline" size="sm" data-testid="builder-download-btn" onClick={() => { saveResume(draft); setTimeout(() => window.print(), 150); }}>
            <Download className="mr-1 h-4 w-4" /> Download PDF
          </Button>
          <Button size="sm" data-testid="builder-save-btn" onClick={save}><Save className="mr-1 h-4 w-4" /> Save</Button>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <div className="rounded-3xl border border-border bg-card p-5" data-testid="builder-editor">
          <Tabs defaultValue="personal">
            <TabsList className="mb-4 flex w-full flex-wrap">
              {["personal", "summary", "experience", "education", "projects", "skills", "more"].map((t) => (
                <TabsTrigger key={t} value={t} className="capitalize" data-testid={`tab-${t}`}>{t}</TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value="personal" className="space-y-3">
              {personalFields.map(([key, label]) => (
                <div key={key}>
                  <Label>{label}</Label>
                  <Input className="mt-1" value={draft.personal[key]} data-testid={`personal-${key}`}
                    onChange={(e) => upd((r) => ({ ...r, personal: { ...r.personal, [key]: e.target.value } }))} />
                </div>
              ))}
            </TabsContent>

            <TabsContent value="summary">
              <Label>Professional summary</Label>
              <Textarea rows={8} className="mt-1" value={draft.summary} data-testid="summary-input"
                onChange={(e) => upd((r) => ({ ...r, summary: e.target.value }))} />
              <p className="mt-2 text-xs text-muted-foreground">2–3 sentences. Lead with years of experience and your strongest metric.</p>
            </TabsContent>

            <TabsContent value="experience" className="space-y-4">
              {draft.experience.map((e, i) => (
                <div key={e.id} className="rounded-2xl border border-border p-4" data-testid={`exp-editor-${i}`}>
                  <div className="mb-3 flex items-center justify-between">
                    <p className="text-sm font-semibold">{e.role || "New role"} · {e.company}</p>
                    <div className="flex gap-1">
                      <Button size="icon-xs" variant="ghost" aria-label="Move up" onClick={() => moveExp(i, -1)}><ArrowUp className="h-3.5 w-3.5" /></Button>
                      <Button size="icon-xs" variant="ghost" aria-label="Move down" onClick={() => moveExp(i, 1)}><ArrowDown className="h-3.5 w-3.5" /></Button>
                      <Button size="icon-xs" variant="ghost" aria-label="Delete role" className="text-destructive"
                        onClick={() => upd((r) => ({ ...r, experience: r.experience.filter((x) => x.id !== e.id) }))}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Input placeholder="Role" value={e.role} onChange={(ev) => setExp(e.id, { role: ev.target.value })} />
                    <Input placeholder="Company" value={e.company} onChange={(ev) => setExp(e.id, { company: ev.target.value })} />
                    <Input placeholder="Start (2022)" value={e.start} onChange={(ev) => setExp(e.id, { start: ev.target.value })} />
                    <Input placeholder="End (Present)" value={e.current ? "Present" : e.end} onChange={(ev) => setExp(e.id, { end: ev.target.value, current: ev.target.value.toLowerCase() === "present" })} />
                  </div>
                  <Textarea rows={4} className="mt-2" placeholder={"One bullet per line.\nLead with a verb, end with a metric."}
                    value={e.bullets.join("\n")} data-testid={`exp-bullets-${i}`}
                    onChange={(ev) => setExp(e.id, { bullets: ev.target.value.split("\n") })} />
                </div>
              ))}
              <Button variant="outline" className="w-full" data-testid="add-experience-btn"
                onClick={() => upd((r) => ({ ...r, experience: [...r.experience, { id: crypto.randomUUID().slice(0, 8), company: "", role: "", location: "", start: "", end: "", bullets: [""] }] }))}>
                <Plus className="mr-1 h-4 w-4" /> Add role
              </Button>
            </TabsContent>

            <TabsContent value="education" className="space-y-3">
              {draft.education.map((ed, i) => (
                <div key={ed.id} className="grid grid-cols-2 gap-2 rounded-2xl border border-border p-4" data-testid={`edu-editor-${i}`}>
                  <Input placeholder="School" value={ed.school} onChange={(e) => upd((r) => ({ ...r, education: r.education.map((x) => (x.id === ed.id ? { ...x, school: e.target.value } : x)) }))} />
                  <Input placeholder="Degree (B.S.)" value={ed.degree} onChange={(e) => upd((r) => ({ ...r, education: r.education.map((x) => (x.id === ed.id ? { ...x, degree: e.target.value } : x)) }))} />
                  <Input placeholder="Field" value={ed.field} onChange={(e) => upd((r) => ({ ...r, education: r.education.map((x) => (x.id === ed.id ? { ...x, field: e.target.value } : x)) }))} />
                  <Input placeholder="Years (2016 – 2020)" value={`${ed.start} – ${ed.end}`}
                    onChange={(e) => { const [s, en] = e.target.value.split("–").map((x) => x.trim()); upd((r) => ({ ...r, education: r.education.map((x) => (x.id === ed.id ? { ...x, start: s ?? "", end: en ?? "" } : x)) })); }} />
                </div>
              ))}
              <Button variant="outline" className="w-full" data-testid="add-education-btn"
                onClick={() => upd((r) => ({ ...r, education: [...r.education, { id: crypto.randomUUID().slice(0, 8), school: "", degree: "", field: "", start: "", end: "" }] }))}>
                <Plus className="mr-1 h-4 w-4" /> Add education
              </Button>
            </TabsContent>

            <TabsContent value="projects" className="space-y-3">
              {draft.projects.map((p, i) => (
                <div key={p.id} className="space-y-2 rounded-2xl border border-border p-4" data-testid={`proj-editor-${i}`}>
                  <div className="flex gap-2">
                    <Input placeholder="Project name" value={p.name} onChange={(e) => upd((r) => ({ ...r, projects: r.projects.map((x) => (x.id === p.id ? { ...x, name: e.target.value } : x)) }))} />
                    <Button size="icon" variant="ghost" aria-label="Delete project" className="shrink-0 text-destructive"
                      onClick={() => upd((r) => ({ ...r, projects: r.projects.filter((x) => x.id !== p.id) }))}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <Textarea rows={2} placeholder="What it does + impact" value={p.description}
                    onChange={(e) => upd((r) => ({ ...r, projects: r.projects.map((x) => (x.id === p.id ? { ...x, description: e.target.value } : x)) }))} />
                  <Input placeholder="Tech (comma separated)" value={p.tech.join(", ")}
                    onChange={(e) => upd((r) => ({ ...r, projects: r.projects.map((x) => (x.id === p.id ? { ...x, tech: e.target.value.split(",").map((t) => t.trim()).filter(Boolean) } : x)) }))} />
                </div>
              ))}
              <Button variant="outline" className="w-full" data-testid="add-project-btn"
                onClick={() => upd((r) => ({ ...r, projects: [...r.projects, { id: crypto.randomUUID().slice(0, 8), name: "", description: "", tech: [] }] }))}>
                <Plus className="mr-1 h-4 w-4" /> Add project
              </Button>
            </TabsContent>

            <TabsContent value="skills">
              <Label>Skills (comma separated)</Label>
              <Textarea rows={6} className="mt-1" value={draft.skills.join(", ")} data-testid="skills-input"
                onChange={(e) => upd((r) => ({ ...r, skills: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) }))} />
              <p className="mt-2 text-xs text-muted-foreground">Aim for 14–18 skills matching your target role. Exact JD phrasing wins ATS keyword scans.</p>
            </TabsContent>

            <TabsContent value="more" className="space-y-4">
              <div>
                <Label>Certifications (one per line: Name — Issuer — Year)</Label>
                <Textarea rows={4} className="mt-1" data-testid="certs-input"
                  value={draft.certifications.map((c) => `${c.name} — ${c.issuer} — ${c.year}`).join("\n")}
                  onChange={(e) => upd((r) => ({ ...r, certifications: e.target.value.split("\n").filter(Boolean).map((line) => { const [n, iss, y] = line.split("—").map((x) => x.trim()); return { id: crypto.randomUUID().slice(0, 8), name: n ?? "", issuer: iss ?? "", year: y ?? "" }; }) }))} />
              </div>
              <div>
                <Label>Achievements (one per line)</Label>
                <Textarea rows={4} className="mt-1" data-testid="achievements-input"
                  value={draft.achievements.join("\n")}
                  onChange={(e) => upd((r) => ({ ...r, achievements: e.target.value.split("\n") }))} />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-card p-3" data-testid="template-switcher">
            <span className="mr-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Template</span>
            {TEMPLATES.map((t) => (
              <button key={t} onClick={() => upd((r) => ({ ...r, template: t }))} data-testid={`builder-template-${t}`}
                className={`rounded-full px-3.5 py-1.5 text-xs font-medium capitalize transition-colors ${draft.template === t ? "bg-[#5B5FEF] text-white" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
                {t}
              </button>
            ))}
          </div>
          <div className="rounded-3xl border border-border bg-card p-4 sm:p-6" data-testid="builder-preview-pane">
            <ResumePreview resume={draft} printId />
          </div>
        </div>
      </div>
    </div>
  );
}
