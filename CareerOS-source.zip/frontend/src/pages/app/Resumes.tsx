import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Copy, Download, FileText, FileUp, Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { EmptyState, PageHeader, TypingDots } from "@/components/career/bits";
import { uploadResumeFile } from "@/services/ai";
import { useCareer } from "@/context/CareerContext";
import type { Resume, ResumeTemplate } from "@/lib/types";

const TEMPLATES: { id: ResumeTemplate; label: string; hint: string }[] = [
  { id: "modern", label: "Modern", hint: "Indigo accents, bold header" },
  { id: "minimal", label: "Minimal", hint: "Centered, ultra-clean" },
  { id: "professional", label: "Professional", hint: "Dark header band" },
  { id: "tech", label: "Tech", hint: "Mono type, cyan details" },
  { id: "executive", label: "Executive", hint: "Violet, generous spacing" },
];

const blankResume = (name: string, template: ResumeTemplate): Resume => ({
  id: crypto.randomUUID().slice(0, 8),
  name, template,
  updatedAt: new Date().toISOString().slice(0, 10),
  personal: { fullName: "Alex Morgan", title: "Software Engineer", email: "alex.morgan@demo.dev", phone: "", location: "San Francisco, CA", website: "", linkedin: "" },
  summary: "",
  education: [], experience: [], projects: [], skills: [], certifications: [], achievements: [],
});

export default function Resumes() {
  const { data, deleteResume, duplicateResume, saveResume, addActivity } = useCareer();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [template, setTemplate] = useState<ResumeTemplate>("modern");
  const [parsing, setParsing] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = async (file: File) => {
    setParsing(true);
    try {
      const resume = await uploadResumeFile(file);
      saveResume(resume);
      addActivity(`Imported resume from ${file.name}`);
      toast.success("🎉 Resume imported — AI read your file and built the editor for you");
      navigate(`/app/resumes/${resume.id}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't parse that file. Try a text-based PDF or DOCX.");
    } finally {
      setParsing(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const create = () => {
    const r = blankResume(name.trim() || "Untitled Resume", template);
    saveResume(r);
    addActivity(`Created resume “${r.name}”`);
    toast.success("🎉 Resume created successfully!");
    setOpen(false);
    setName("");
    navigate(`/app/resumes/${r.id}`);
  };

  return (
    <div data-testid="resumes-page">
      <PageHeader title="Resumes" subtitle="Create, tailor and export every version of your story."
        testId="resumes-header"
        actions={
          <>
            <input ref={fileRef} type="file" accept=".pdf,.docx,.doc" className="hidden" data-testid="resume-file-input"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) void onFile(f); }} />
            <Button variant="outline" className="rounded-full" data-testid="upload-resume-btn" disabled={parsing}
              onClick={() => fileRef.current?.click()}>
              {parsing ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <FileUp className="mr-1 h-4 w-4" />}
              {parsing ? "Reading your resume…" : "Upload PDF / DOCX"}
            </Button>
            <Button className="rounded-full" data-testid="new-resume-btn" onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New resume</Button>
          </>
        } />

      {parsing && (
        <div className="mb-5 flex items-center gap-4 rounded-2xl border border-[#5B5FEF]/30 bg-[#5B5FEF]/5 p-4" data-testid="resume-parsing-state">
          <TypingDots label="AI is reading your resume — extracting sections, bullets and skills" />
        </div>
      )}

      {data.resumes.length === 0 ? (
        <EmptyState icon={<FileText className="h-6 w-6" />} title="No resumes yet"
          subtitle="Your next opportunity could start with one great resume."
          testId="resumes-empty"
          action={<Button data-testid="empty-new-resume-btn" onClick={() => setOpen(true)}>Create your first resume</Button>} />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {data.resumes.map((r) => (
            <div key={r.id} className="card-lift group flex flex-col rounded-3xl border border-border bg-card p-5" data-testid={`resume-card-${r.id}`}>
              <div className="flex items-start justify-between gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#5B5FEF]/10 text-[#5B5FEF]">
                  <FileText className="h-5 w-5" />
                </span>
                <Badge variant="secondary" className="capitalize">{r.template}</Badge>
              </div>
              <h3 className="mt-4 font-heading text-lg font-semibold leading-snug">{r.name}</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                Updated {r.updatedAt} · {r.experience.length} roles · {r.skills.length} skills
              </p>
              <div className="mt-4 flex items-center gap-1.5 border-t border-border pt-4">
                <Button size="sm" className="flex-1 rounded-full" data-testid={`resume-edit-${r.id}`} onClick={() => navigate(`/app/resumes/${r.id}`)}>
                  <Pencil className="mr-1 h-3.5 w-3.5" /> Edit
                </Button>
                <Button size="icon-sm" variant="outline" aria-label="Duplicate" data-testid={`resume-duplicate-${r.id}`}
                  onClick={() => { duplicateResume(r.id); toast.success("Resume duplicated"); }}>
                  <Copy className="h-3.5 w-3.5" />
                </Button>
                <Button size="icon-sm" variant="outline" aria-label="Download PDF" data-testid={`resume-download-${r.id}`}
                  onClick={() => navigate(`/app/resumes/${r.id}?print=1`)}>
                  <Download className="h-3.5 w-3.5" />
                </Button>
                <Button size="icon-sm" variant="outline" aria-label="Delete" data-testid={`resume-delete-${r.id}`}
                  className="text-destructive hover:bg-destructive/10"
                  onClick={() => { deleteResume(r.id); toast("Resume deleted"); }}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent data-testid="new-resume-dialog">
          <DialogHeader><DialogTitle className="font-heading">New resume</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="resume-name">Resume name</Label>
              <Input id="resume-name" data-testid="new-resume-name" className="mt-1.5" placeholder="e.g. Backend Engineer — Stripe"
                value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <Label>Template</Label>
              <Select value={template} onValueChange={(v: string) => setTemplate(v as ResumeTemplate)}>
                <SelectTrigger className="mt-1.5" data-testid="new-resume-template">
                  <SelectValue>{(v: string) => TEMPLATES.find((t) => t.id === v)?.label ?? "Modern"}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {TEMPLATES.map((t) => (
                    <SelectItem key={t.id} value={t.id} data-testid={`template-${t.id}`}>
                      {t.label} — {t.hint}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button data-testid="create-resume-submit" onClick={create}>Create & open editor</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
