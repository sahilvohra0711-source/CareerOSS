import { motion } from "motion/react";
import { Check, CircleDashed, CircleDot, Flag } from "lucide-react";
import { PageHeader, ProgressBar } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import { cn } from "@/lib/utils";

const META = {
  done: { icon: Check, tone: "#10B981", label: "Completed", copy: "Locked in. This one shows up in your interviews." },
  current: { icon: CircleDot, tone: "#5B5FEF", label: "In progress", copy: "You're here now — keep the streak going." },
  next: { icon: Flag, tone: "#F59E0B", label: "Up next", copy: "Queued automatically based on your target role." },
  upcoming: { icon: CircleDashed, tone: "#64748B", label: "Upcoming", copy: "On the path to Software Engineer, senior track." },
} as const;

export default function Roadmap() {
  const { data } = useCareer();
  const done = data.roadmap.filter((r) => r.status === "done").length;
  const pct = Math.round((done / data.roadmap.length) * 100);

  return (
    <div className="mx-auto max-w-2xl" data-testid="roadmap-page">
      <PageHeader title="Career Roadmap" subtitle={`Your guided path to ${data.profile.targetRole} — and beyond.`} testId="roadmap-header" />

      <div className="mb-8 rounded-3xl border border-border bg-card p-5">
        <div className="mb-2 flex justify-between text-sm">
          <span className="font-medium">{done} of {data.roadmap.length} milestones complete</span>
          <span className="font-mono text-muted-foreground">{pct}%</span>
        </div>
        <ProgressBar value={pct} />
      </div>

      <div className="relative pl-2" data-testid="roadmap-timeline">
        <motion.div
          className="absolute bottom-6 left-[27px] top-2 w-0.5 bg-gradient-to-b from-[#10B981] via-[#5B5FEF] to-border"
          initial={{ scaleY: 0 }} animate={{ scaleY: 1 }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          style={{ transformOrigin: "top" }}
        />
        {data.roadmap.map((item, i) => {
          const m = META[item.status];
          return (
            <motion.div key={item.id}
              initial={{ opacity: 0, x: -18 }} animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.15 + i * 0.08, duration: 0.5 }}
              className="relative mb-4 flex items-center gap-4"
              data-testid={`roadmap-${item.title.toLowerCase().replace(/[\s/]+/g, "-")}`}>
              <span
                className={cn(
                  "relative z-10 flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-2xl border bg-card",
                  item.status === "current" && "pulse-ring",
                )}
                style={{ borderColor: `${m.tone}55`, color: m.tone }}>
                <m.icon className="h-5 w-5" />
              </span>
              <div className={cn(
                "flex-1 rounded-2xl border bg-card p-4 transition-colors",
                item.status === "current" ? "border-[#5B5FEF]/50 shadow-[0_0_24px_-8px_rgba(91,95,239,0.5)]" : "border-border",
              )}>
                <div className="flex items-center justify-between gap-3">
                  <p className="font-heading font-semibold">{item.title}</p>
                  <span className="rounded-full px-2.5 py-0.5 text-[10px] font-semibold" style={{ background: `${m.tone}1a`, color: m.tone }}>
                    {m.label}
                  </span>
                </div>
                <p className="mt-0.5 text-xs text-muted-foreground">{m.copy}</p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
