import { useState } from "react";
import { useTheme } from "next-themes";
import { useQuery } from "@tanstack/react-query";
import { Download, Eye, Moon, RotateCcw, Sun, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { apiGet } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import { endSession } from "@/lib/session";
import { cn } from "@/lib/utils";

function ShareStats() {
  const { data: stats, isError } = useQuery({
    queryKey: ["share-stats"],
    queryFn: () => apiGet<{ total: number; last7d: number; sources: { ref: string; count: number }[] }>("/analytics/stats"),
    retry: false,
    staleTime: 30_000,
  });
  const labelFor = (ref: string) =>
    ref === "direct" || !ref ? "Direct / typed" :
    ref.includes("linkedin") ? "LinkedIn" :
    ref.includes("twitter") || ref.includes("x.com") ? "X / Twitter" :
    (() => { try { return new URL(ref).hostname; } catch { return ref; } })();
  return (
    <div data-testid="share-stats">
      <div className="flex gap-4">
        <div className="flex-1 rounded-2xl border border-border bg-background/60 p-4">
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><Eye className="h-3.5 w-3.5" /> Total visits</p>
          <p className="mt-1 font-heading text-2xl font-bold" data-testid="share-stats-total">{isError ? "—" : stats?.total ?? "…"}</p>
        </div>
        <div className="flex-1 rounded-2xl border border-border bg-background/60 p-4">
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><Eye className="h-3.5 w-3.5" /> Last 7 days</p>
          <p className="mt-1 font-heading text-2xl font-bold text-[#22D3EE]" data-testid="share-stats-week">{isError ? "—" : stats?.last7d ?? "…"}</p>
        </div>
      </div>
      {stats && stats.sources.length > 0 && (
        <div className="mt-3 rounded-2xl border border-border bg-background/60 p-4" data-testid="share-stats-sources">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Where visitors came from</p>
          {stats.sources.map((s) => (
            <p key={s.ref} className="flex items-center justify-between py-1 text-sm">
              <span className="text-muted-foreground">{labelFor(s.ref)}</span>
              <span className="font-mono text-xs font-semibold">{s.count}</span>
            </p>
          ))}
        </div>
      )}
      <a href="/CareerOS-README.md" download="CareerOS-README.md" className="mt-4 inline-flex">
        <Button variant="outline" className="rounded-full" data-testid="download-readme-btn">
          <Download className="mr-1 h-4 w-4" /> Download project README (for GitHub)
        </Button>
      </a>
    </div>
  );
}

function Section({ title, copy, children, testId }: { title: string; copy: string; children: React.ReactNode; testId: string }) {
  return (
    <section className="rounded-3xl border border-border bg-card p-6" data-testid={testId}>
      <h2 className="font-heading text-lg font-semibold">{title}</h2>
      <p className="mb-5 mt-0.5 text-sm text-muted-foreground">{copy}</p>
      {children}
    </section>
  );
}

export default function Settings() {
  const { data, updateProfile, resetDemo } = useCareer();
  const { theme, setTheme } = useTheme();
  const [name, setName] = useState(data.profile.name);
  const [email, setEmail] = useState(data.profile.email);
  const [role, setRole] = useState(data.profile.targetRole);
  const [notif, setNotif] = useState({ matches: true, reminders: true, weekly: false });
  const [aiDepth, setAiDepth] = useState("detailed");

  const exportData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "careeros-export.json";
    a.click();
    toast.success("Your data is downloading as JSON");
  };

  return (
    <div className="mx-auto max-w-2xl space-y-5" data-testid="settings-page">
      <PageHeader title="Settings" subtitle="Your workspace, your rules." testId="settings-header" />

      <Section title="Account" copy="Who you are across CareerOS." testId="settings-account">
        <div className="grid gap-3 sm:grid-cols-2">
          <div><Label>Name</Label><Input className="mt-1.5" value={name} onChange={(e) => setName(e.target.value)} data-testid="settings-name" /></div>
          <div><Label>Email</Label><Input className="mt-1.5" value={email} onChange={(e) => setEmail(e.target.value)} data-testid="settings-email" /></div>
          <div className="sm:col-span-2"><Label>Target role</Label><Input className="mt-1.5" value={role} onChange={(e) => setRole(e.target.value)} data-testid="settings-role" /></div>
        </div>
        <Button className="mt-4 rounded-full" data-testid="settings-save-account"
          onClick={() => { updateProfile({ name, email, targetRole: role, firstName: name.split(" ")[0] }); toast.success("Account updated"); }}>
          Save changes
        </Button>
      </Section>

      <Section title="Appearance" copy="Both themes are crafted — pick your mood." testId="settings-appearance">
        <div className="grid grid-cols-2 gap-3">
          {([{ id: "dark", label: "Dark obsidian", icon: Moon }, { id: "light", label: "Light", icon: Sun }] as const).map((t) => (
            <button key={t.id} onClick={() => setTheme(t.id)} data-testid={`theme-${t.id}`}
              className={cn("flex items-center gap-3 rounded-2xl border p-4 text-left transition-colors",
                (theme ?? "dark") === t.id ? "border-[#5B5FEF] bg-[#5B5FEF]/10" : "border-border hover:border-[#5B5FEF]/40")}>
              <t.icon className="h-4 w-4 text-[#5B5FEF]" />
              <span className="text-sm font-medium">{t.label}</span>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Notifications" copy="What Nova nudges you about." testId="settings-notifications">
        <div className="space-y-3">
          {([
            ["matches", "New job matches above 90%"],
            ["reminders", "Follow-up reminders (same morning)"],
            ["weekly", "Weekly career digest"],
          ] as const).map(([k, label]) => (
            <label key={k} className="flex cursor-pointer items-center gap-3 text-sm">
              <Checkbox checked={notif[k]} onCheckedChange={(c) => setNotif((n) => ({ ...n, [k]: !!c }))} data-testid={`notif-${k}`} />
              {label}
            </label>
          ))}
        </div>
      </Section>

      <Section title="AI Preferences" copy="How the coach and analyzers talk to you." testId="settings-ai">
        <Label>Feedback depth</Label>
        <Select value={aiDepth} onValueChange={(v: string) => setAiDepth(v)}>
          <SelectTrigger className="mt-1.5 max-w-xs" data-testid="ai-depth-select">
            <SelectValue>{(v: string) => ({ concise: "Concise — just the fix", detailed: "Detailed — fix + reasoning", coach: "Coach mode — fix + reasoning + motivation" })[v]}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="concise">Concise — just the fix</SelectItem>
            <SelectItem value="detailed">Detailed — fix + reasoning</SelectItem>
            <SelectItem value="coach">Coach mode — fix + reasoning + motivation</SelectItem>
          </SelectContent>
        </Select>
      </Section>

      <Section title="Share stats" copy="Visits to your CareerOS link — watch the LinkedIn post land." testId="settings-share-stats">
        <ShareStats />
      </Section>

      <Section title="Data Export" copy="Everything in your workspace, as JSON." testId="settings-export">
        <Button variant="outline" className="rounded-full" onClick={exportData} data-testid="export-data-btn">
          <Download className="mr-1 h-4 w-4" /> Export my data
        </Button>
      </Section>

      <section className="rounded-3xl border border-destructive/30 bg-destructive/5 p-6" data-testid="settings-danger">
        <h2 className="font-heading text-lg font-semibold text-destructive">Danger zone</h2>
        <p className="mb-5 mt-0.5 text-sm text-muted-foreground">Reset demo data or wipe this workspace entirely.</p>
        <div className="flex flex-wrap gap-3">
          <Button variant="outline" className="rounded-full" data-testid="reset-demo-btn"
            onClick={() => { resetDemo(); toast.success("Demo data restored to pristine state"); }}>
            <RotateCcw className="mr-1 h-4 w-4" /> Reset demo data
          </Button>
          <Button variant="destructive" className="rounded-full" data-testid="delete-account-btn"
            onClick={() => { localStorage.removeItem("careeros-state-v1"); void endSession(); }}>
            <Trash2 className="mr-1 h-4 w-4" /> Delete account
          </Button>
        </div>
      </section>
    </div>
  );
}
