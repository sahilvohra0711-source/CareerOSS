import { useState } from "react";
import { motion } from "motion/react";
import { Brain, Minus, Plus, Sparkles, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader, ProgressBar } from "@/components/career/bits";
import { useCareer } from "@/context/CareerContext";
import type { Skill } from "@/lib/types";

const TAG_TONE = { Advanced: "#10B981", Intermediate: "#5B5FEF", Beginner: "#F59E0B" } as const;
const LEVEL_FOR = { Beginner: 40, Intermediate: 65, Advanced: 88 } as const;

export default function Skills() {
  const { data, saveSkill, deleteSkill } = useCareer();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [tag, setTag] = useState<Skill["tag"]>("Intermediate");
  const recommended = data.skills.filter((s) => s.recommended);
  const rest = data.skills.filter((s) => !s.recommended);

  const bump = (s: Skill, d: number) => {
    const level = Math.max(5, Math.min(100, s.level + d));
    const newTag: Skill["tag"] = level >= 80 ? "Advanced" : level >= 55 ? "Intermediate" : "Beginner";
    saveSkill({ ...s, level, tag: newTag });
  };

  const add = () => {
    if (!name.trim()) { toast.error("Name the skill first."); return; }
    saveSkill({ name: name.trim(), level: LEVEL_FOR[tag], tag });
    toast.success(`Skill added: ${name.trim()}`);
    setOpen(false); setName("");
  };

  const Card = ({ s }: { s: Skill }) => (
    <motion.div layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      className="card-lift rounded-2xl border border-border bg-card p-5" data-testid={`skill-card-${s.name.toLowerCase().replace(/\s/g, "-")}`}>
      <div className="flex items-center justify-between gap-2">
        <p className="font-heading font-semibold">{s.name}</p>
        <span className="rounded-full px-2.5 py-0.5 text-[10px] font-semibold" style={{ background: `${TAG_TONE[s.tag]}1a`, color: TAG_TONE[s.tag] }}>
          {s.tag}
        </span>
      </div>
      <div className="mt-3 flex items-center gap-3">
        <ProgressBar value={s.level} className="flex-1" color={TAG_TONE[s.tag]} />
        <span className="w-9 text-right font-mono text-xs text-muted-foreground">{s.level}%</span>
      </div>
      <div className="mt-3 flex items-center gap-1">
        <Button size="icon-xs" variant="outline" aria-label="Decrease level" onClick={() => bump(s, -5)}><Minus className="h-3 w-3" /></Button>
        <Button size="icon-xs" variant="outline" aria-label="Increase level" data-testid={`skill-bump-${s.name.toLowerCase().replace(/\s/g, "-")}`} onClick={() => bump(s, 5)}><Plus className="h-3 w-3" /></Button>
        <Button size="icon-xs" variant="ghost" aria-label="Remove skill" className="ml-auto text-muted-foreground hover:text-destructive"
          onClick={() => { deleteSkill(s.name); toast("Skill removed"); }}>
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>
    </motion.div>
  );

  return (
    <div data-testid="skills-page">
      <PageHeader title="Skills Matrix" subtitle={`Benchmarked against your target role: ${data.profile.targetRole}.`}
        testId="skills-header"
        actions={<Button className="rounded-full" data-testid="add-skill-btn" onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> Add skill</Button>} />

      <h2 className="mb-3 flex items-center gap-2 font-heading text-lg font-semibold">
        <Sparkles className="h-4 w-4 text-[#F59E0B]" /> Recommended to close your gap
      </h2>
      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {recommended.map((s) => <Card key={s.name} s={s} />)}
      </div>

      <h2 className="mb-3 flex items-center gap-2 font-heading text-lg font-semibold">
        <Brain className="h-4 w-4 text-[#5B5FEF]" /> Your stack
      </h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {rest.map((s) => <Card key={s.name} s={s} />)}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent data-testid="add-skill-dialog">
          <DialogHeader><DialogTitle className="font-heading">Add a skill</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Skill name</Label><Input className="mt-1.5" placeholder="e.g. Kubernetes" value={name} onChange={(e) => setName(e.target.value)} data-testid="skill-name-input" /></div>
            <div>
              <Label>Current level</Label>
              <Select value={tag} onValueChange={(v: string) => setTag(v as Skill["tag"])}>
                <SelectTrigger className="mt-1.5" data-testid="skill-level-select"><SelectValue>{(v: string) => v}</SelectValue></SelectTrigger>
                <SelectContent>
                  {(["Beginner", "Intermediate", "Advanced"] as const).map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter><Button onClick={add} data-testid="skill-save-btn">Add skill</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
