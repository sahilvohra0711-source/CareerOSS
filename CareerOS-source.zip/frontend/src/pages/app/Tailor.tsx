import { useState } from "react";
import { motion } from "motion/react";
import { Check, Copy, PenLine, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader, TypingDots } from "@/components/career/bits";
import { tailorResume, type TailorSuggestion } from "@/services/ai";
import { SAMPLE_JD } from "@/data/demo";
import { useCareer } from "@/context/CareerContext";
import { celebrate } from "@/lib/confetti";

export default function Tailor() {
  const { data, saveResume, addActivity } = useCareer();
  const [resumeId, setResumeId] = useState(data.resumes[0]?.id ?? "");
  const [jd, setJd] = useState("");
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<TailorSuggestion[] | null>(null);
  const [applied, setApplied] = useState<Set<number>>(new Set());
  const resume = data.resumes.find((r) => r.id === resumeId);

  const generate = async () => {
    if (!resume || jd.trim().length < 40) {
      toast.error("Pick a resume and paste a full job description.");
      return;
    }
    setLoading(true);
    setSuggestions(null);
    setApplied(new Set());
    const s = await tailorResume(resume, jd);
    setSuggestions(s);
    setLoading(false);
  };

  const apply = (s: TailorSuggestion, i: number) => {
    if (!resume) return;
    const updated = {
      ...resume,
      experience: resume.experience.map((e) => ({
        ...e,
        bullets: e.bullets.map((b) => (b === s.original ? s.improved : b)),
      })),
    };
    saveResume(updated);
    setApplied((a) => new Set(a).add(i));
    addActivity(`Tailored a bullet for ${s.company}`);
    toast.success("Bullet updated in your resume");
    celebrate();
  };

  return (
    <div data-testid="tailor-page">
      <PageHeader title="Resume Tailoring" subtitle="Rewrite specific bullets for a specific job — never generic filler." testId="tailor-header" />

      <div className="mb-6 grid gap-4 rounded-3xl border border-border bg-card p-5 lg:grid-cols-2">
        <div>
          <label className="text-sm font-medium">Resume</label>
          <Select value={resumeId} onValueChange={(v: string) => setResumeId(v)}>
            <SelectTrigger className="mt-1.5" data-testid="tailor-resume-select">
              <SelectValue>{(v: string) => data.resumes.find((r) => r.id === v)?.name ?? "Choose a resume"}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {data.resumes.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button className="mt-4 w-full rounded-full lg:w-auto" onClick={() => void generate()} disabled={loading} data-testid="generate-tailor-btn">
            <PenLine className="mr-1 h-4 w-4" /> {loading ? "Generating…" : "Generate tailored bullets"}
          </Button>
          {loading && <div className="mt-3"><TypingDots label="Rewriting bullets" /></div>}
        </div>
        <div>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Job description</label>
            <Button variant="ghost" size="sm" onClick={() => setJd(SAMPLE_JD)} data-testid="tailor-sample-jd">
              <Sparkles className="mr-1 h-3.5 w-3.5" /> Sample JD
            </Button>
          </div>
          <Textarea rows={7} className="mt-1.5 font-mono text-xs" value={jd} onChange={(e) => setJd(e.target.value)}
            placeholder="Paste the job description…" data-testid="tailor-jd-input" />
        </div>
      </div>

      {suggestions && (
        <div className="space-y-4" data-testid="tailor-results">
          {suggestions.map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
              className="rounded-3xl border border-border bg-card p-5" data-testid={`tailor-card-${i}`}>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{s.company}</p>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-2xl bg-muted/50 p-4">
                  <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Original</p>
                  <p className="text-sm text-muted-foreground line-through decoration-[#F43F5E]/60">{s.original}</p>
                </div>
                <div className="rounded-2xl border border-[#10B981]/30 bg-[#10B981]/5 p-4">
                  <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#10B981]">Improved</p>
                  <p className="text-sm">{s.improved}</p>
                </div>
              </div>
              <p className="mt-3 rounded-xl bg-[#5B5FEF]/10 px-3 py-2 text-xs text-[#5B5FEF]">
                <span className="font-semibold">Why this is better:</span> {s.why}
              </p>
              <div className="mt-3 flex gap-2">
                <Button size="sm" variant="outline" className="rounded-full" data-testid={`tailor-copy-${i}`}
                  onClick={() => { void navigator.clipboard.writeText(s.improved); toast.success("Copied to clipboard"); }}>
                  <Copy className="mr-1 h-3.5 w-3.5" /> Copy
                </Button>
                <Button size="sm" className="rounded-full" disabled={applied.has(i)} data-testid={`tailor-apply-${i}`}
                  onClick={() => apply(s, i)}>
                  <Check className="mr-1 h-3.5 w-3.5" /> {applied.has(i) ? "Applied" : "Apply to resume"}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {!suggestions && !loading && (
        <div className="flex min-h-60 flex-col items-center justify-center rounded-3xl border border-dashed border-border p-8 text-center" data-testid="tailor-empty">
          <PenLine className="h-8 w-8 text-muted-foreground" />
          <p className="mt-3 max-w-sm text-sm text-muted-foreground">
            Pick a resume, paste the JD, and get bullet-by-bullet rewrites with the reasoning behind each one.
          </p>
        </div>
      )}
    </div>
  );
}
