import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowRight, Loader2, PlayCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/brand/Logo";
import { beginSession, forgotPassword, formatApiError, login, register, startDemo } from "@/lib/session";

const HERO_IMG = "https://static.prod-images.emergentagent.com/jobs/27d5e273-d453-429b-a6f9-6b26eb7555e0/images/4fe308539886948ba5a3abe5a491c160f37724667e70f8a2e379fc5cc00e17ef.jpeg";

function AuthLayout({ children, title, sub }: { children: ReactNode; title: string; sub: string }) {
  return (
    <div className="grid min-h-screen bg-background lg:grid-cols-2" data-testid="auth-layout">
      <div className="flex flex-col px-6 py-8 sm:px-12">
        <Link to="/" aria-label="CareerOS home"><Logo /></Link>
        <div className="mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-12">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="font-heading text-3xl font-bold tracking-tight">{title}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{sub}</p>
            <div className="mt-8">{children}</div>
          </motion.div>
        </div>
      </div>
      <div className="hero-aurora relative hidden items-center justify-center overflow-hidden border-l border-border lg:flex">
        <div className="bg-grid absolute inset-0" aria-hidden />
        <div className="relative max-w-md px-10">
          <motion.img
            src={HERO_IMG} alt="CareerOS character"
            initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }}
            className="mx-auto w-64 rounded-[2rem] rounded-t-[8rem] border border-border object-cover shadow-2xl"
          />
          <motion.blockquote
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6, duration: 0.8 }}
            className="mt-8 text-center"
          >
            <p className="font-heading text-lg font-semibold leading-snug">
              “CareerOS turned my scattered job hunt into a system. Three offers in five weeks.”
            </p>
            <footer className="mt-3 text-sm text-muted-foreground">— Alex Morgan, Software Engineer</footer>
          </motion.blockquote>
        </div>
      </div>
    </div>
  );
}

function DemoButton() {
  const navigate = useNavigate();
  return (
    <Button variant="outline" className="w-full rounded-full border-[#5B5FEF]/40 text-[#5B5FEF] hover:bg-[#5B5FEF]/10"
      data-testid="try-demo-btn"
      onClick={() => { startDemo(); navigate("/app"); }}>
      <PlayCircle className="mr-1.5 h-4 w-4" /> Try Interactive Demo — no account needed
    </Button>
  );
}

export function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await login(email, password);
      beginSession();
      toast.success("Welcome back 👋");
      navigate("/app");
    } catch (err) {
      setError(formatApiError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="Welcome back" sub="Sign in to your career workspace.">
      <form onSubmit={(e) => void submit(e)} className="space-y-4" data-testid="login-form">
        <div><Label>Email</Label><Input type="email" required className="mt-1.5" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} data-testid="login-email" /></div>
        <div>
          <div className="flex items-center justify-between">
            <Label>Password</Label>
            <Link to="/forgot-password" className="text-xs text-[#5B5FEF] hover:underline" data-testid="forgot-link">Forgot password?</Link>
          </div>
          <Input type="password" required className="mt-1.5" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="login-password" />
        </div>
        {error && <p className="rounded-xl bg-destructive/10 px-3 py-2 text-sm text-destructive" data-testid="login-error">{error}</p>}
        <Button type="submit" className="w-full rounded-full" disabled={loading} data-testid="login-submit">
          {loading && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />} Sign in <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </form>
      <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
        <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
      </div>
      <DemoButton />
      <p className="mt-6 text-center text-sm text-muted-foreground">
        New to CareerOS? <Link to="/signup" className="font-medium text-[#5B5FEF] hover:underline" data-testid="goto-signup">Create an account</Link>
      </p>
    </AuthLayout>
  );
}

export function Signup() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await register(name, email, password);
      beginSession();
      toast.success("🎉 Welcome to CareerOS!");
      navigate("/app");
    } catch (err) {
      setError(formatApiError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="Build your career OS" sub="Free forever for your first job search.">
      <form onSubmit={(e) => void submit(e)} className="space-y-4" data-testid="signup-form">
        <div><Label>Full name</Label><Input required className="mt-1.5" placeholder="Alex Morgan" value={name} onChange={(e) => setName(e.target.value)} data-testid="signup-name" /></div>
        <div><Label>Email</Label><Input type="email" required className="mt-1.5" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} data-testid="signup-email" /></div>
        <div><Label>Password</Label><Input type="password" required minLength={6} className="mt-1.5" placeholder="6+ characters" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="signup-password" /></div>
        {error && <p className="rounded-xl bg-destructive/10 px-3 py-2 text-sm text-destructive" data-testid="signup-error">{error}</p>}
        <Button type="submit" className="w-full rounded-full" disabled={loading} data-testid="signup-submit">
          {loading && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />} Create account <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </form>
      <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
        <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
      </div>
      <DemoButton />
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Already have an account? <Link to="/login" className="font-medium text-[#5B5FEF] hover:underline" data-testid="goto-login">Sign in</Link>
      </p>
    </AuthLayout>
  );
}

export function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await forgotPassword(email);
    } catch { /* endpoint always returns ok; show success regardless */ }
    setSent(true);
    setLoading(false);
  };

  return (
    <AuthLayout title="Reset your password" sub="We'll email you a secure reset link.">
      {sent ? (
        <div className="rounded-2xl border border-[#10B981]/30 bg-[#10B981]/5 p-5 text-sm" data-testid="forgot-success">
          <p className="font-semibold text-[#10B981]">Check your inbox</p>
          <p className="mt-1 text-muted-foreground">
            If an account exists for <span className="font-medium text-foreground">{email}</span>, a reset link is on its way.
          </p>
        </div>
      ) : (
        <form onSubmit={(e) => void submit(e)} className="space-y-4" data-testid="forgot-form">
          <div><Label>Email</Label><Input type="email" required className="mt-1.5" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} data-testid="forgot-email" /></div>
          <Button type="submit" className="w-full rounded-full" disabled={loading} data-testid="forgot-submit">
            {loading && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />} Send reset link
          </Button>
        </form>
      )}
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Remembered it? <Link to="/login" className="font-medium text-[#5B5FEF] hover:underline" data-testid="back-to-login">Back to sign in</Link>
      </p>
    </AuthLayout>
  );
}
