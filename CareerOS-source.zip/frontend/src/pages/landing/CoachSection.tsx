import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { Bot, ArrowRight } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { SectionTag, TypingDots } from "@/components/career/bits";

const SCRIPT = [
  { from: "user", text: "What skills should I learn next?" },
  { from: "ai", text: "Based on your target role and saved jobs: System Design first (it gates senior interviews), then AWS — it appears in 7 of your 8 saved posts." },
  { from: "user", text: "How should I answer the Google behavioral round?" },
  { from: "ai", text: "Use STAR, 90 seconds max. Your Nova Payments migration story fits 3 of their 4 leadership principles — lead with that." },
];

export default function CoachSection() {
  const [shown, setShown] = useState(1);
  useEffect(() => {
    const t = setInterval(() => setShown((s) => (s >= SCRIPT.length ? 1 : s + 1)), 2600);
    return () => clearInterval(t);
  }, []);

  return (
    <section id="coach" className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8" data-testid="coach-section">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, x: -28 }} whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.7 }}
        >
          <SectionTag>Always in your corner</SectionTag>
          <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight sm:text-4xl">
            Meet your <span className="text-gradient">AI Career Coach</span>
          </h2>
          <p className="mt-4 max-w-lg text-muted-foreground">
            Not a generic chatbot. Your coach reads your resume, your tracker and your skill
            gaps — so every answer is about <em>your</em> next move.
          </p>
          <ul className="mt-6 space-y-3 text-sm">
            {["“How can I improve my resume?”", "“What skills should I learn?”", "“How do I negotiate this offer?”"].map((q) => (
              <li key={q} className="flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 text-muted-foreground">
                <Bot className="h-4 w-4 shrink-0 text-[#22D3EE]" /> {q}
              </li>
            ))}
          </ul>
          <Link to="/signup" data-testid="coach-cta" className={buttonVariants({ variant: "outline" }) + " mt-8 rounded-full"}>
            Ask your first question <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 28 }} whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.7 }}
          className="glass rounded-3xl p-6 shadow-2xl"
          data-testid="coach-demo-panel"
        >
          <div className="mb-5 flex items-center gap-3 border-b border-border pb-4">
            <span className="relative flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-[#5B5FEF] to-[#22D3EE] text-white">
              <Bot className="h-5 w-5" />
              <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-card bg-[#10B981]" />
            </span>
            <div>
              <p className="font-heading text-sm font-semibold">Nova · Career Coach</p>
              <p className="text-xs text-[#10B981]">Online — knows your workspace</p>
            </div>
          </div>
          <div className="space-y-4">
            {SCRIPT.slice(0, shown).map((m, i) => (
              <motion.div
                key={`${shown}-${i}`}
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}
                className={m.from === "user" ? "flex justify-end" : "flex justify-start"}
              >
                <p className={
                  m.from === "user"
                    ? "max-w-[80%] rounded-2xl rounded-br-md bg-[#5B5FEF] px-4 py-2.5 text-sm text-white"
                    : "max-w-[85%] rounded-2xl rounded-bl-md bg-muted px-4 py-2.5 text-sm"
                }>
                  {m.text}
                </p>
              </motion.div>
            ))}
            <TypingDots label="Nova is thinking" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
