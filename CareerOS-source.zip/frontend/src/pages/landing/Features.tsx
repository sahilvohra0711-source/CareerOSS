import { motion } from "motion/react";
import { FileText, Target, ScanSearch, Mic, Kanban, Bot, Check, TriangleAlert } from "lucide-react";
import { ProgressBar, ScoreRing, SectionTag } from "@/components/career/bits";
import { INTERVIEWER_AVATAR } from "@/data/demo";

const reveal = {
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
  transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] as const },
};

function CardShell({ children, className, testId }: { children: React.ReactNode; className?: string; testId: string }) {
  return (
    <motion.article {...reveal} data-testid={testId}
      className={`card-lift group relative overflow-hidden rounded-3xl border border-border bg-card p-7 ${className ?? ""}`}>
      {children}
    </motion.article>
  );
}

function CardHead({ icon: Icon, title, copy, tone }: { icon: typeof FileText; title: string; copy: string; tone: string }) {
  return (
    <div className="relative z-10">
      <span className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl" style={{ background: `${tone}1f`, color: tone }}>
        <Icon className="h-5 w-5" />
      </span>
      <h3 className="font-heading text-lg font-semibold">{title}</h3>
      <p className="mt-1.5 max-w-md text-sm leading-relaxed text-muted-foreground">{copy}</p>
    </div>
  );
}

export default function Features() {
  return (
    <section id="features" className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8" data-testid="features-section">
      <motion.div {...reveal} className="mb-12 max-w-2xl">
        <SectionTag>Everything, connected</SectionTag>
        <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight sm:text-4xl">
          Everything for your career, <span className="text-gradient">in one place</span>
        </h2>
        <p className="mt-3 text-muted-foreground">
          Twelve modules that share one brain — what you learn in one place makes every other place smarter.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-12">
        <CardShell className="md:col-span-7" testId="feature-resume-builder">
          <CardHead icon={FileText} tone="#5B5FEF" title="Resume Builder & PDF Export"
            copy="Five ATS-friendly templates, a live preview beside your editor, and one-click professional PDF export." />
          <div className="mt-6 space-y-3 rounded-2xl bg-muted/60 p-5">
            {[["Experience", 92], ["Skills", 84], ["Impact", 88]].map(([l, v]) => (
              <div key={l as string}>
                <div className="mb-1 flex justify-between text-xs text-muted-foreground"><span>{l}</span><span>{v}%</span></div>
                <ProgressBar value={v as number} />
              </div>
            ))}
          </div>
        </CardShell>

        <CardShell className="md:col-span-5" testId="feature-job-matcher">
          <CardHead icon={Target} tone="#22D3EE" title="Job Matcher"
            copy="Paste any job description. Get an instant match score, the skills you already have, and exactly what to strengthen." />
          <div className="mt-6 flex items-center justify-center">
            <ScoreRing value={94} size={132} sub="MATCH" testId="feature-match-ring" />
          </div>
        </CardShell>

        <CardShell className="md:col-span-4" testId="feature-ats-analysis">
          <CardHead icon={ScanSearch} tone="#7C3AED" title="ATS Analysis"
            copy="Not just a score — specific, actionable feedback on every weak bullet." />
          <div className="mt-5 space-y-2 text-xs">
            <p className="flex items-center gap-2 rounded-lg bg-[#10B981]/10 px-3 py-2 text-[#10B981]"><Check className="h-3.5 w-3.5" /> Formatting parses cleanly</p>
            <p className="flex items-center gap-2 rounded-lg bg-[#F59E0B]/10 px-3 py-2 text-[#F59E0B]"><TriangleAlert className="h-3.5 w-3.5" /> 3 bullets missing metrics</p>
          </div>
        </CardShell>

        <CardShell className="md:col-span-4" testId="feature-interview-prep">
          <CardHead icon={Mic} tone="#F43F5E" title="AI Interview Studio"
            copy="An AI interviewer that reacts to your answers and scores clarity, depth, structure and impact." />
          <div className="mt-5 flex items-center gap-3 rounded-2xl bg-muted/60 p-3">
            <img src={INTERVIEWER_AVATAR} alt="AI interviewer" className="h-10 w-10 rounded-full object-cover ring-2 ring-[#5B5FEF]/50" />
            <div className="text-xs">
              <p className="font-semibold">Sarah · AI Interviewer</p>
              <p className="text-[#10B981]">Excellent answer! 8.5 / 10</p>
            </div>
          </div>
        </CardShell>

        <CardShell className="md:col-span-4" testId="feature-tracker">
          <CardHead icon={Kanban} tone="#10B981" title="Application Tracker"
            copy="A beautiful Kanban pipeline from Saved to Offer — with follow-ups that never slip." />
          <div className="mt-5 flex gap-2">
            {["Saved", "Applied", "Interview", "Offer"].map((s, i) => (
              <div key={s} className="flex-1 rounded-xl bg-muted/60 p-2 text-center">
                <p className="font-heading text-lg font-bold" style={{ color: ["#94A3B8", "#5B5FEF", "#7C3AED", "#10B981"][i] }}>{[4, 6, 3, 1][i]}</p>
                <p className="text-[10px] text-muted-foreground">{s}</p>
              </div>
            ))}
          </div>
        </CardShell>

        <CardShell className="md:col-span-12" testId="feature-ai-coach">
          <div className="grid items-center gap-6 md:grid-cols-2">
            <CardHead icon={Bot} tone="#22D3EE" title="AI Career Coach, always on"
              copy="A coach that knows your resume, your applications and your gaps. Ask how to answer a question, what skill to learn next, or how to negotiate the offer — get specific answers, not platitudes." />
            <div className="space-y-2.5 rounded-2xl bg-muted/60 p-4 text-sm">
              <p className="ml-auto w-fit max-w-[80%] rounded-2xl rounded-br-md bg-[#5B5FEF] px-4 py-2 text-white">How do I answer “tell me about yourself”?</p>
              <p className="w-fit max-w-[85%] rounded-2xl rounded-bl-md bg-card px-4 py-2 shadow-sm">Lead with your present role, one proof metric, then why this role. 30 seconds, no life story. Want to practice it live?</p>
            </div>
          </div>
        </CardShell>
      </div>
    </section>
  );
}
