import { Link, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowRight, CirclePlay } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { LogoMark } from "@/components/brand/Logo";
import { startDemo } from "@/lib/session";

export default function Footer() {
  const navigate = useNavigate();
  return (
    <footer className="border-t border-border" data-testid="landing-footer">
      <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.8 }}
          className="relative overflow-hidden rounded-[2rem] border border-[#5B5FEF]/30 bg-gradient-to-br from-[#5B5FEF]/15 via-card to-[#22D3EE]/10 px-8 py-16 text-center"
        >
          <div className="bg-grid absolute inset-0" aria-hidden />
          <div className="relative">
            <h2 className="mx-auto max-w-2xl font-heading text-3xl font-bold tracking-tight sm:text-4xl" data-testid="final-cta-headline">
              Ready to take control of your career?
            </h2>
            <p className="mx-auto mt-3 max-w-md text-muted-foreground">
              Join thousands of candidates running their job search like a system — not a spreadsheet.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <Link to="/signup" data-testid="btn-start-building"
                className={buttonVariants({ size: "lg" }) + " rounded-full px-7 shadow-[0_8px_30px_-6px_rgba(91,95,239,0.55)] transition-transform hover:scale-[1.03] active:scale-[0.98]"}>
                Start Building <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
              <Button variant="outline" size="lg" data-testid="btn-footer-demo" className="rounded-full px-7"
                onClick={() => { startDemo(); navigate("/app"); }}>
                <CirclePlay className="mr-1 h-4 w-4" /> Try Interactive Demo
              </Button>
            </div>
          </div>
        </motion.div>

        <div className="mt-16 flex flex-col items-center justify-between gap-6 border-t border-border pt-8 sm:flex-row">
          <span className="flex items-center gap-2.5">
            <LogoMark className="h-7 w-7" />
            <span className="text-sm text-muted-foreground">Your career. One intelligent workspace.</span>
          </span>
          <nav className="flex gap-6 text-sm text-muted-foreground">
            <a href="#features" className="transition-colors hover:text-foreground">Features</a>
            <a href="#how" className="transition-colors hover:text-foreground">How it works</a>
            <Link to="/login" className="transition-colors hover:text-foreground">Sign in</Link>
          </nav>
          <p className="text-xs text-muted-foreground">© 2026 CareerOS. Built for the ambitious.</p>
        </div>
        <p className="mt-6 text-center font-mono text-[11px] tracking-wide text-muted-foreground/70" data-testid="built-by-credit">
          Designed &amp; built end-to-end as a full-stack portfolio project — React · FastAPI · MongoDB · GPT-5.4
        </p>
      </div>
    </footer>
  );
}
