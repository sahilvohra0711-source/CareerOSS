import { Link, useNavigate } from "react-router-dom";
import { motion, useMotionValue, useSpring, useTransform } from "motion/react";
import { ArrowRight, CirclePlay, FileText, Target, Mic, Briefcase, Sparkles } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { startDemo } from "@/lib/session";
import { CountUp } from "@/components/career/bits";

const HERO_IMG = "https://static.prod-images.emergentagent.com/jobs/27d5e273-d453-429b-a6f9-6b26eb7555e0/images/4fe308539886948ba5a3abe5a491c160f37724667e70f8a2e379fc5cc00e17ef.jpeg";
const DASH_IMG = "https://static.prod-images.emergentagent.com/jobs/27d5e273-d453-429b-a6f9-6b26eb7555e0/images/91313a846f33af4165aef8e08e795ae1ba471eef9ab6ea6caadbce78e018d375.jpeg";

const FLOAT_CARDS = [
  { icon: FileText, label: "Resume Score", value: "92", tone: "#22D3EE", pos: "left-[-8%] top-[12%]", delay: 0 },
  { icon: Target, label: "Job Match", value: "94%", tone: "#5B5FEF", pos: "right-[-6%] top-[24%]", delay: 0.8 },
  { icon: Mic, label: "Interview", value: "Ready", tone: "#7C3AED", pos: "left-[-10%] top-[52%]", delay: 1.6 },
  { icon: Briefcase, label: "This Week", value: "3 Applications", tone: "#10B981", pos: "right-[-8%] top-[58%]", delay: 2.2 },
  { icon: Sparkles, label: "Skill Gap", value: "Detected", tone: "#F59E0B", pos: "left-[6%] bottom-[4%]", delay: 2.9 },
];

function MaskedLine({ children, delay }: { children: string; delay: number }) {
  return (
    <span className="reveal-line">
      <span style={{ animationDelay: `${delay}s` }}>{children}</span>
    </span>
  );
}

export default function Hero() {
  const navigate = useNavigate();
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 60, damping: 18 });
  const sy = useSpring(my, { stiffness: 60, damping: 18 });
  const px = useTransform(sx, [-0.5, 0.5], [-14, 14]);
  const py = useTransform(sy, [-0.5, 0.5], [-10, 10]);
  const cx = useTransform(sx, [-0.5, 0.5], [8, -8]);
  const cy = useTransform(sy, [-0.5, 0.5], [6, -6]);

  return (
    <section
      className="hero-aurora relative"
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        mx.set((e.clientX - r.left) / r.width - 0.5);
        my.set((e.clientY - r.top) / r.height - 0.5);
      }}
      data-testid="hero-section"
    >
      <div className="bg-grid absolute inset-0" aria-hidden />
      <div className="relative mx-auto grid min-h-[100svh] max-w-7xl grid-cols-1 items-center gap-12 px-4 pb-20 pt-28 sm:px-6 lg:grid-cols-12 lg:gap-8 lg:px-8">
        <div className="lg:col-span-6">
          <motion.p
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
            className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3.5 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-[#22D3EE]"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#22D3EE] opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[#22D3EE]" />
            </span>
            One workspace. Every career move.
          </motion.p>
          <h1 className="font-heading text-4xl font-bold leading-[1.04] tracking-tight sm:text-5xl lg:text-6xl" data-testid="hero-headline">
            <MaskedLine delay={0.15}>Your career deserves</MaskedLine>
            <MaskedLine delay={0.32}>
              a smarter workspace.
            </MaskedLine>
          </h1>
          <motion.p
            initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.7 }}
            className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg"
          >
            CareerOS brings your resume, job search, applications, interview preparation,
            and career growth into one intelligent workspace.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.75, duration: 0.7 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <Link to="/signup" data-testid="btn-build-career"
              className={buttonVariants({ size: "lg" }) + " rounded-full px-6 shadow-[0_8px_30px_-6px_rgba(91,95,239,0.55)] transition-transform hover:scale-[1.03] active:scale-[0.98]"}>
              Build My Career <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
            <Button
              variant="outline" size="lg" data-testid="btn-explore-demo"
              className="rounded-full px-6 transition-transform hover:scale-[1.03] active:scale-[0.98]"
              onClick={() => { startDemo(); navigate("/app"); }}
            >
              <CirclePlay className="mr-1 h-4 w-4" /> Explore Demo
            </Button>
          </motion.div>
          <motion.dl
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1, duration: 0.8 }}
            className="mt-12 flex gap-10 border-t border-border pt-6"
          >
            {[
              { v: 12, s: "", l: "Connected modules" },
              { v: 94, s: "%", l: "Avg. match score" },
              { v: 3, s: "×", l: "Faster interview prep" },
            ].map((s) => (
              <div key={s.l}>
                <dt className="sr-only">{s.l}</dt>
                <dd className="font-heading text-2xl font-bold sm:text-3xl">
                  <CountUp to={s.v} suffix={s.s} />
                </dd>
                <dd className="mt-1 text-xs text-muted-foreground">{s.l}</dd>
              </div>
            ))}
          </motion.dl>
        </div>

        <div className="relative lg:col-span-6" data-testid="hero-visual">
          <motion.div style={{ x: px, y: py }} className="relative mx-auto max-w-[480px]">
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 24 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              className="relative overflow-hidden rounded-[2.5rem] rounded-t-[10rem] border border-border shadow-[0_40px_120px_-30px_rgba(91,95,239,0.45)]"
            >
              <img src={HERO_IMG} alt="CareerOS career character beside a futuristic dashboard"
                className="h-auto w-full object-cover" draggable={false} />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/40 via-transparent to-transparent" />
            </motion.div>

            <motion.div style={{ x: cx, y: cy }}
              initial={{ opacity: 0, y: 20, rotate: -6 }}
              animate={{ opacity: 1, y: 0, rotate: -6 }}
              transition={{ delay: 1.1, duration: 0.8 }}
              className="absolute -bottom-10 -right-4 w-56 overflow-hidden rounded-2xl border border-border shadow-2xl sm:-right-10 sm:w-64"
            >
              <img src={DASH_IMG} alt="Futuristic career dashboard preview" className="h-auto w-full object-cover" draggable={false} />
            </motion.div>

            {FLOAT_CARDS.map((c) => (
              <motion.div
                key={c.label}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: [0, -7, 0] }}
                transition={{
                  opacity: { delay: 0.9 + c.delay * 0.3, duration: 0.5 },
                  y: { delay: 0.9 + c.delay * 0.3, duration: 4, repeat: Infinity, ease: "easeInOut" },
                }}
                className={`glass absolute ${c.pos} flex items-center gap-2.5 rounded-2xl px-3.5 py-2.5 shadow-lg`}
                data-testid={`hero-chip-${c.label.toLowerCase().replace(/\s/g, "-")}`}
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-xl" style={{ background: `${c.tone}22`, color: c.tone }}>
                  <c.icon className="h-4 w-4" />
                </span>
                <span>
                  <span className="block text-[10px] uppercase tracking-wider text-muted-foreground">{c.label}</span>
                  <span className="block font-heading text-sm font-bold">{c.value}</span>
                </span>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
