import { motion } from "motion/react";
import { UserRound, ScanSearch, BrainCircuit, TrendingUp } from "lucide-react";
import { SectionTag } from "@/components/career/bits";

const STEPS = [
  { icon: UserRound, title: "Build your profile", copy: "Import or craft a resume that reads like you on your best day. Skills, projects and goals plug into every module." },
  { icon: ScanSearch, title: "Analyze opportunities", copy: "Paste any job description. See your match score, keyword gaps and tailored bullets in seconds." },
  { icon: BrainCircuit, title: "Prepare smarter", copy: "Rehearse with an AI interviewer that scores every answer and builds a personal practice plan." },
  { icon: TrendingUp, title: "Track your progress", copy: "Applications, follow-ups, skills and readiness — one dashboard that always tells you the next move." },
];

export default function HowItWorks() {
  return (
    <section id="how" className="border-y border-border bg-card/40 py-24" data-testid="how-section">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.7 }}
          className="mb-14 max-w-2xl"
        >
          <SectionTag>The playbook</SectionTag>
          <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight sm:text-4xl">How CareerOS works</h2>
        </motion.div>

        <div className="relative grid gap-10 md:grid-cols-4 md:gap-6">
          <div className="absolute left-0 right-0 top-7 hidden h-px bg-gradient-to-r from-transparent via-[#5B5FEF]/50 to-transparent md:block" aria-hidden />
          {STEPS.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.12 }}
              className="relative"
              data-testid={`how-step-${i + 1}`}
            >
              <div className="relative z-10 mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-border bg-card shadow-[0_10px_30px_-12px_rgba(91,95,239,0.4)]">
                <s.icon className="h-6 w-6 text-[#5B5FEF]" />
                <span className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br from-[#5B5FEF] to-[#7C3AED] font-mono text-[11px] font-bold text-white">
                  {i + 1}
                </span>
              </div>
              <h3 className="font-heading text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.copy}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
