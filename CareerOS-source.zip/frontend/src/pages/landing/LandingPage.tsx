import { useEffect } from "react";
import Lenis from "lenis";
import { apiPost } from "@/lib/api";
import Navbar from "./Navbar";
import Hero from "./Hero";
import Marquee from "./Marquee";
import Features from "./Features";
import HowItWorks from "./HowItWorks";
import CoachSection from "./CoachSection";
import { DashboardPreview, Readiness } from "./Preview";
import Footer from "./Footer";

export default function LandingPage() {
  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.1 });
    let raf = 0;
    const loop = (t: number) => {
      lenis.raf(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
    };
  }, []);

  useEffect(() => {
    apiPost("/analytics/track", { ref: document.referrer || "direct" }).catch(() => undefined);
  }, []);

  return (
    <div className="relative min-h-screen overflow-x-clip bg-background" data-testid="landing-page">
      <Navbar />
      <main>
        <Hero />
        <Marquee />
        <Features />
        <HowItWorks />
        <CoachSection />
        <DashboardPreview />
        <Readiness />
      </main>
      <Footer />
    </div>
  );
}
