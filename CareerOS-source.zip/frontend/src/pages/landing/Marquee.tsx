const ITEMS = [
  "Resume Builder", "Job Matcher", "ATS Analysis", "Resume Tailoring", "Application Tracker",
  "Company Tracker", "Interview Prep", "Career Dashboard", "Follow-up Reminders",
  "Portfolio & Projects", "PDF Export", "AI Career Coach",
];

export default function Marquee() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <section className="border-y border-border py-7" aria-label="CareerOS modules" data-testid="modules-marquee">
      <div className="marquee-mask overflow-hidden">
        <div className="animate-marquee flex w-max items-center gap-10 pr-10">
          {row.map((item, i) => (
            <span key={i} className="flex items-center gap-10">
              <span className="font-heading text-xl font-semibold tracking-tight text-muted-foreground/80 sm:text-2xl">
                {item}
              </span>
              <span className="text-[#5B5FEF]">✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
