import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useTheme } from "next-themes";
import { Moon, Sun, Menu } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "@/components/brand/Logo";
import { startDemo } from "@/lib/session";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "#features", label: "Features" },
  { href: "#how", label: "How it works" },
  { href: "#coach", label: "AI Coach" },
  { href: "#preview", label: "Preview" },
];

export function ThemeToggle({ className }: { className?: string }) {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const dark = !mounted || theme !== "light";
  return (
    <Button
      variant="ghost" size="icon"
      aria-label="Toggle theme"
      data-testid="theme-toggle"
      className={cn("rounded-full", className)}
      onClick={() => setTheme(dark ? "light" : "dark")}
    >
      {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </Button>
  );
}

export default function Navbar() {
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-colors duration-300",
        scrolled ? "glass" : "bg-transparent",
      )}
      data-testid="landing-nav"
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" aria-label="CareerOS home"><Logo /></Link>
        <nav className="hidden items-center gap-7 md:flex">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} data-testid={`nav-${l.label.toLowerCase().replace(/\s/g, "-")}`}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground">
              {l.label}
            </a>
          ))}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <ThemeToggle />
          <Link to="/login" data-testid="nav-sign-in" className={buttonVariants({ variant: "ghost", size: "sm" })}>Sign in</Link>
          <Link to="/signup" data-testid="nav-build-career" className={buttonVariants({ size: "sm" }) + " rounded-full px-4"}>
            Build My Career
          </Link>
        </div>
        <div className="flex items-center gap-1 md:hidden">
          <ThemeToggle />
          <Sheet>
            <SheetTrigger render={<Button variant="ghost" size="icon" aria-label="Open menu" data-testid="nav-mobile-menu" />}>
              <Menu className="h-5 w-5" />
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <div className="mt-8 flex flex-col gap-4">
                {LINKS.map((l) => (
                  <a key={l.href} href={l.href} className="text-base text-muted-foreground hover:text-foreground">{l.label}</a>
                ))}
                <Link to="/login" className={buttonVariants({ variant: "outline" })}>Sign in</Link>
                <Link to="/signup" className={buttonVariants({})}>Build My Career</Link>
                <Button variant="secondary" data-testid="nav-mobile-demo" onClick={() => { startDemo(); navigate("/app"); }}>
                  Try Interactive Demo
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
