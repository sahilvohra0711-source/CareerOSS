import { motion } from "motion/react";
import { Bell, Search, FileText, Briefcase, Mic, TrendingUp } from "lucide-react";
import { CountUp, ProgressBar, ScoreRing, SectionTag } from "@/components/career/bits";

const STATS = [
  { icon: FileText, label: "Resume Score", value: 92, suffix: "/100", tone: "#22D3EE" },
  { icon: Briefcase, label: "Applications", value: 24, suffix: "", tone: "#5B5FEF" },
  { icon: Mic, label: "Interviews", value: 6, suffix: "", tone: "#7C3AED" },
  { icon: TrendingUp, label: "Response Rate", value: 31, suffix: "%", tone: "#10B981" },
];

const BARS = [3, 5, 2, 6, 4, 7, 5];

export function DashboardPreview() {
  return (
    <section id="preview" className="border-y border-border bg-card/40 py-24" data-testid="preview-section">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.7 }}
          className="mx-auto mb-14 max-w-2xl text-center"
        >
          <SectionTag>Command center</SectionTag>
          <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight sm:text-4xl">
            A dashboard that tells you <span className="text-gradient">what to do next</span>
          </h2>
          <p className="mt-3 text-muted-foreground">
            Every number answers three questions: what happened, why it matters, and what to do next.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40, rotateX: 8 }}
          whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          style={{ transformPerspective: 1200 }}
          className="relative mx-auto max-w-5xl"
        >
          <div className="absolute -inset-8 rounded-[3rem] bg-gradient-to-br from-[#5B5FEF]/20 via-transparent to-[#22D3EE]/15 blur-2xl" aria-hidden />
          <div className="relative overflow-hidden rounded-3xl border border-border bg-card shadow-2xl">
            <div className="flex items-center gap-2 border-b border-border px-5 py-3">
              <span className="h-3 w-3 rounded-full bg-[#F43F5E]/70" />
              <span className="h-3 w-3 rounded-full bg-[#F59E0B]/70" />
              <span className="h-3 w-3 rounded-full bg-[#10B981]/70" />
              <span className="ml-4 flex items-center gap-2 rounded-lg bg-muted px-3 py-1 font-mono text-[11px] text-muted-foreground">
                <Search className="h-3 w-3" /> careeros.app/dashboard
              </span>
              <Bell className="ml-auto h-4 w-4 text-muted-foreground" />
            </div>
            <div className="grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-4">
              {STATS.map((s, i) => (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }} transition={{ delay: 0.15 + i * 0.08, duration: 0.5 }}
                  className="rounded-2xl border border-border bg-background/60 p-4"
                >
                  <div className="flex items-center justify-between">
                    <s.icon className="h-4 w-4" style={{ color: s.tone }} />
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</span>
                  </div>
                  <p className="mt-2 font-heading text-2xl font-bold">
                    <CountUp to={s.value} suffix={s.suffix} />
                  </p>
                </motion.div>
              ))}
              <div className="rounded-2xl border border-border bg-background/60 p-4 sm:col-span-2 lg:col-span-2">
                <p className="mb-3 text-[10px] uppercase tracking-wider text-muted-foreground">Applications / week</p>
                <div className="flex h-20 items-end gap-2">
                  {BARS.map((v, i) => (
                    <motion.div key={i} className="flex-1 rounded-t-md bg-gradient-to-t from-[#5B5FEF] to-[#22D3EE]"
                      initial={{ height: 0 }} whileInView={{ height: `${v * 13}%` }}
                      viewport={{ once: true }} transition={{ delay: 0.3 + i * 0.06, duration: 0.6 }} />
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-center rounded-2xl border border-border bg-background/60 p-4 sm:col-span-2 lg:col-span-2">
                <ScoreRing value={87} size={110} sub="READINESS" />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function Readiness() {
  const breakdown = [
    { label: "Resume", value: 92 },
    { label: "Skills", value: 84 },
    { label: "Projects", value: 89 },
    { label: "Interview Prep", value: 76 },
    { label: "Applications", value: 83 },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8" data-testid="readiness-section">
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }} whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.8 }}
          className="relative mx-auto"
        >
          <div className="pulse-ring relative rounded-full">
            <ScoreRing value={87} size={260} stroke={14} sub="CAREER READINESS" testId="landing-readiness-ring" />
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 28 }} whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }} transition={{ duration: 0.7 }}
        >
          <SectionTag>Know exactly where you stand</SectionTag>
          <h2 className="mt-3 font-heading text-3xl font-bold tracking-tight sm:text-4xl">
            One score for your <span className="text-gradient">entire career search</span>
          </h2>
          <p className="mt-4 max-w-lg text-muted-foreground">
            Career Readiness blends your resume strength, skills, projects, interview prep and
            application momentum — then points at the lever that moves it fastest.
          </p>
          <div className="mt-8 space-y-4">
            {breakdown.map((b, i) => (
              <motion.div key={b.label}
                initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.08, duration: 0.5 }}>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span>{b.label}</span>
                  <span className="font-mono text-muted-foreground">{b.value}%</span>
                </div>
                <ProgressBar value={b.value} />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
