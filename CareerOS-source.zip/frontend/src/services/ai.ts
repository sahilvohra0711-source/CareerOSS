import type { Reaction, Resume } from "@/lib/types";

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
const AI_API = "/api/ai";

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${AI_API}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`ai ${path} failed: ${res.status}`);
  return (await res.json()) as T;
}

/* ------------------------------ resume upload ------------------------------ */

export async function uploadResumeFile(file: File): Promise<Resume> {
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch(`${AI_API}/parse-resume`, { method: "POST", body: fd });
  if (!res.ok) {
    const detail = (await res.json().catch(() => null)) as { detail?: string } | null;
    throw new Error(detail?.detail ?? "Couldn't parse that file.");
  }
  return (await res.json()) as Resume;
}

/* ---------------------------------- skills ---------------------------------- */

const SKILL_ALIASES: Record<string, string[]> = {
  "Node.js": ["node.js", "nodejs", "node"],
  "React": ["react", "react.js", "reactjs"],
  "Next.js": ["next.js", "nextjs"],
  "TypeScript": ["typescript", "ts"],
  "JavaScript": ["javascript", "js"],
  "REST APIs": ["rest api", "rest apis", "restful"],
  "CI/CD": ["ci/cd", "ci cd", "continuous integration"],
  "AWS": ["aws", "amazon web services"],
  "System Design": ["system design", "distributed systems", "distributed system"],
  "Tailwind CSS": ["tailwind", "tailwind css"],
  "SQL": ["sql", "postgres", "postgresql", "mysql"],
};

export const SKILL_LEXICON = [
  "JavaScript", "TypeScript", "React", "Next.js", "Node.js", "GraphQL", "REST APIs",
  "SQL", "PostgreSQL", "MongoDB", "Redis", "Python", "Go", "AWS", "Docker",
  "Kubernetes", "CI/CD", "Terraform", "Git", "Testing", "Jest", "System Design",
  "Microservices", "Kafka", "Tailwind CSS", "Redux", "Agile", "Leadership",
];

export function extractSkills(text: string): string[] {
  const t = text.toLowerCase();
  return SKILL_LEXICON.filter((skill) => {
    const aliases = SKILL_ALIASES[skill] ?? [skill.toLowerCase()];
    return aliases.some((a) => t.includes(a));
  });
}

/* -------------------------------- ATS analysis ------------------------------- */

export interface AtsReport {
  overall: number;
  categories: { label: string; score: number; note: string }[];
  feedback: { title: string; detail: string; action: string }[];
}

const METRIC_RE = /\d+%|\$\d|\d+x|\d+\+|\b\d{2,}\b/;
const WEAK_VERBS = /^(worked|helped|responsible|assisted|was involved|participated)/i;

async function analyzeResumeLocal(resume: Resume): Promise<AtsReport> {
  await wait(1400);
  const bullets = resume.experience.flatMap((e) => e.bullets).filter(Boolean);
  const noMetric = bullets.filter((b) => !METRIC_RE.test(b));
  const weak = bullets.filter((b) => WEAK_VERBS.test(b.trim()));
  const lengths = bullets.map((b) => b.split(/\s+/).length);
  const goodLen = lengths.filter((n) => n >= 8 && n <= 28).length;

  const sections = [
    resume.summary, resume.experience.length > 0 ? "x" : "",
    resume.education.length > 0 ? "x" : "", resume.skills.length > 5 ? "x" : "",
    resume.personal.email, resume.personal.phone,
  ];
  const formatting = Math.round((sections.filter(Boolean).length / sections.length) * 100);
  const impact = bullets.length ? Math.round(((bullets.length - noMetric.length) / bullets.length) * 100) : 40;
  const clarity = bullets.length ? Math.round((goodLen / bullets.length) * 100) : 50;
  const keywords = Math.min(100, Math.round((resume.skills.length / 14) * 100));
  const experience = Math.min(100, 55 + resume.experience.length * 12 + (bullets.length - weak.length));
  const skills = Math.min(100, resume.skills.length * 7);
  const overall = Math.round((formatting + impact + clarity + keywords + experience + skills) / 6);

  const feedback: AtsReport["feedback"] = [];
  if (noMetric.length > 0)
    feedback.push({
      title: `${noMetric.length} bullet${noMetric.length > 1 ? "s" : ""} missing measurable achievements`,
      detail: `“${noMetric[0].slice(0, 72)}…” has no number. Recruiters scan for metrics first.`,
      action: "Add a metric — %, $, users, latency, hours saved.",
    });
  if (weak.length > 0)
    feedback.push({
      title: `${weak.length} bullet${weak.length > 1 ? "s" : ""} start${weak.length > 1 ? "" : "s"} with a weak verb`,
      detail: `Avoid “${weak[0].split(" ")[0]}”. Lead with a strong action verb like Led, Built, Cut, Shipped.`,
      action: "Rewrite using the XYZ formula: “Accomplished X, measured by Y, by doing Z”.",
    });
  if (keywords < 90)
    feedback.push({
      title: "Keyword coverage below target-role average",
      detail: `Your skills section lists ${resume.skills.length} skills. Top Software Engineer resumes list 14–18, including System Design and Kubernetes.`,
      action: "Add System Design and Kubernetes if you can defend them in an interview.",
    });
  if (feedback.length === 0)
    feedback.push({
      title: "This resume is in excellent shape",
      detail: "Strong metrics, verbs and keyword coverage. Keep tailoring it per job description.",
      action: "Run a Job Match against each posting before applying.",
    });

  return {
    overall,
    categories: [
      { label: "Formatting", score: formatting, note: "All core sections present and parseable" },
      { label: "Impact", score: impact, note: `${bullets.length - noMetric.length}/${bullets.length} bullets include a metric` },
      { label: "Clarity", score: clarity, note: `${goodLen}/${bullets.length} bullets hit the 8–28 word sweet spot` },
      { label: "Keywords", score: keywords, note: `${resume.skills.length} skills detected for Software Engineer roles` },
      { label: "Experience", score: experience, note: `${resume.experience.length} roles, ${bullets.length} achievement bullets` },
      { label: "Skills", score: skills, note: "Breadth vs. target-role benchmark" },
    ],
    feedback,
  };
}

export async function analyzeResume(resume: Resume): Promise<AtsReport> {
  try {
    return await post<AtsReport>("/analyze-resume", { resume });
  } catch {
    return analyzeResumeLocal(resume);
  }
}

/* --------------------------------- job match --------------------------------- */

export interface MatchReport {
  score: number;
  matched: string[];
  missing: string[];
  categories: { label: string; value: number }[];
  suggestions: string[];
}

async function matchJobLocal(resume: Resume, jd: string): Promise<MatchReport> {
  await wait(1600);
  const jdSkills = extractSkills(jd);
  const have = new Set([...resume.skills.map((s) => s.toLowerCase()), ...extractSkills(resume.summary + " " + resume.experience.flatMap((e) => e.bullets.join(" ")).join(" ")).map((s) => s.toLowerCase())]);
  const matched = jdSkills.filter((s) => have.has(s.toLowerCase()) || (SKILL_ALIASES[s] ?? []).some((a) => have.has(a)));
  const missing = jdSkills.filter((s) => !matched.includes(s));
  const skillScore = jdSkills.length ? Math.round((matched.length / jdSkills.length) * 100) : 70;
  const senior = /senior|staff|lead|5\+|6\+/i.test(jd);
  const experience = senior ? 82 : 92;
  const education = 95;
  const score = Math.round(skillScore * 0.55 + experience * 0.25 + education * 0.2);
  return {
    score,
    matched,
    missing,
    categories: [
      { label: "Skills Match", value: skillScore },
      { label: "Experience Match", value: experience },
      { label: "Education Match", value: education },
      { label: "Keyword Coverage", value: Math.min(100, skillScore + 6) },
    ],
    suggestions: [
      ...missing.slice(0, 3).map((s) => `Mirror “${s}” in your summary or top bullet — the ATS looks for exact phrasing.`),
      "Lead your summary with the exact job title: it raises recruiter scan relevance.",
      "Move your most relevant role's metric bullets to the top of the experience section.",
    ],
  };
}

export async function matchJob(resume: Resume, jd: string): Promise<MatchReport> {
  try {
    return await post<MatchReport>("/match", { resume, jd });
  } catch {
    return matchJobLocal(resume, jd);
  }
}

/* --------------------------------- tailoring --------------------------------- */

export interface TailorSuggestion {
  original: string;
  improved: string;
  why: string;
  company: string;
}

const STRONG_VERBS = ["Led", "Built", "Shipped", "Drove", "Architected", "Accelerated"];

async function tailorResumeLocal(resume: Resume, jd: string): Promise<TailorSuggestion[]> {
  await wait(1800);
  const jdSkills = extractSkills(jd);
  const have = new Set(resume.skills.map((s) => s.toLowerCase()));
  const missing = jdSkills.filter((s) => !have.has(s.toLowerCase()));
  const out: TailorSuggestion[] = [];
  const targets = resume.experience.slice(0, 2).flatMap((e) =>
    e.bullets.slice(0, 2).map((b) => ({ b, company: e.company })),
  );
  targets.slice(0, 4).forEach(({ b, company }, i) => {
    let improved = b.replace(/\.$/, "");
    const why: string[] = [];
    if (!METRIC_RE.test(b)) {
      improved += ` — improving ${["p95 latency", "conversion", "deployment frequency", "test coverage"][i % 4]} by ${[38, 12, 3, 22][i % 4]}${i % 4 === 2 ? "x" : "%"}`;
      why.push("adds a measurable result, which recruiters scan for first");
    }
    if (WEAK_VERBS.test(b.trim())) {
      improved = improved.replace(WEAK_VERBS, STRONG_VERBS[i % STRONG_VERBS.length]);
      why.push("replaces a passive opener with a strong action verb");
    }
    if (missing.length > 0 && i < missing.length) {
      improved += ` using ${missing[i % missing.length]}`;
      why.push(`mirrors “${missing[i % missing.length]}” from the job description for ATS keyword match`);
    }
    if (why.length === 0) why.push("tightens phrasing and keeps the proven metric up front");
    out.push({ original: b, improved: improved + ".", why: `This ${why.join(" and ")}.`, company });
  });
  return out;
}

export async function tailorResume(resume: Resume, jd: string): Promise<TailorSuggestion[]> {
  try {
    return await post<TailorSuggestion[]>("/tailor", { resume, jd });
  } catch {
    return tailorResumeLocal(resume, jd);
  }
}

/* --------------------------------- interviews -------------------------------- */

const QUESTION_BANKS: Record<string, string[]> = {
  Behavioral: [
    "Tell me about a project where you had to solve a difficult technical problem.",
    "Describe a time you disagreed with a teammate. How did you resolve it?",
    "Tell me about a time you failed. What did you learn?",
    "Describe a situation where you had to deliver under a tight deadline.",
    "Tell me about a time you mentored someone or raised the bar for your team.",
  ],
  Technical: [
    "Walk me through how you'd debug a sudden p95 latency spike in a production API.",
    "Explain how you would design caching for a read-heavy endpoint. What are the trade-offs?",
    "How do you decide between SQL and NoSQL for a new service?",
    "Describe how you ensure code quality on a fast-moving team.",
    "Tell me about the most technically complex feature you've shipped end-to-end.",
  ],
  HR: [
    "Why are you interested in this role and our company?",
    "Where do you see yourself in three years?",
    "What does an ideal engineering culture look like to you?",
    "Tell me about a piece of feedback that changed how you work.",
    "How do you prioritize when everything feels urgent?",
  ],
  "System Design": [
    "Design a URL shortener that handles 100M redirects per day.",
    "Design a real-time collaborative document editor.",
    "Design the backend for a job application tracker like CareerOS.",
    "Design a notification system that scales to 10M users.",
    "Design an API rate limiter for a public developer platform.",
  ],
  General: [
    "Tell me about yourself and your journey into software engineering.",
    "What's a project you're most proud of, and why?",
    "How do you stay current with technology?",
    "What's the hardest bug you've ever fixed?",
    "Why should we hire you for this role?",
  ],
};

export function generateInterviewQuestions(type: string, _level: string, _jobTitle: string, count: number): string[] {
  const bank = QUESTION_BANKS[type] ?? QUESTION_BANKS.General;
  const extra = Object.values(QUESTION_BANKS).flat();
  const merged = [...bank, ...extra.filter((q) => !bank.includes(q))];
  return merged.slice(0, count);
}

export interface EvalResult {
  scores: { clarity: number; depth: number; structure: number; impact: number; overall: number };
  feedback: string;
  reaction: Reaction;
}

const STAR_RE = /(situation|task|action|result|so that|because|impact|led|built|designed|improved|reduced|increased|measured)/i;

async function evaluateLocal(_question: string, answer: string): Promise<EvalResult> {
  await wait(1800);
  const words = answer.trim().split(/\s+/).filter(Boolean).length;
  const hasMetric = METRIC_RE.test(answer);
  const hasStar = STAR_RE.test(answer);
  const firstPerson = /\b(I|we|my)\b/i.test(answer);

  const clarity = Math.max(2, Math.min(10, Math.round(words / 18) + (firstPerson ? 2 : 0)));
  const depth = Math.max(2, Math.min(10, Math.round(words / 24) + (hasStar ? 3 : 0)));
  const structure = Math.max(2, Math.min(10, 4 + (hasStar ? 3 : 0) + (words > 60 ? 2 : words > 30 ? 1 : 0)));
  const impact = Math.max(2, Math.min(10, 4 + (hasMetric ? 4 : 0) + (hasStar ? 1 : 0)));
  const overall = Math.round(((clarity + depth + structure + impact) / 4) * 10) / 10;

  const reaction: Reaction = overall >= 8.5 ? "excellent" : overall >= 7 ? "strong" : overall >= 5 ? "average" : "weak";
  const parts: string[] = [];
  if (hasStar && hasMetric) parts.push("Your answer clearly explained the problem and solution, and the measurable result makes the impact land.");
  else if (hasStar) parts.push("Your answer clearly explained the problem and solution. Consider adding a measurable result to make the impact stronger.");
  else if (hasMetric) parts.push("Strong use of numbers. Now frame it with a clear situation → action → result arc so it's easier to follow.");
  else parts.push("Good start. Anchor the story with a specific situation, the actions you personally took, and a measurable result.");
  if (words < 40) parts.push("Aim for 60–120 words — enough depth to show how you think.");
  if (words > 180) parts.push("Tighten it: interviewers retain the first 90 seconds best.");
  return { scores: { clarity, depth, structure, impact, overall }, feedback: parts.join(" "), reaction };
}

export async function evaluateInterviewAnswer(question: string, answer: string): Promise<EvalResult> {
  try {
    return await post<EvalResult>("/evaluate-answer", { question, answer });
  } catch {
    return evaluateLocal(question, answer);
  }
}

/* --------------------------------- AI coach ---------------------------------- */

export interface CoachCtx { readiness: number; resumeScore: number; apps: number }
export interface CoachMsg { from: "user" | "ai"; text: string }

/* Streams tokens from the real LLM; throws if the backend is unreachable (caller falls back). */
export async function streamCoach(
  message: string,
  history: CoachMsg[],
  ctx: CoachCtx,
  onDelta: (token: string) => void,
): Promise<void> {
  const res = await fetch(`${AI_API}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history, context: ctx }),
  });
  if (!res.ok || !res.body) throw new Error("chat unavailable");
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (payload === "[DONE]") return;
      try {
        const parsed = JSON.parse(payload) as { t?: string; error?: string };
        if (parsed.error) throw new Error(parsed.error);
        if (parsed.t) onDelta(parsed.t);
      } catch (e) {
        if (e instanceof SyntaxError) continue;
        throw e;
      }
    }
  }
}

/* Offline fallback when the AI backend is unreachable (static preview). */
export async function careerCoachChat(message: string, ctx: CoachCtx): Promise<string> {
  await wait(1500);
  const m = message.toLowerCase();
  if (/resume|ats|cv/.test(m))
    return `Your main resume scores ${ctx.resumeScore}/100 — strong, but two moves will push it past 95:\n\n1. Add a metric to every experience bullet (%, $, users, latency).\n2. Mirror the exact job title and top 3 keywords from each posting in your summary.\n\nWant me to run a fresh ATS analysis? Open ATS Analysis from the sidebar.`;
  if (/skill|learn|study/.test(m))
    return `Based on your target role (Software Engineer) and current gaps, the highest-leverage skills to learn next are:\n\n1. System Design — it gates senior-level interviews (you're at 58%).\n2. AWS — appears in 7 of your 8 saved job posts.\n3. Docker/Kubernetes — pair them in one weekend project.\n\nCheck your Career Roadmap — Testing is your next milestone.`;
  if (/interview|question|answer/.test(m))
    return `For interview answers, use the STAR arc: Situation (1 line) → Task (1 line) → Action (3–4 lines, what *you* did) → Result (a number). Example closer: “…which cut p95 latency 40% for 2M users.”\n\nPractice now in Interview Prep — the mock mode gives you per-answer scoring.`;
  if (/salary|negotiat|offer/.test(m))
    return `You have an active offer from Linear ($165k + equity) — that's leverage. Script for the Google call:\n\n“I'm excited about the role. I'm weighing another offer at $165k base — is there flexibility on compensation if we get to offer stage?”\n\nNever share the number first unless asked directly.`;
  if (/project|portfolio|github/.test(m))
    return `Your CareerOS project is your strongest signal — lead with it. For each project, frame: what it does → the hardest technical decision → a measurable outcome. Pulseboard's “40k checks/day on a $20 VPS” is exactly the kind of line recruiters remember.`;
  if (/job|apply|application/.test(m))
    return `You have ${ctx.apps} applications tracked with a 31% response rate — above the 20% benchmark. Focus this week:\n\n1. Close the Linear offer decision (Jul 15 deadline).\n2. Prep for the Google onsite on Jul 14.\n3. Apply to Figma after tailoring your resume — it's a 87% match sitting in Saved.`;
  return `Here's how I'd think about it: your career readiness is ${ctx.readiness}/100, and the fastest lever right now is interview prep (76%). Two mock interviews before your Google onsite would likely move you past 90.\n\nAsk me about your resume, skills, interviews, salary negotiation, or projects — I'll get specific.`;
}

/* ------------------------------ project describe ----------------------------- */

async function projectDescriptionLocal(
  project: { name: string; description: string; tech: string[]; achievements: string[] },
  variant: "resume" | "linkedin" | "github",
): Promise<string> {
  await wait(1400);
  const tech = project.tech.join(", ");
  const win = project.achievements[0] ?? "Shipped end-to-end as a production-grade project";
  if (variant === "resume")
    return `${project.name} — ${tech}\n• ${project.description}\n• ${win}.`;
  if (variant === "linkedin")
    return `Excited to share ${project.name}! 🚀\n\n${project.description}\n\nBuilt with ${tech}. ${win}.\n\n#softwareengineering #buildinpublic`;
  return `# ${project.name}\n\n${project.description}\n\n## Stack\n${project.tech.map((t) => `- ${t}`).join("\n")}\n\n## Highlights\n${project.achievements.map((a) => `- ${a}`).join("\n")}`;
}

export async function generateProjectDescription(
  project: { name: string; description: string; tech: string[]; achievements: string[] },
  variant: "resume" | "linkedin" | "github",
): Promise<string> {
  try {
    const res = await post<{ text: string }>("/project-description", { project, variant });
    return res.text;
  } catch {
    return projectDescriptionLocal(project, variant);
  }
}
